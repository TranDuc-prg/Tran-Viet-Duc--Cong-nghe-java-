package vn.edu.eaut.lab13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab13SpringDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
