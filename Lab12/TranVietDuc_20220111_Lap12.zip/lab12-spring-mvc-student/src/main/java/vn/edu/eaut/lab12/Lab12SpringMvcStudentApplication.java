package vn.edu.eaut.lab12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab12SpringMvcStudentApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab12SpringMvcStudentApplication.class, args);
    }

}
