package vn.edu.eaut.lab12.service;

import org.springframework.stereotype.Service;
import vn.edu.eaut.lab12.model.Student;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class StudentService {
    private final List<Student> students = new ArrayList<>();
    private long nextId = 1;

    public StudentService() {
        students.add(new Student(nextId++, "B20DCCN001", "Nguyễn Văn A", "a.nv@eaut.edu.vn", "CNTT 1"));
        students.add(new Student(nextId++, "B20DCCN002", "Trần Thị B", "b.tt@eaut.edu.vn", "CNTT 2"));
    }

    public List<Student> findAll() {
        return students;
    }

    public Student findById(Long id) {
        return students.stream().filter(s -> s.getId().equals(id)).findFirst().orElse(null);
    }

    public void save(Student student) {
        if (student.getId() == null) {
            student.setId(nextId++);
            students.add(student);
        } else {
            Student existing = findById(student.getId());
            if (existing != null) {
                existing.setStudentCode(student.getStudentCode());
                existing.setFullName(student.getFullName());
                existing.setEmail(student.getEmail());
                existing.setClassName(student.getClassName());
            }
        }
    }

    public void delete(Long id) {
        students.removeIf(s -> s.getId().equals(id));
    }

    public List<Student> searchByName(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return students;
        }
        return students.stream()
                .filter(s -> s.getFullName().toLowerCase().contains(keyword.toLowerCase()))
                .collect(Collectors.toList());
    }

    public boolean isStudentCodeExists(String studentCode, Long id) {
        return students.stream().anyMatch(s -> s.getStudentCode().equalsIgnoreCase(studentCode) && (id == null || !s.getId().equals(id)));
    }
}