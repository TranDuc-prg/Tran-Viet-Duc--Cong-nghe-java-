package vn.edu.eaut.lab12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab12SpringMvcStudentApplicationTests {

    @Test
    void contextLoads() {
    }

}
