package vn.edu.eaut.lab6.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import vn.edu.eaut.lab6.model.Student;
import vn.edu.eaut.lab6.store.StudentStore;

import java.io.IOException;
import java.util.List;

@WebServlet("/students")
public class StudentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        // Bài 7: Xử lý chức năng xóa sinh viên
        if ("delete".equals(action)) {
            String id = request.getParameter("id");
            if (id != null) {
                StudentStore.delete(id);
            }
            response.sendRedirect(request.getContextPath() + "/students");
            return;
        }

        /// Bài 8: Hiển thị form cập nhật thông tin sinh viên
        if ("edit".equals(action)) {
            String id = request.getParameter("id");
            Student student = StudentStore.findById(id);
            if (student != null) {
                request.setAttribute("student", student);
                request.getRequestDispatcher("/student-edit.jsp").forward(request, response);
                return;
            } else {
                // Nếu không tìm thấy, quay lại trang danh sách
                response.sendRedirect(request.getContextPath() + "/students");
                return;
            }
        }

        // Bài 6: Xử lý chức năng tìm kiếm sinh viên theo tên
        String keyword = request.getParameter("keyword");
        List<Student> studentList;
        if (keyword != null && !keyword.trim().isEmpty()) {
            studentList = StudentStore.findByName(keyword);
            request.setAttribute("keyword", keyword);
        } else {
            studentList = StudentStore.findAll();
        }

        request.setAttribute("students", studentList);
        request.getRequestDispatcher("/student-list.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");

        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String className = request.getParameter("className");
        String email = request.getParameter("email");

        // Bài 8: Xử lý cập nhật thông tin sinh viên khi gửi form từ student-edit.jsp
        if ("update".equals(action)) {
            StudentStore.update(id, name, className, email);
            response.sendRedirect(request.getContextPath() + "/students");
            return;
        }

        // Mặc định: Thêm mới sinh viên
        StudentStore.add(new Student(id, name, className, email));
        response.sendRedirect(request.getContextPath() + "/students");
    }
}