package vn.edu.eaut.lab6.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String user = request.getParameter("username");
        String pass = request.getParameter("password");

        if ("admin".equals(user) && "123456".equals(pass)) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            session.setAttribute("role", "admin"); // Lưu thêm phân quyền nếu làm bài 9

            // Thay "welcome.jsp" bằng trang bạn muốn chuyển tới sau khi đăng nhập thành công:
            // Ví dụ: chuyển đến trang quản lý sinh viên
            response.sendRedirect("students");

            // Hoặc nếu muốn chuyển đến Dashboard (Bài 10):
            // response.sendRedirect("dashboard.jsp");
        } else {
            response.sendRedirect("login.jsp?error=invalid");
        }
    }
}