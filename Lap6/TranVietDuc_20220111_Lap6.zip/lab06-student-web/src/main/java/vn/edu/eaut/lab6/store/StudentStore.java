package vn.edu.eaut.lab6.store;

import vn.edu.eaut.lab6.model.Student;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StudentStore {
    private static final List<Student> students = new ArrayList<>();

    static {
        // Bài 12: Khởi tạo sẵn từ 5 sinh viên mẫu trở lên
        students.add(new Student("SV001", "Nguyễn Văn An", "DCCNTT12", "an@example.com"));
        students.add(new Student("SV002", "Trần Thị Bình", "DCCNTT12", "binh@example.com"));
        students.add(new Student("SV003", "Lê Hoàng Cường", "DCCNTT13", "cuong@example.com"));
        students.add(new Student("SV004", "Phạm Thị Dung", "DCCNTT13", "dung@example.com"));
        students.add(new Student("SV005", "Hoàng Văn Em", "DCCNTT14", "em@example.com"));
    }

    public static List<Student> findAll() {
        return students;
    }

    public static void add(Student student) {
        students.add(student);
    }

    // Bài 7: Xóa sinh viên theo mã sinh viên (id)
    public static void delete(String id) {
        students.removeIf(sv -> sv.getId().equals(id));
    }

    // Bài 6: Tìm kiếm sinh viên theo họ tên (không phân biệt hoa thường)
    public static List<Student> findByName(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return students;
        }
        String lowerKeyword = keyword.toLowerCase();
        return students.stream()
                .filter(sv -> sv.getName().toLowerCase().contains(lowerKeyword))
                .collect(Collectors.toList());
    }

    // Tìm sinh viên theo ID (phục vụ chức năng Sửa)
    public static Student findById(String id) {
        for (Student sv : students) {
            if (sv.getId().equals(id)) {
                return sv;
            }
        }
        return null;
    }

    // Bài 8: Cập nhật thông tin sinh viên
    public static void update(String id, String name, String className, String email) {
        Student sv = findById(id);
        if (sv != null) {
            sv.setName(name);
            sv.setClassName(className);
            sv.setEmail(email);
        }
    }
}