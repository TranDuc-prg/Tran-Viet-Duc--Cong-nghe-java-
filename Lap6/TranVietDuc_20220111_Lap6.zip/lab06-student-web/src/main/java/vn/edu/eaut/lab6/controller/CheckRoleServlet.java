package vn.edu.eaut.lab6.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/check-role")
public class CheckRoleServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession(false);
        String user = (session != null) ? (String) session.getAttribute("user") : null;

        // Kiểm tra xem đã đăng nhập và có phải là admin hay không
        if ("admin".equals(user)) {
            // Nếu là admin, cho phép vào trang quản trị / dashboard
            response.sendRedirect("admin/dashboard");
        } else if (user != null) {
            // Nếu là user thường, chuyển đến trang dành riêng cho user hoặc báo hạn chế quyền
            response.getWriter().write("<h3>Ban la User, khong co quyền truy cap trang Quan tri!</h3>");
        } else {
            // Nếu chưa đăng nhập, chuyển hướng về trang login
            response.sendRedirect("login.jsp");
        }
    }
}