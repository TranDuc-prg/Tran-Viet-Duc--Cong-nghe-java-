package vn.edu.eaut.lab6.controller;

import vn.edu.eaut.lab6.store.StudentStore;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/dashboard")
public class DashboardServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Sửa lại gọi đúng phương thức static findAll() của StudentStore
        int totalStudents = StudentStore.findAll().size();
        request.setAttribute("totalStudents", totalStudents);
        request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
    }
}