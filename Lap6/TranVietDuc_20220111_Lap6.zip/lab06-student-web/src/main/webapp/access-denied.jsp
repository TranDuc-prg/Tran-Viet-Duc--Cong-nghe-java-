<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Lỗi Truy Cập - 403</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; margin-top: 100px; background-color: #f8f9fa; }
        .container { background: white; padding: 40px; display: inline-block; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        h1 { color: #dc3545; }
        a { color: #007bff; text-decoration: none; font-weight: bold; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
<div class="container">
    <h1>403 - Truy Cập Bị Từ Chối</h1>
    <p>Bạn không có quyền quản trị viên (Admin) để truy cập vào trang này!</p>
    <p><a href="index.jsp">Quay lại Trang Chủ</a> | <a href="login.jsp">Đăng nhập tài khoản khác</a></p>
</div>
</body>
</html>