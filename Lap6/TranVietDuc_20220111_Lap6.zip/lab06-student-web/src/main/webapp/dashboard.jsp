<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Admin Dashboard - Lab 6</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background-color: #f4f6f9; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); width: 300px; display: inline-block; }
        h2 { color: #333; }
        .number { font-size: 36px; color: #007bff; font-weight: bold; }
        .back-link { margin-top: 20px; display: block; }
    </style>
</head>
<body>
<h2>Trang Quản Trị (Admin Dashboard)</h2>
<div class="card">
    <p>Tổng số lượng sinh viên trong hệ thống:</p>
    <div class="number">${totalStudents}</div>
</div>
<div class="back-link">
    <a href="${pageContext.request.contextPath}/students">Quản lý Sinh viên</a> |
    <a href="${pageContext.request.contextPath}/index.jsp">Về Trang Chủ</a>
</div>
</body>
</html>