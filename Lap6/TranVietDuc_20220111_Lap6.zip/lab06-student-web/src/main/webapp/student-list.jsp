<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<html>
<head><title>Danh Sách Sinh Viên</title></head>
<body>
<h2>Danh Sách Sinh Viên</h2>
<a href="${pageContext.request.contextPath}/student-form.jsp">+ Thêm sinh viên mới</a><br/><br/>

<!-- Bài 6: Form tìm kiếm sinh viên theo tên -->
<form action="${pageContext.request.contextPath}/students" method="get">
    <input type="text" name="keyword" value="${keyword}" placeholder="Nhập tên sinh viên...">
    <button type="submit">Tìm kiếm</button>
    <a href="${pageContext.request.contextPath}/students">Làm mới</a>
</form>
<br/>

<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>Mã SV</th>
        <th>Họ Tên</th>
        <th>Lớp</th>
        <th>Email</th>
        <th>Thao tác</th>
    </tr>

    <!-- Sử dụng JSTL để kiểm tra danh sách và lặp thay vì dùng Scriptlet -->
    <c:choose>
        <c:when test="${not empty students}">
            <c:forEach var="s" items="${students}">
                <tr>
                    <td>${s.id}</td>
                    <td>${s.name}</td>
                    <td>${s.className}</td>
                    <td>${s.email}</td>
                    <td>
                        <a href="${pageContext.request.contextPath}/students?action=edit&id=${s.id}">Sửa</a> |
                        <a href="${pageContext.request.contextPath}/students?action=delete&id=${s.id}" onclick="return confirm('Bạn có chắc chắn muốn xóa sinh viên này không?');">Xóa</a>
                    </td>
                </tr>
            </c:forEach>
        </c:when>
        <c:otherwise>
            <tr>
                <td colspan="5" style="text-align: center;">Không tìm thấy sinh viên nào!</td>
            </tr>
        </c:otherwise>
    </c:choose>
</table>
<br/>
<a href="${pageContext.request.contextPath}/index.jsp">Về trang chủ</a>
</body>
</html>