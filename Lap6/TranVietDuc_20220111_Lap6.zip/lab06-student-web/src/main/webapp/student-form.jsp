<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head><title>Thêm Sinh Viên</title></head>
<body>
<h2>Thêm Sinh Viên Mới</h2>
<form action="students" method="post">
    Mã SV: <input type="text" name="id" required /><br/><br/>
    Họ tên: <input type="text" name="name" required /><br/><br/>
    Email: <input type="email" name="email" required /><br/><br/>
    Lớp: <input type="text" name="className" required /><br/><br/>
    <button type="submit">Lưu sinh viên</button>
</form>
<br/>
<a href="students">Xem danh sách sinh viên</a>
</body>
</html>