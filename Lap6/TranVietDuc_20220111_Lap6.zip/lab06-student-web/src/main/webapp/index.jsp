<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Trang Chủ Lab 6 - EAUT</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        h2 { color: #333; }
        ul { line-height: 1.8; }
        a { text-decoration: none; color: #0066cc; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
<h2>Chào mừng bạn đến với Lab 6 - EAUT</h2>
<ul>
    <li><a href="hello">Bài 1: Test HelloServlet</a></li>
    <li><a href="student-form.jsp">Bài 2: Tạo Form nhập sinh viên mới</a></li>
    <li><a href="students">Bài 3: Hiển thị danh sách Sinh viên (JSP + JSTL)</a></li>
    <li><a href="login.jsp">Bài 4: Đăng nhập & Xác thực Session</a></li>
    <li><a href="logout">Bài 5: Đăng xuất (Logout & Xóa Session)</a></li>
    <li><a href="students">Bài 6: Tìm kiếm sinh viên theo tên</a></li>
    <li><a href="students">Bài 7: Xóa sinh viên khỏi danh sách</a></li>
    <li><a href="students">Bài 8: Cập nhật thông tin sinh viên</a></li>

    <!-- Sửa Bài 9 trỏ tới Servlet/trang kiểm tra quyền riêng biệt -->
    <li><a href="check-role">Bài 9: Phân quyền truy cập (Admin / User)</a></li>

    <!-- Bài 10 giữ nguyên trang Dashboard -->
    <li><a href="admin/dashboard">Bài 10: Trang Dashboard thống kê dữ liệu</a></li>

    <li><a href="students">Bài 11: Ghi log truy cập qua Filter</a></li>
    <li><a href="students">Bài 12: Khởi tạo dữ liệu mẫu bằng Listener</a></li>
</ul>
</body>
</html>