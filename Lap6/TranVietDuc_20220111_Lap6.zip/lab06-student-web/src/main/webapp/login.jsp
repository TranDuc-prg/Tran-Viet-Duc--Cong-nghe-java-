<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head><title>Đăng nhập hệ thống</title></head>
<body>
<h2>Đăng Nhập Quản Trị</h2>
<form action="login" method="post">
    Tài khoản: <input type="text" name="username" required /><br/><br/>
    Mật khẩu: <input type="password" name="password" required /><br/><br/>
    <button type="submit">Đăng nhập</button>
</form>
<% if(request.getParameter("error") != null) { %>
<p style="color:red;">Sai tài khoản hoặc mật khẩu!</p>
<% } %>
</body>
</html>