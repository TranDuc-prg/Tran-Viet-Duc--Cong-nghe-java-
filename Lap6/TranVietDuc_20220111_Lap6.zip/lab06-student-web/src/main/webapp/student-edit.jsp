<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Sửa Thông Tin Sinh Viên</title>
</head>
<body>
<h2>Cập Nhật Thông Tin Sinh Viên</h2>
<form action="${pageContext.request.contextPath}/students" method="post">
    <input type="hidden" name="action" value="update">

    <label>Mã Sinh Viên:</label><br/>
    <input type="text" name="id" value="${student.id}" readonly><br/><br/>

    <label>Họ Tên:</label><br/>
    <input type="text" name="name" value="${student.name}" required><br/><br/>

    <label>Lớp:</label><br/>
    <input type="text" name="className" value="${student.className}" required><br/><br/>

    <label>Email:</label><br/>
    <input type="email" name="email" value="${student.email}" required><br/><br/>

    <button type="submit">Lưu Thay Đổi</button>
    <a href="${pageContext.request.contextPath}/students">Hủy</a>
</form>
</body>
</html>