<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head><title>Trang Chào Mừng</title></head>
<body>
<h2>Xin chào, bạn đã đăng nhập thành công!</h2>
<a href="logout">Đăng xuất</a>
</body>
</html>