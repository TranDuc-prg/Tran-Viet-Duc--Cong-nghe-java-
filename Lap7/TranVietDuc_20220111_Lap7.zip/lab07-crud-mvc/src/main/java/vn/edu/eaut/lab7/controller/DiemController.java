package vn.edu.eaut.lab7.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/diem")
public class DiemController extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/views/diem/form.jsp").forward(req, resp);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            double cc = Double.parseDouble(req.getParameter("chuyenCan"));
            double gk = Double.parseDouble(req.getParameter("giuaKy"));
            double ck = Double.parseDouble(req.getParameter("cuoiKy"));

            // Tính điểm tổng kết theo trọng số (Chuyên cần 10%, Giữa kỳ 30%, Cuối kỳ 60%)
            double tongKet = cc * 0.1 + gk * 0.3 + ck * 0.6;
            String xepLoai;
            if (tongKet >= 8.5) xepLoai = "A";
            else if (tongKet >= 7.0) xepLoai = "B";
            else if (tongKet >= 5.5) xepLoai = "C";
            else if (tongKet >= 4.0) xepLoai = "D";
            else xepLoai = "F";

            req.setAttribute("tongKet", tongKet);
            req.setAttribute("xepLoai", xepLoai);
        } catch (Exception e) {
            req.setAttribute("error", "Vui lòng nhập đúng định dạng số!");
        }
        req.getRequestDispatcher("/views/diem/form.jsp").forward(req, resp);
    }
}