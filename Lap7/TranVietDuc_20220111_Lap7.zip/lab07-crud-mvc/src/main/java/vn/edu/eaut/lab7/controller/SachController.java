package vn.edu.eaut.lab7.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.edu.eaut.lab7.model.Sach;
import vn.edu.eaut.lab7.repository.SachRepository;

import java.io.IOException;

@WebServlet("/sach")
public class SachController extends HttpServlet {
    private final SachRepository repo = new SachRepository();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");

        if ("delete".equals(action)) {
            repo.delete(Integer.parseInt(req.getParameter("id")));
            resp.sendRedirect(req.getContextPath() + "/sach");
            return;
        }

        req.setAttribute("dsSach", repo.search(req.getParameter("keyword")));
        // Tạo thư mục views/sach và file list.jsp để hiển thị giao diện tương tự sinh viên
        req.getRequestDispatcher("/views/sach/list.jsp").forward(req, resp);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        Sach s = new Sach(
                0,
                req.getParameter("maSach"),
                req.getParameter("tenSach"),
                req.getParameter("tacGia"),
                req.getParameter("nhaXuatBan"),
                Integer.parseInt(req.getParameter("namXuatBan"))
        );
        repo.add(s);
        resp.sendRedirect(req.getContextPath() + "/sach");
    }
}