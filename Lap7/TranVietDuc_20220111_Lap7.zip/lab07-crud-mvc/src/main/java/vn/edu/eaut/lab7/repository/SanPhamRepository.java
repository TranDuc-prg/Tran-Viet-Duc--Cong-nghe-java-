package vn.edu.eaut.lab7.repository;

import vn.edu.eaut.lab7.model.SanPham;
import vn.edu.eaut.lab7.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SanPhamRepository {
    public List<SanPham> getAll() {
        List<SanPham> list = new ArrayList<>();
        String sql = "SELECT * FROM san_pham";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new SanPham(
                        rs.getInt("id"),
                        rs.getString("ma_san_pham"),
                        rs.getString("ten_san_pham"),
                        rs.getString("mo_ta"),
                        rs.getDouble("gia"),
                        rs.getInt("so_luong")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void add(SanPham sp) {
        String sql = "INSERT INTO san_pham (ma_san_pham, ten_san_pham, mo_ta, gia, so_luong) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, sp.getMaSanPham());
            ps.setString(2, sp.getTenSanPham());
            ps.setString(3, sp.getMoTa());
            ps.setDouble(4, sp.getGia());
            ps.setInt(5, sp.getSo_luong());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(int id) {
        String sql = "DELETE FROM san_pham WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}