package vn.edu.eaut.lab7.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginController extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String u = req.getParameter("username");
        String p = req.getParameter("password");
        if ("admin".equals(u) && "123456".equals(p)) {
            HttpSession session = req.getSession();
            session.setAttribute("username", u);
            // Đã đồng bộ đường dẫn khớp với SinhVienController (/admin/sinh-vien)
            resp.sendRedirect(req.getContextPath() + "/admin/sinh-vien");
        } else {
            resp.sendRedirect(req.getContextPath() + "/login.jsp?error=1");
        }
    }
}