package vn.edu.eaut.lab7.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.edu.eaut.lab7.model.Item;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/gio-hang")
public class GioHangController extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        List<Item> cart = (List<Item>) session.getAttribute("cart");
        String action = req.getParameter("action");

        if ("add".equals(action)) {
            if (cart == null) {
                cart = new ArrayList<>();
                session.setAttribute("cart", cart);
            }
            String id = req.getParameter("id");
            String name = req.getParameter("name");
            double price = Double.parseDouble(req.getParameter("price"));

            boolean found = false;
            for (Item item : cart) {
                if (item.getId().equals(id)) {
                    item.setQuantity(item.getQuantity() + 1);
                    found = true;
                    break;
                }
            }
            if (!found) cart.add(new Item(id, name, price, 1));
        } else if ("remove".equals(action)) {
            String id = req.getParameter("id");
            if (cart != null) {
                cart.removeIf(item -> item.getId().equals(id));
            }
        }
        req.getRequestDispatcher("/views/giohang/cart.jsp").forward(req, resp);
    }
}