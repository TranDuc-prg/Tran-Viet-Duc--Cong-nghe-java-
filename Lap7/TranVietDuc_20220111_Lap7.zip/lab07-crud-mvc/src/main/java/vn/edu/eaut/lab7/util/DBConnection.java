package vn.edu.eaut.lab7.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Đã cập nhật đúng tên database là "quan_ly_sach" và mật khẩu rỗng "" (nếu XAMPP/Laragon của bạn không đặt mật khẩu root)
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quan_ly_sach?useSSL=false&serverTimezone=UTC", "root", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }
}