package vn.edu.eaut.lab7.repository;

import vn.edu.eaut.lab7.model.LopHoc;
import vn.edu.eaut.lab7.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LopHocRepository {
    public List<LopHoc> search(String keyword) {
        List<LopHoc> list = new ArrayList<>();
        String sql = "SELECT * FROM lop_hoc WHERE (? IS NULL OR ma_lop LIKE ? OR ten_lop LIKE ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String key = (keyword == null || keyword.isBlank()) ? null : "%" + keyword + "%";
            ps.setString(1, key);
            ps.setString(2, key);
            ps.setString(3, key);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new LopHoc(
                        rs.getInt("id"), rs.getString("ma_lop"),
                        rs.getString("ten_lop"), rs.getString("co_van_hoc_tap"),
                        rs.getInt("so_luong_sinh_vien")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public void add(LopHoc lh) {
        String sql = "INSERT INTO lop_hoc (ma_lop, ten_lop, co_van_hoc_tap, so_luong_sinh_vien) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, lh.getMaLop());
            ps.setString(2, lh.getTenLop());
            ps.setString(3, lh.getCoVanHocTap());
            ps.setInt(4, lh.getSoLuongSinhVien());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void delete(int id) {
        String sql = "DELETE FROM lop_hoc WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }
}