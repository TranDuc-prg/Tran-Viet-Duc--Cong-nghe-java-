package vn.edu.eaut.lab7.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.edu.eaut.lab7.model.SinhVien;
import vn.edu.eaut.lab7.repository.SinhVienRepository;

import java.io.IOException;
import java.util.List;

@WebServlet("/phan-trang")
public class PhanTrangController extends HttpServlet {
    private final SinhVienRepository repo = new SinhVienRepository();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        // Lấy danh sách sinh viên từ repository mẫu của bạn
        List<SinhVien> allList = repo.findAll();

        int pageSize = 2; // Số lượng hiển thị trên 1 trang (bạn có thể đổi thành 5 tùy ý)
        int totalItems = allList.size();
        int totalPages = (int) Math.ceil((double) totalItems / pageSize);

        int page = 1;
        String pageStr = req.getParameter("page");
        if (pageStr != null) {
            try {
                page = Integer.parseInt(pageStr);
            } catch (NumberFormatException e) {
                page = 1;
            }
        }

        if (page < 1) page = 1;
        if (page > totalPages && totalPages > 0) page = totalPages;

        int start = (page - 1) * pageSize;
        int end = Math.min(start + pageSize, totalItems);

        List<SinhVien> pagedList = (start < totalItems) ? allList.subList(start, end) : List.of();

        req.setAttribute("dsSinhVien", pagedList);
        req.setAttribute("currentPage", page);
        req.setAttribute("totalPages", totalPages);

        req.getRequestDispatcher("/views/phantrang/list.jsp").forward(req, resp);
    }
}