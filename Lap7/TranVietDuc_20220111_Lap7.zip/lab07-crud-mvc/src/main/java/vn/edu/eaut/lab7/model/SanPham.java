package vn.edu.eaut.lab7.model;

public class SanPham {
    private int id;
    private String maSanPham;
    private String tenSanPham;
    private String moTa;
    private double gia;
    private int so_luong;

    public SanPham() {}

    public SanPham(int id, String maSanPham, String tenSanPham, String moTa, double gia, int so_luong) {
        this.id = id;
        this.maSanPham = maSanPham;
        this.tenSanPham = tenSanPham;
        this.moTa = moTa;
        this.gia = gia;
        this.so_luong = so_luong;
    }

    // Getters và Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getMaSanPham() { return maSanPham; }
    public void setMaSanPham(String maSanPham) { this.maSanPham = maSanPham; }
    public String getTenSanPham() { return tenSanPham; }
    public void setTenSanPham(String tenSanPham) { this.tenSanPham = tenSanPham; }
    public String getMoTa() { return moTa; }
    public void setMoTa(String moTa) { this.moTa = moTa; }
    public double getGia() { return gia; }
    public void setGia(double gia) { this.gia = gia; }
    public int getSo_luong() { return so_luong; }
    public void setSo_luong(int so_luong) { this.so_luong = so_luong; }
}