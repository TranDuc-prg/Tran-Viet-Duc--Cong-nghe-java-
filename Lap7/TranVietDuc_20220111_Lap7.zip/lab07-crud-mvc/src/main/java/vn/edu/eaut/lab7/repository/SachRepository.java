package vn.edu.eaut.lab7.repository;

import vn.edu.eaut.lab7.model.Sach;
import vn.edu.eaut.lab7.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SachRepository {
    public List<Sach> search(String keyword) {
        List<Sach> list = new ArrayList<>();
        String sql = "SELECT * FROM sach WHERE (? IS NULL OR ten_sach LIKE ? OR tac_gia LIKE ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String searchKey = (keyword == null || keyword.isBlank()) ? null : "%" + keyword + "%";
            ps.setString(1, searchKey);
            ps.setString(2, searchKey);
            ps.setString(3, searchKey);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Sach(
                        rs.getInt("id"),
                        rs.getString("ma_sach"),
                        rs.getString("ten_sach"),
                        rs.getString("tac_gia"),
                        rs.getString("nha_xuat_ban"),
                        rs.getInt("nam_xuat_ban")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void add(Sach s) {
        String sql = "INSERT INTO sach (ma_sach, ten_sach, tac_gia, nha_xuat_ban, nam_xuat_ban) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, s.getMaSach());
            ps.setString(2, s.getTenSach());
            ps.setString(3, s.getTacGia());
            ps.setString(4, s.getNhaXuatBan());
            ps.setInt(5, s.getNamXuatBan());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(int id) {
        String sql = "DELETE FROM sach WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}