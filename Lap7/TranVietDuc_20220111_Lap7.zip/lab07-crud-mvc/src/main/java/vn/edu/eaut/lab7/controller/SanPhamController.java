package vn.edu.eaut.lab7.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.edu.eaut.lab7.model.SanPham;
import vn.edu.eaut.lab7.repository.SanPhamRepository;

import java.io.IOException;

@WebServlet("/san-pham")
public class SanPhamController extends HttpServlet {
    private final SanPhamRepository repo = new SanPhamRepository();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");

        if ("delete".equals(action)) {
            repo.delete(Integer.parseInt(req.getParameter("id")));
            resp.sendRedirect(req.getContextPath() + "/san-pham");
            return;
        }

        req.setAttribute("dsSanPham", repo.getAll());
        req.getRequestDispatcher("/views/sanpham/list.jsp").forward(req, resp);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        req.setCharacterEncoding("UTF-8");
        try {
            double gia = Double.parseDouble(req.getParameter("gia"));
            int soLuong = Integer.parseInt(req.getParameter("soLuong"));

            // Validate yêu cầu: giá > 0 và số lượng >= 0
            if (gia <= 0 || soLuong < 0) {
                req.setAttribute("error", "Giá phải lớn hơn 0 và số lượng phải lớn hơn hoặc bằng 0!");
                req.setAttribute("dsSanPham", repo.getAll());
                req.getRequestDispatcher("/views/sanpham/list.jsp").forward(req, resp);
                return;
            }

            SanPham sp = new SanPham(
                    0,
                    req.getParameter("maSanPham"),
                    req.getParameter("tenSanPham"),
                    req.getParameter("moTa"),
                    gia,
                    soLuong
            );
            repo.add(sp);
            resp.sendRedirect(req.getContextPath() + "/san-pham");
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect(req.getContextPath() + "/san-pham");
        }
    }
}