package vn.edu.eaut.lab7.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.edu.eaut.lab7.repository.SinhVienRepository;

import java.io.IOException;

@WebServlet("/tong-hop")
public class TongHopController extends HttpServlet {
    private final SinhVienRepository repo = new SinhVienRepository();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        // Truyền một số thông tin tổng hợp cho trang JSP hiển thị
        req.setAttribute("totalSinhVien", repo.findAll().size());

        // Điều hướng tới trang JSP tổng hợp
        req.getRequestDispatcher("/views/tonghop/index.jsp").forward(req, resp);
    }
}