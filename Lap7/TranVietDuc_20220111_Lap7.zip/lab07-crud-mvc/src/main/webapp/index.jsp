<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head><title>Lab 7 - CRUD MVC</title></head>
<body>
<h2>Lab 7 - CRUD bằng Servlet + JSP, dùng MVC đơn giản</h2>
<ul>
    <li><a href="${pageContext.request.contextPath}/login.jsp">Bài 5: Đăng nhập hệ thống</a></li>
    <li><a href="${pageContext.request.contextPath}/admin/sinh-vien">Bài 1-4: Quản lý sinh viên (CRUD MVC & Filter)</a></li>
    <li><a href="${pageContext.request.contextPath}/sach">Bài 6: Quản lý sách</a></li>
    <li><a href="${pageContext.request.contextPath}/san-pham">Bài 7: Quản lý sản phẩm</a></li>
    <li><a href="${pageContext.request.contextPath}/lop-hoc">Bài 8: Quản lý lớp học</a></li>
    <li><a href="${pageContext.request.contextPath}/diem">Bài 9: Quản lý điểm sinh viên</a></li>
    <li><a href="${pageContext.request.contextPath}/gio-hang">Bài 10: Quản lý giỏ hàng bằng Session</a></li>
    <li><a href="${pageContext.request.contextPath}/phan-trang">Bài 11: Phân trang danh sách</a></li>
    <li><a href="${pageContext.request.contextPath}/tong-hop">Bài 13: Bài tổng hợp MVC</a></li>
</ul>
</body>
</html>