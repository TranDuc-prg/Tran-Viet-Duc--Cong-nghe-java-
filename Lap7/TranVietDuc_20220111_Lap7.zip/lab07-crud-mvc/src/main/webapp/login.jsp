<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head><title>Đăng nhập hệ thống</title></head>
<body>
<h2>Đăng nhập quản trị</h2>
<form method="post" action="${pageContext.request.contextPath}/login">
  <p>Username: <input type="text" name="username" required></p>
  <p>Password: <input type="password" name="password" required></p>
  <button type="submit">Đăng nhập</button>
</form>
</body>
</html>