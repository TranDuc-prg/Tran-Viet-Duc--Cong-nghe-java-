<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>Quản lý Sách</title>
</head>
<body>
<h2>Quản lý Sách (Bài 6)</h2>
<a href="${pageContext.request.contextPath}/">Về trang chủ</a>
<hr/>

<!-- Form tìm kiếm -->
<form action="${pageContext.request.contextPath}/sach" method="get">
    <input type="text" name="keyword" placeholder="Nhập tên sách hoặc tác giả..." value="${param.keyword}" />
    <button type="submit">Tìm kiếm</button>
</form>
<br/>

<!-- Bảng hiển thị danh sách -->
<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Mã Sách</th>
        <th>Tên Sách</th>
        <th>Tác Giả</th>
        <th>Nhà Xuất Bản</th>
        <th>Năm XB</th>
        <th>Thao Tác</th>
    </tr>
    <c:forEach var="s" items="${dsSach}">
        <tr>
            <td>${s.id}</td>
            <td>${s.maSach}</td>
            <td>${s.tenSach}</td>
            <td>${s.tacGia}</td>
            <td>${s.nhaXuatBan}</td>
            <td>${s.namXuatBan}</td>
            <td>
                <a href="${pageContext.request.contextPath}/sach?action=delete&id=${s.id}" onclick="return confirm('Bạn có chắc muốn xóa?')">Xóa</a>
            </td>
        </tr>
    </c:forEach>
</table>

<h3>Thêm Sách Mới</h3>
<form action="${pageContext.request.contextPath}/sach" method="post">
    Mã sách: <input type="text" name="maSach" required /><br/><br/>
    Tên sách: <input type="text" name="tenSach" required /><br/><br/>
    Tác giả: <input type="text" name="tacGia" required /><br/><br/>
    Nhà xuất bản: <input type="text" name="nhaXuatBan" /><br/><br/>
    Năm xuất bản: <input type="number" name="namXuatBan" value="2026" /><br/><br/>
    <button type="submit">Lưu</button>
</form>
</body>
</html>