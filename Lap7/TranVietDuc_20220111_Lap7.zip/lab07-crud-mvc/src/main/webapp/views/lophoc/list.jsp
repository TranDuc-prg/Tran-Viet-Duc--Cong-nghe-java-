<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head><title>Quản lý Lớp học</title></head>
<body>
<h2>Bài 8: Quản lý Lớp học</h2>
<a href="${pageContext.request.contextPath}/">Về trang chủ</a><hr/>
<form action="${pageContext.request.contextPath}/lop-hoc" method="get">
    <input type="text" name="keyword" placeholder="Tìm theo mã hoặc tên lớp..." value="${param.keyword}"/>
    <button type="submit">Tìm kiếm</button>
</form><br/>
<table border="1" cellpadding="8">
    <tr><th>ID</th><th>Mã Lớp</th><th>Tên Lớp</th><th>CVHT</th><th>Sĩ số</th><th>Thao tác</th></tr>
    <c:forEach var="l" items="${dsLopHoc}">
        <tr>
            <td>${l.id}</td><td>${l.maLop}</td><td>${l.tenLop}</td>
            <td>${l.coVanHocTap}</td><td>${l.soLuongSinhVien}</td>
            <td><a href="${pageContext.request.contextPath}/lop-hoc?action=delete&id=${l.id}" onclick="return confirm('Xóa lớp này?')">Xóa</a></td>
        </tr>
    </c:forEach>
</table>
<h3>Thêm Lớp Học</h3>
<form action="${pageContext.request.contextPath}/lop-hoc" method="post">
    Mã lớp: <input type="text" name="maLop" required/><br/><br/>
    Tên lớp: <input type="text" name="tenLop" required/><br/><br/>
    Cố vấn học tập: <input type="text" name="coVanHocTap"/><br/><br/>
    Số lượng SV: <input type="number" name="soLuongSinhVien" value="40"/><br/><br/>
    <button type="submit">Lưu lớp học</button>
</form>
</body>
</html>