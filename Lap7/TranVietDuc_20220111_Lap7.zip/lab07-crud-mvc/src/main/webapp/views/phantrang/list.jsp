<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head><title>Phân trang danh sách</title></head>
<body>
<h2>Bài 11: Phân trang danh sách Sinh Viên</h2>
<a href="${pageContext.request.contextPath}/">Về trang chủ</a><hr/>

<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Mã SV</th>
        <th>Họ Tên</th>
        <th>Email</th>
        <th>Lớp</th>
    </tr>
    <c:forEach var="sv" items="${dsSinhVien}">
        <tr>
            <td>${sv.id}</td>
            <td>${sv.maSinhVien}</td>
            <td>${sv.hoTen}</td>
            <td>${sv.email}</td>
            <td>${sv.lop}</td>
        </tr>
    </c:forEach>
</table>
<br/>

<!-- Thanh phân trang -->
<div>
    <c:forEach begin="1" end="${totalPages}" var="i">
        <c:choose>
            <c:when test="${currentPage == i}">
                <span style="padding: 5px 10px; background: blue; color: white; font-weight: bold;">${i}</span>
            </c:when>
            <c:otherwise>
                <a href="${pageContext.request.contextPath}/phan-trang?page=${i}" style="padding: 5px 10px; border: 1px solid gray; text-decoration: none;">${i}</a>
            </c:otherwise>
        </c:choose>
    </c:forEach>
</div>
</body>
</html>