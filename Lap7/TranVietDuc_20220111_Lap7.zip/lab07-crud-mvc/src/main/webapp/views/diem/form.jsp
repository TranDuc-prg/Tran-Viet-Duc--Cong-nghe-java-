<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head><title>Quản lý Điểm Sinh Viên</title></head>
<body>
<h2>Bài 9: Quản lý Điểm Sinh Viên</h2>
<a href="${pageContext.request.contextPath}/">Về trang chủ</a><hr/>
<form action="${pageContext.request.contextPath}/diem" method="post">
    Điểm Chuyên Cần (10%): <input type="number" step="0.1" name="chuyenCan" required/><br/><br/>
    Điểm Giữa Kỳ (30%): <input type="number" step="0.1" name="giuaKy" required/><br/><br/>
    Điểm Cuối Kỳ (60%): <input type="number" step="0.1" name="cuoiKy" required/><br/><br/>
    <button type="submit">Tính Điểm & Xếp Loại</button>
</form>
<c:if test="${not empty tongKet}">
    <h3>Kết quả:</h3>
    <p>Điểm tổng kết: <b>${tongKet}</b></p>
    <p>Xếp loại: <b style="color: blue;">${xepLoai}</b></p>
</c:if>
</body>
</html>