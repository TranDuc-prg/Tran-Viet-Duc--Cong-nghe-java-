<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head><title>Quản lý Sản phẩm</title></head>
<body>
<h2>Quản lý Sản phẩm (Bài 7)</h2>
<a href="${pageContext.request.contextPath}/">Về trang chủ</a>
<hr/>

<c:if test="${not empty error}">
    <p style="color: red;">${error}</p>
</c:if>

<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Mã SP</th>
        <th>Tên Sản Phẩm</th>
        <th>Mô Tả</th>
        <th>Giá</th>
        <th>Số Lượng</th>
        <th>Thao Tác</th>
    </tr>
    <c:forEach var="sp" items="${dsSanPham}">
        <tr>
            <td>${sp.id}</td>
            <td>${sp.maSanPham}</td>
            <td>${sp.tenSanPham}</td>
            <td>${sp.moTa}</td>
            <td>${sp.gia}</td>
            <td>${sp.so_luong}</td>
            <td>
                <a href="${pageContext.request.contextPath}/san-pham?action=delete&id=${sp.id}" onclick="return confirm('Xóa sản phẩm này?')">Xóa</a>
            </td>
        </tr>
    </c:forEach>
</table>

<h3>Thêm Sản Phẩm Mới</h3>
<form action="${pageContext.request.contextPath}/san-pham" method="post">
    Mã sản phẩm: <input type="text" name="maSanPham" required /><br/><br/>
    Tên sản phẩm: <input type="text" name="tenSanPham" required /><br/><br/>
    Mô tả: <textarea name="moTa"></textarea><br/><br/>
    Giá (> 0): <input type="number" step="0.01" name="gia" required /><br/><br/>
    Số lượng (>= 0): <input type="number" name="soLuong" required /><br/><br/>
    <button type="submit">Lưu sản phẩm</button>
</form>
</body>
</html>