<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<h2>Chi tiết sinh viên</h2>
<p><strong>ID:</strong> ${sv.id}</p>
<p><strong>Mã SV:</strong> ${sv.maSinhVien}</p>
<p><strong>Họ tên:</strong> ${sv.hoTen}</p>
<p><strong>Email:</strong> ${sv.email}</p>
<p><strong>Lớp:</strong> ${sv.lop}</p>
<p><a href="${pageContext.request.contextPath}/admin/sinh-vien">Quay lại danh sách</a></p>