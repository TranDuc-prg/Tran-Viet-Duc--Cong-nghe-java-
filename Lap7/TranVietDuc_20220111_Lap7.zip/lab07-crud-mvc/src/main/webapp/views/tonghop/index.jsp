<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Bài 13 - Tổng Hợp Hệ Thống</title>
</head>
<body>
<h2>Bài 13: Trang Tổng Hợp Lab 7 - CRUD MVC</h2>
<a href="${pageContext.request.contextPath}/">Về trang chủ</a>
<hr/>
<ul>
    <li>Tổng số lượng sinh viên trong hệ thống: <b>${totalSinhVien}</b></li>
    <li>Trạng thái ứng dụng: <span style="color: green; font-weight: bold;">Hoạt động ổn định (Active)</span></li>
</ul>
</body>
</html>