<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head><title>Giỏ hàng Session</title></head>
<body>
<h2>Bài 10: Quản lý giỏ hàng</h2>
<a href="${pageContext.request.contextPath}/">Về trang chủ</a><hr/>
<h3>Sản phẩm mẫu có sẵn:</h3>
<ul>
    <li>Sản phẩm A (100,000đ) - <a href="gio-hang?action=add&id=1&name=SanPhamA&price=100000">Thêm vào giỏ</a></li>
    <li>Sản phẩm B (250,000đ) - <a href="gio-hang?action=add&id=2&name=SanPhamB&price=250000">Thêm vào giỏ</a></li>
</ul>
<h3>Giỏ hàng của bạn:</h3>
<table border="1" cellpadding="5">
    <tr><th>Tên SP</th><th>Giá</th><th>Số lượng</th><th>Thành tiền</th><th>Xóa</th></tr>
    <c:set var="tongTien" value="0"/>
    <c:forEach var="i" items="${cart}">
        <c:set var="tongTien" value="${tongTien + i.total}"/>
        <tr>
            <td>${i.name}</td><td>${i.price}</td><td>${i.quantity}</td><td>${i.total}</td>
            <td><a href="gio-hang?action=remove&id=${i.id}">Xóa</a></td>
        </tr>
    </c:forEach>
</table>
<h3>Tổng thanh toán: ${tongTien} VNĐ</h3>
</body>
</html>