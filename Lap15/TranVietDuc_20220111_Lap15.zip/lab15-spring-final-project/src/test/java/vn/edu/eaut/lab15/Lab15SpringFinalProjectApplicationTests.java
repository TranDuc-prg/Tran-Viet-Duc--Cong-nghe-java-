package vn.edu.eaut.lab15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab15SpringFinalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
