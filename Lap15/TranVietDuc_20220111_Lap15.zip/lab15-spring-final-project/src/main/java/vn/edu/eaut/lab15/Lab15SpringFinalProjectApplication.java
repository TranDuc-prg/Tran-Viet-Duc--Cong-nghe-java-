package vn.edu.eaut.lab15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab15SpringFinalProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab15SpringFinalProjectApplication.class, args);
	}

}
