package vn.edu.eaut.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManagementPortalSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManagementPortalSpringApplication.class, args);
	}

}