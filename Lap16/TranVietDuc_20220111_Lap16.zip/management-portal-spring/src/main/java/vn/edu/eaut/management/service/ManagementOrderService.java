package vn.edu.eaut.management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import vn.edu.eaut.management.entity.OrderEntity;
import vn.edu.eaut.management.entity.OrderStatusHistory;
import vn.edu.eaut.management.repository.OrderRepository;
import vn.edu.eaut.management.repository.OrderStatusHistoryRepository;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ManagementOrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderStatusHistoryRepository historyRepository;

    public List<OrderEntity> getReadyOrders() {
        return orderRepository.findByStatus("READY");
    }

    public List<OrderEntity> getOrdersByStatus(String status) {
        return orderRepository.findByStatus(status);
    }

    public Double calculateCompletedRevenue() {
        List<OrderEntity> completedOrders = orderRepository.findByStatus("COMPLETED");
        double total = 0.0;
        for (OrderEntity order : completedOrders) {
            if (order.getTotalAmount() != null) {
                total += order.getTotalAmount();
            }
        }
        return total;
    }

    public void createTestOrder() {
        OrderEntity order = new OrderEntity();
        order.setCustomerId(1L);
        order.setTotalAmount(250000.0);
        order.setStatus("READY");
        order.setCreatedAt(LocalDateTime.now());
        orderRepository.save(order);
    }

    @Transactional
    public void approveOrder(Long orderId) {
        OrderEntity order = orderRepository.findById(orderId).orElse(null);
        if (order != null) {
            String oldStatus = order.getStatus();
            order.setStatus("SHIPPING");
            orderRepository.save(order);

            OrderStatusHistory history = new OrderStatusHistory();
            history.setOrderId(order.getId());
            history.setOldStatus(oldStatus);
            history.setNewStatus("SHIPPING");
            history.setChangedBy(3L);
            history.setChangedAt(LocalDateTime.now());
            history.setPlatform("SPRING_BOOT_PORTAL");
            history.setIpAddress("127.0.0.1");
            history.setNote("Quản lý phê duyệt đơn hàng sang trạng thái giao hàng");
            historyRepository.save(history);
        }
    }
}