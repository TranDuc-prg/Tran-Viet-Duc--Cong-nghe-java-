package vn.edu.eaut.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import vn.edu.eaut.management.service.ManagementOrderService;

@Controller
public class ManagementController {

    @Autowired
    private ManagementOrderService orderService;

    @GetMapping("/manager/orders")
    public String viewOrders(@RequestParam(name = "status", defaultValue = "READY") String status, Model model) {
        model.addAttribute("orders", orderService.getOrdersByStatus(status));
        model.addAttribute("currentStatus", status);
        model.addAttribute("totalRevenue", orderService.calculateCompletedRevenue());
        return "orders";
    }

    @PostMapping("/manager/orders/approve/{id}")
    public String approveOrder(@PathVariable("id") Long id) {
        orderService.approveOrder(id);
        return "redirect:/manager/orders?status=READY";
    }

    @PostMapping("/manager/orders/add")
    public String addTestOrder() {
        orderService.createTestOrder();
        return "redirect:/manager/orders?status=READY";
    }
}