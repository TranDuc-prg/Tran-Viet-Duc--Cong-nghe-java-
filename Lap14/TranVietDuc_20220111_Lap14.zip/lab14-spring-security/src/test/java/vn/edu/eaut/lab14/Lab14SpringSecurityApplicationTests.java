package vn.edu.eaut.lab14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab14SpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
