package vn.edu.eaut.lab14.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/students")
public class StudentController {

    @GetMapping("")
    public String listStudents() {
        return "students/list";
    }

    @GetMapping("/create")
    @PreAuthorize("hasRole('ADMIN')")
    public String createStudentForm() {
        return "students/create";
    }

    @PostMapping("/create")
    @PreAuthorize("hasRole('ADMIN')")
    public String saveStudent(@RequestParam("name") String name, @RequestParam("email") String email) {
        // Xử lý lưu sinh viên mới
        return "redirect:/students";
    }

    // Cập nhật hàm này để trỏ đúng sang view "students/edit" và truyền id
    @GetMapping("/edit/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String editStudentForm(@PathVariable("id") Long id, Model model) {
        model.addAttribute("id", id);
        return "students/edit";
    }

    @PostMapping("/edit/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String updateStudent(@PathVariable("id") Long id, @RequestParam("name") String name, @RequestParam("email") String email) {
        // Xử lý cập nhật thông tin sinh viên sau khi submit form edit
        return "redirect:/students";
    }

    @GetMapping("/delete/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String deleteStudent(@PathVariable("id") Long id) {
        // Xử lý xóa sinh viên
        return "redirect:/students";
    }
}