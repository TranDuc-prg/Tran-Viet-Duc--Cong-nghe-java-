package vn.edu.eaut.lab14.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CourseController {

    @GetMapping("/courses")
    public String listCourses(Model model) {
        model.addAttribute("title", "Quản lý Khóa học");
        return "courses"; // Trỏ đúng tên file courses.html
    }
}