package vn.edu.eaut.lab14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab14SpringSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab14SpringSecurityApplication.class, args);
	}

}
