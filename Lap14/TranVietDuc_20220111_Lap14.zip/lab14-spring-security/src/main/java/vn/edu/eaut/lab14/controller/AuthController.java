package vn.edu.eaut.lab14.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AuthController {

    @GetMapping("/login")
    public String login() {
        return "auth/login"; // Bài 4
    }

    @GetMapping("/403")
    public String accessDenied() {
        return "error/403"; // Bài 7
    }
}