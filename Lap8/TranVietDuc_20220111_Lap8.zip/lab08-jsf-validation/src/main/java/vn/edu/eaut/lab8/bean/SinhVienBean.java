package vn.edu.eaut.lab8.bean;

import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import vn.edu.eaut.lab8.model.SinhVien;
import vn.edu.eaut.lab8.repository.SinhVienRepository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named("sinhVienBean")
@SessionScoped
public class SinhVienBean implements Serializable {
    private SinhVien sinhVien = new SinhVien();
    private final SinhVienRepository repo = new SinhVienRepository();
    private String keyword = "";
    private boolean isEdit = false;

    // Danh sách các lớp học dùng cho Bài 12 (selectOneMenu)
    private List<String> danhSachLop;

    public SinhVienBean() {
        danhSachLop = new ArrayList<>();
        danhSachLop.add("DCCNTT15.10.1");
        danhSachLop.add("DCCNTT15.10.2");
        danhSachLop.add("DCCNTT15.10.3");
        danhSachLop.add("DCCNTT15.10.4");
    }

    public String save() {
        if (isEdit) {
            repo.update(sinhVien);
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Thành công", "Đã cập nhật sinh viên"));
        } else {
            repo.add(sinhVien);
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Thành công", "Đã lưu sinh viên"));
        }
        sinhVien = new SinhVien();
        isEdit = false;
        return "sinhvien-list?faces-redirect=true";
    }

    public String edit(int id) {
        SinhVien sv = repo.findById(id);
        if (sv != null) {
            this.sinhVien = new SinhVien(sv.getId(), sv.getMaSinhVien(), sv.getHoTen(), sv.getEmail(), sv.getLop());
            this.isEdit = true;
            return "sinhvien-form";
        }
        return null;
    }

    public void delete(int id) {
        repo.delete(id);
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Thành công", "Đã xóa sinh viên"));
    }

    public void search() {
        // Tự động tìm kiếm qua getter getDsSinhVien()
    }

    public String resetForm() {
        this.sinhVien = new SinhVien();
        this.isEdit = false;
        return "sinhvien-form";
    }

    public List<SinhVien> getDsSinhVien() { return repo.search(keyword); }
    public SinhVien getSinhVien() { return sinhVien; }
    public void setSinhVien(SinhVien sinhVien) { this.sinhVien = sinhVien; }
    public String getKeyword() { return keyword; }
    public void setKeyword(String keyword) { this.keyword = keyword; }
    public boolean isEdit() { return isEdit; }
    public void setEdit(boolean edit) { isEdit = edit; }
    public List<String> getDanhSachLop() { return danhSachLop; }
}