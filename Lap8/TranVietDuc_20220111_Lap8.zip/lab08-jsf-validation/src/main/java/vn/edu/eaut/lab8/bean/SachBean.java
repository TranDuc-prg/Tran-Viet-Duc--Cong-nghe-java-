package vn.edu.eaut.lab8.bean;

import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import vn.edu.eaut.lab8.model.Sach;

@Named("sachBean")
@RequestScoped
public class SachBean {
    private Sach sach = new Sach();

    // Đổi tên hàm từ save() sang themSach()
    public String themSach() {
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Thành công", "Đã lưu thông tin sách!"));
        sach = new Sach();
        return null;
    }

    public Sach getSach() { return sach; }
    public void setSach(Sach sach) { this.sach = sach; }
}