package vn.edu.eaut.model;

public class UserSession {

    private static String username;
    private static String fullName;
    private static String role;

    public static void login(String user, String name, String r) {
        username = user;
        fullName = name;

        if (r != null) {
            r = r.trim().toUpperCase();

            // Chuẩn hóa role cũ về role mới
            switch (r) {
                case "HR":
                case "NHANSU":
                case "MANAGER":
                    r = "QUAN_LY";
                    break;

                case "USER":
                case "EMPLOYEE":
                case "NHANVIEN":
                    r = "NHAN_VIEN";
                    break;

                case "KETOAN":
                    r = "KETOAN";
                    break;

                case "ADMIN":
                    r = "ADMIN";
                    break;
            }
        }

        role = r;
    }

    public static String getUsername() {
        return username;
    }

    public static String getFullName() {
        return fullName;
    }

    public static String getRole() {
        return role;
    }

    public static boolean isAdmin() {
        return "ADMIN".equals(role);
    }

    public static boolean isQuanLy() {
        return "QUAN_LY".equals(role);
    }

    public static boolean isKeToan() {
        return "KETOAN".equals(role);
    }

    public static boolean isNhanVien() {
        return "NHAN_VIEN".equals(role);
    }

    public static void logout() {
        username = null;
        fullName = null;
        role = null;
    }
}