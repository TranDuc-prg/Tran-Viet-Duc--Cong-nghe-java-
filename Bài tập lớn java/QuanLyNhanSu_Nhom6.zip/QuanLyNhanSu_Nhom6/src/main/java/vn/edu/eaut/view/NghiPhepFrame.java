package vn.edu.eaut.view;

import vn.edu.eaut.dao.NghiPhepDAO;
import vn.edu.eaut.model.NghiPhep;
import vn.edu.eaut.model.UserSession;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class NghiPhepFrame extends JPanel {
    private final JTable table;
    private final DefaultTableModel tableModel;
    private final JTextField txtMaNV;
    private final JTextField txtTuNgay;
    private final JTextField txtDenNgay;
    private final JTextField txtLyDo;
    private final JComboBox<String> cbTrangThai;
    private final JButton btnThem;
    private final JButton btnSua;
    private final JButton btnXoa;
    private final JButton btnLamMoi;
    private final NghiPhepDAO nghiPhepDAO;

    public NghiPhepFrame() {
        nghiPhepDAO = new NghiPhepDAO();

        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(new Color(245, 247, 250));

        // Tiêu đề
        JLabel lblHeader = new JLabel("QUẢN LÝ ĐƠN XIN NGHỈ PHÉP", JLabel.CENTER);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblHeader.setForeground(new Color(41, 128, 185));
        lblHeader.setBorder(new EmptyBorder(0, 0, 5, 0));
        add(lblHeader, BorderLayout.NORTH);

        // --- Panel bên trái: Form nhập liệu & Xử lý gọn gàng ---
        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setBackground(Color.WHITE);
        panelForm.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(200, 200, 200)),
                        " Thông tin đơn nghỉ phép ",
                        0, 0, new Font("Segoe UI", Font.BOLD, 13), new Color(41, 128, 185)
                ),
                new EmptyBorder(12, 12, 12, 12)
        ));
        panelForm.setPreferredSize(new Dimension(320, 0));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.weightx = 1.0;

        int row = 0;
        gbc.gridy = row++; panelForm.add(createLabel("Mã Nhân Viên:"), gbc);
        txtMaNV = new JTextField(); styleTextField(txtMaNV);
        gbc.gridy = row++; panelForm.add(txtMaNV, gbc);

        gbc.gridy = row++; panelForm.add(createLabel("Từ ngày (YYYY-MM-DD):"), gbc);
        txtTuNgay = new JTextField(); styleTextField(txtTuNgay);
        gbc.gridy = row++; panelForm.add(txtTuNgay, gbc);

        gbc.gridy = row++; panelForm.add(createLabel("Đến ngày (YYYY-MM-DD):"), gbc);
        txtDenNgay = new JTextField(); styleTextField(txtDenNgay);
        gbc.gridy = row++; panelForm.add(txtDenNgay, gbc);

        gbc.gridy = row++; panelForm.add(createLabel("Lý do xin nghỉ:"), gbc);
        txtLyDo = new JTextField(); styleTextField(txtLyDo);
        gbc.gridy = row++; panelForm.add(txtLyDo, gbc);

        gbc.gridy = row++; panelForm.add(createLabel("Trạng thái đơn:"), gbc);
        cbTrangThai = new JComboBox<>(new String[]{"Chờ duyệt", "Đã duyệt", "Từ chối"});
        styleComboBox(cbTrangThai);
        gbc.gridy = row++; panelForm.add(cbTrangThai, gbc);

        // Panel chứa các nút chức năng
        JPanel panelButtons = new JPanel(new GridLayout(2, 2, 8, 8));
        panelButtons.setBackground(Color.WHITE);

        btnThem = new JButton("Tạo đơn");
        btnSua = new JButton("Cập nhật / Duyệt");
        btnXoa = new JButton("Xóa bỏ");
        btnLamMoi = new JButton("Làm mới");

        styleButton(btnThem, new Color(46, 204, 113));
        styleButton(btnSua, new Color(230, 126, 34));
        styleButton(btnXoa, new Color(231, 76, 60));
        styleButton(btnLamMoi, new Color(52, 152, 219));

        panelButtons.add(btnThem);
        panelButtons.add(btnSua);
        panelButtons.add(btnXoa);
        panelButtons.add(btnLamMoi);

        gbc.gridy = row++;
        gbc.insets = new Insets(15, 6, 6, 6);
        panelForm.add(panelButtons, gbc);

        gbc.gridy = row++;
        gbc.weighty = 1.0;
        panelForm.add(new JLabel(""), gbc);

        add(panelForm, BorderLayout.WEST);

        // --- Panel bên phải: Bảng hiển thị danh sách gọn gàng ---
        tableModel = new DefaultTableModel(new String[]{
                "ID", "Mã NV", "Họ Tên", "Từ Ngày", "Đến Ngày", "Lý Do", "Trạng Thái"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setPreferredSize(new Dimension(0, 32));

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setBackground(new Color(41, 128, 185));
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        headerRenderer.setFont(new Font("Segoe UI", Font.BOLD, 13));

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        table.getColumnModel().getColumn(0).setPreferredWidth(50); table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(1).setPreferredWidth(90); table.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(3).setPreferredWidth(100); table.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(4).setPreferredWidth(100); table.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(6).setPreferredWidth(100); table.getColumnModel().getColumn(6).setCellRenderer(centerRenderer);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                " Danh sách đơn nghỉ phép ",
                0, 0, new Font("Segoe UI", Font.BOLD, 13), new Color(41, 128, 185)
        ));
        add(scrollPane, BorderLayout.CENTER);

        // Load dữ liệu ban đầu
        loadDataToTable();
        clearForm();

        // Sự kiện click dòng trên bảng
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    txtMaNV.setText(tableModel.getValueAt(row, 1).toString());
                    txtTuNgay.setText(tableModel.getValueAt(row, 3).toString());
                    txtDenNgay.setText(tableModel.getValueAt(row, 4).toString());
                    txtLyDo.setText(tableModel.getValueAt(row, 5) != null ? tableModel.getValueAt(row, 5).toString() : "");
                    cbTrangThai.setSelectedItem(tableModel.getValueAt(row, 6).toString());
                }
            }
        });

        // Xử lý sự kiện các nút
        btnThem.addActionListener(e -> handleAdd());
        btnSua.addActionListener(e -> handleUpdate());
        btnXoa.addActionListener(e -> handleDelete());
        btnLamMoi.addActionListener(e -> {
            clearForm();
            loadDataToTable();
        });
    }

    private JLabel createLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        return lbl;
    }

    private void styleTextField(JTextField tf) {
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setPreferredSize(new Dimension(0, 30));
    }

    private void styleComboBox(JComboBox<String> cb) {
        cb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cb.setBackground(Color.WHITE);
        cb.setPreferredSize(new Dimension(0, 30));
    }

    private void styleButton(JButton btn, Color bgColor) {
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void loadDataToTable() {
        tableModel.setRowCount(0);
        List<NghiPhep> list = nghiPhepDAO.getAll();
        for (NghiPhep np : list) {
            tableModel.addRow(new Object[]{
                    np.getId(),
                    np.getMaNv(),
                    np.getHoTen(),
                    np.getNgayBatDau(),
                    np.getNgayKetThuc(),
                    np.getLyDo(),
                    np.getTrangThai()
            });
        }
    }

    private void handleAdd() {
        String maNV = txtMaNV.getText().trim();
        String tuNgayStr = txtTuNgay.getText().trim();
        String denNgayStr = txtDenNgay.getText().trim();
        String lyDo = txtLyDo.getText().trim();

        if (maNV.isEmpty() || tuNgayStr.isEmpty() || denNgayStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập Mã NV, Từ ngày và Đến ngày!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        long soNgayNghi = 1;
        try {
            LocalDate tuNgay = LocalDate.parse(tuNgayStr);
            LocalDate denNgay = LocalDate.parse(denNgayStr);
            LocalDate ngayHienTai = LocalDate.now();

            if (tuNgay.isBefore(ngayHienTai) || denNgay.isBefore(ngayHienTai)) {
                JOptionPane.showMessageDialog(this,
                        "Không thể tạo đơn xin nghỉ phép cho thời gian trong quá khứ!\nThời gian tạo phải từ ngày hôm nay (" + ngayHienTai + ") trở đi.",
                        "Cảnh báo ngày quá hạn", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (denNgay.isBefore(tuNgay)) {
                JOptionPane.showMessageDialog(this, "Đến ngày không được nhỏ hơn Từ ngày!", "Cảnh báo ngày không hợp lệ", JOptionPane.WARNING_MESSAGE);
                return;
            }

            soNgayNghi = ChronoUnit.DAYS.between(tuNgay, denNgay) + 1;
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Định dạng ngày không hợp lệ! Vui lòng nhập theo dạng YYYY-MM-DD.", "Lỗi định dạng", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int nhanVienId = nghiPhepDAO.getNhanVienIdByMaNv(maNV);
        if (nhanVienId == -1) {
            JOptionPane.showMessageDialog(this, "Mã nhân viên không tồn tại trong hệ thống!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        NghiPhep np = new NghiPhep();
        np.setNhanVienId(nhanVienId);
        np.setNgayBatDau(tuNgayStr);
        np.setNgayKetThuc(denNgayStr);
        np.setSoNgayNghi((int) soNgayNghi);
        np.setLyDo(lyDo);
        np.setTrangThai("Chờ duyệt"); // Mặc định đơn mới tạo

        if (nghiPhepDAO.insert(np)) {
            JOptionPane.showMessageDialog(this, "Tạo đơn nghỉ phép thành công!");
            loadDataToTable();
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, "Lỗi thêm dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleUpdate() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn đơn cần cập nhật/duyệt trên bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = Integer.parseInt(tableModel.getValueAt(row, 0).toString());

        NghiPhep np = new NghiPhep();
        np.setId(id);
        np.setNgayBatDau(txtTuNgay.getText().trim());
        np.setNgayKetThuc(txtDenNgay.getText().trim());
        np.setLyDo(txtLyDo.getText().trim());
        np.setTrangThai(cbTrangThai.getSelectedItem().toString());

        // Lấy tên user hiện tại gán ngầm làm người duyệt nếu cần lưu vết
        String currentUser = UserSession.getUsername() != null ? UserSession.getUsername() : "Admin";
        np.setNguoiDuyet(currentUser);
        np.setNgayDuyet(LocalDate.now().toString());

        if (nghiPhepDAO.update(np)) {
            JOptionPane.showMessageDialog(this, "Cập nhật trạng thái đơn thành công!");
            loadDataToTable();
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, "Lỗi cập nhật dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleDelete() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn đơn cần xóa trên bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = Integer.parseInt(tableModel.getValueAt(row, 0).toString());
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa đơn xin nghỉ phép này?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (nghiPhepDAO.delete(id)) {
                JOptionPane.showMessageDialog(this, "Xóa thành công!");
                loadDataToTable();
                clearForm();
            } else {
                JOptionPane.showMessageDialog(this, "Lỗi xóa dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void clearForm() {
        txtMaNV.setText("");
        LocalDate today = LocalDate.now();
        txtTuNgay.setText(today.toString());
        txtDenNgay.setText(today.toString());
        txtLyDo.setText("");
        cbTrangThai.setSelectedIndex(0);
        table.clearSelection();
    }
}