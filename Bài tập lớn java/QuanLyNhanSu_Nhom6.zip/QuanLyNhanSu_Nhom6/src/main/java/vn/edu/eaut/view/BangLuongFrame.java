package vn.edu.eaut.view;

import vn.edu.eaut.connection.DatabaseConnection;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.text.DecimalFormat;
import java.time.LocalDate;

public class BangLuongFrame extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;
    private JButton btnTinhLuong, btnXemPhieuLuong, btnChotLuong, btnHuyChot, btnXuatExcel, btnLamMoi;
    private JComboBox<Integer> cbThang;
    private JComboBox<Integer> cbNam;
    private JTextField txtTimKiem;
    private DecimalFormat currencyFormat = new DecimalFormat("#,###");

    public BangLuongFrame() {
        setLayout(new BorderLayout(0, 12));
        setBackground(new Color(245, 247, 250));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel panelNorth = new JPanel(new BorderLayout());
        panelNorth.setOpaque(false);

        JPanel header = new JPanel();
        header.setOpaque(false);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        JLabel lblTitle = new JLabel("BẢNG LƯƠNG NHÂN SỰ TỰ ĐỘNG (NÂNG CAO)");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(new Color(41, 128, 185));

        JLabel sub = new JLabel("Tự động tổng hợp Chấm công, Nghỉ phép, Tăng ca, Hợp đồng, Phụ cấp và Bảo hiểm, Thuế");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sub.setForeground(Color.GRAY);

        header.add(lblTitle);
        header.add(Box.createVerticalStrut(3));
        header.add(sub);
        panelNorth.add(header, BorderLayout.WEST);

        JPanel panelFilter = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panelFilter.setOpaque(false);

        panelFilter.add(new JLabel("Tìm kiếm:"));
        txtTimKiem = new JTextField();
        txtTimKiem.setPreferredSize(new Dimension(150, 28));
        txtTimKiem.putClientProperty("JTextField.placeholderText", "Mã NV / Họ tên...");
        panelFilter.add(txtTimKiem);

        panelFilter.add(new JLabel("Tháng:"));
        cbThang = new JComboBox<>();
        for (int i = 1; i <= 12; i++) cbThang.addItem(i);
        cbThang.setSelectedItem(LocalDate.now().getMonthValue());
        panelFilter.add(cbThang);

        panelFilter.add(new JLabel("Năm:"));
        cbNam = new JComboBox<>();
        int currentYear = LocalDate.now().getYear();
        for (int i = currentYear - 2; i <= currentYear + 2; i++) cbNam.addItem(i);
        cbNam.setSelectedItem(currentYear);
        panelFilter.add(cbNam);

        panelNorth.add(panelFilter, BorderLayout.EAST);
        add(panelNorth, BorderLayout.NORTH);

        String[] columns = {
                "ID", "Mã NV", "Họ Tên", "Lương CB", "Phụ Cấp", "Thưởng",
                "Tăng Ca", "BHXH", "BHYT", "BHTN", "Thuế TNCN", "Khấu Trừ/Phạt", "Thực Nhận", "Trạng Thái"
        };

        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        table.getTableHeader().setPreferredSize(new Dimension(0, 32));

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setBackground(new Color(41, 128, 185));
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        headerRenderer.setFont(new Font("Segoe UI", Font.BOLD, 12));

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);

        table.getColumnModel().getColumn(0).setPreferredWidth(45);
        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);

        table.getColumnModel().getColumn(1).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);

        table.getColumnModel().getColumn(2).setPreferredWidth(150);

        for (int i = 3; i <= 12; i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(100);
            table.getColumnModel().getColumn(i).setCellRenderer(rightRenderer);
        }

        table.getColumnModel().getColumn(13).setPreferredWidth(90);
        table.getColumnModel().getColumn(13).setCellRenderer(centerRenderer);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                " Chi tiết bảng lương nhân sự ",
                0, 0, new Font("Segoe UI", Font.BOLD, 13), new Color(41, 128, 185)
        ));
        add(scroll, BorderLayout.CENTER);

        JPanel panelButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        panelButtons.setOpaque(false);

        btnTinhLuong = new JButton("Tính Lương Tự Động");
        btnXemPhieuLuong = new JButton("Xem Phiếu Lương");
        btnChotLuong = new JButton("Chốt Bảng Lương");
        btnHuyChot = new JButton("Hủy Chốt");
        btnXuatExcel = new JButton("Xuất Excel");
        btnLamMoi = new JButton("Làm Mới");

        styleButton(btnTinhLuong, new Color(46, 204, 113));
        styleButton(btnXemPhieuLuong, new Color(230, 126, 34));
        styleButton(btnChotLuong, new Color(59, 130, 246));
        styleButton(btnHuyChot, new Color(231, 76, 60));
        styleButton(btnXuatExcel, new Color(155, 89, 182));
        styleButton(btnLamMoi, new Color(52, 152, 219));

        panelButtons.add(btnTinhLuong);
        panelButtons.add(btnXemPhieuLuong);
        panelButtons.add(btnChotLuong);
        panelButtons.add(btnHuyChot);
        panelButtons.add(btnXuatExcel);
        panelButtons.add(btnLamMoi);
        add(panelButtons, BorderLayout.SOUTH);

        loadData();

        btnTinhLuong.addActionListener(e -> {
            thucHienTinhLuongTuDongHangLoat();
            loadData();
        });

        btnXemPhieuLuong.addActionListener(e -> handleXemPhieuLuong());
        cbThang.addActionListener(e -> loadData());
        cbNam.addActionListener(e -> loadData());

        txtTimKiem.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                loadData();
            }
        });

        btnLamMoi.addActionListener(e -> {
            txtTimKiem.setText("");
            loadData();
            table.clearSelection();
        });

        btnChotLuong.addActionListener(e -> handleChotLuong());
        btnHuyChot.addActionListener(e -> handleHuyChot());
        btnXuatExcel.addActionListener(e -> handleXuatExcel());
    }

    private void styleButton(JButton btn, Color bgColor) {
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(160, 32));
    }

    private void thucHienTinhLuongTuDongHangLoat() {
        int thang = (int) cbThang.getSelectedItem();
        int nam = (int) cbNam.getSelectedItem();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sqlNV = "SELECT id, ma_nv, ho_ten, COALESCE(luong_co_ban, 0) AS luong_cb FROM nhan_vien";
            try (PreparedStatement psNV = conn.prepareStatement(sqlNV);
                 ResultSet rsNV = psNV.executeQuery()) {

                while (rsNV.next()) {
                    int nvId = rsNV.getInt("id");
                    double luongCoBan = rsNV.getDouble("luong_cb");

                    double phuCap = layTongTienPhuCapKhauTru(conn, nvId, "Phụ cấp");
                    double khauTru = layTongTienPhuCapKhauTru(conn, nvId, "Khấu trừ");
                    double tangCa = layTienTangCaThucTe(conn, nvId, luongCoBan);
                    double thuong = 0.0;

                    double bhxh = luongCoBan * 0.08;
                    double bhyt = luongCoBan * 0.015;
                    double bhtn = luongCoBan * 0.01;

                    double tongThuNhap = luongCoBan + phuCap + thuong + tangCa;
                    double thuThuNhapChiuThue = tongThuNhap - (bhxh + bhyt + bhtn) - 11000000;
                    double thueTncn = (thuThuNhapChiuThue > 0) ? thuThuNhapChiuThue * 0.05 : 0;

                    double thucNhan = tongThuNhap - bhxh - bhyt - bhtn - thueTncn - khauTru;
                    if (thucNhan < 0) thucNhan = 0;

                    if (!kiemTraDaChot(conn, nvId, thang, nam)) {
                        ghiHoacCapNhatBangLuong(conn, nvId, thang, nam, "Chưa chốt");
                    }
                }
            }
            JOptionPane.showMessageDialog(this, "Đã tính toán và đồng bộ dữ liệu bảng lương thành công cho tháng " + thang + "/" + nam + "!");
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi khi tính lương tự động!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private double layTongTienPhuCapKhauTru(Connection conn, int nvId, String loai) {
        String sql = "SELECT COALESCE(SUM(so_tien), 0) FROM phu_cap_khau_tru WHERE nhan_vien_id = ? AND loai = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, nvId);
            ps.setString(2, loai);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getDouble(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    private double layTienTangCaThucTe(Connection conn, int nvId, double luongCoBan) {
        double tongTienTangCa = 0;
        String sql = "SELECT so_gio, he_so FROM tang_ca WHERE nhan_vien_id = ? AND trang_thai = 'Đã duyệt'";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, nvId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    double soGio = rs.getDouble("so_gio");
                    double heSo = rs.getDouble("he_so");
                    double giaTien1Gio = (luongCoBan / 22.0) / 8.0;
                    tongTienTangCa += soGio * giaTien1Gio * heSo;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tongTienTangCa;
    }

    private boolean kiemTraDaChot(Connection conn, int nvId, int thang, int nam) {
        String sql = "SELECT trang_thai FROM bang_luong WHERE nhan_vien_id = ? AND thang = ? AND nam = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, nvId);
            ps.setInt(2, thang);
            ps.setInt(3, nam);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return "Đã chốt".equals(rs.getString("trang_thai"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private String layTrangThaiLuong(Connection conn, int nvId, int thang, int nam) {
        String sql = "SELECT trang_thai FROM bang_luong WHERE nhan_vien_id = ? AND thang = ? AND nam = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, nvId);
            ps.setInt(2, thang);
            ps.setInt(3, nam);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("trang_thai");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Chưa chốt";
    }

    private void ghiHoacCapNhatBangLuong(Connection conn, int nvId, int thang, int nam, String trangThai) throws SQLException {
        String checkSql = "SELECT id FROM bang_luong WHERE nhan_vien_id = ? AND thang = ? AND nam = ?";
        try (PreparedStatement ps = conn.prepareStatement(checkSql)) {
            ps.setInt(1, nvId);
            ps.setInt(2, thang);
            ps.setInt(3, nam);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String update = "UPDATE bang_luong SET trang_thai = ? WHERE nhan_vien_id = ? AND thang = ? AND nam = ?";
                    try (PreparedStatement psUp = conn.prepareStatement(update)) {
                        psUp.setString(1, trangThai);
                        psUp.setInt(2, nvId);
                        psUp.setInt(3, thang);
                        psUp.setInt(4, nam);
                        psUp.executeUpdate();
                    }
                    return;
                }
            }
        }

        String insert = "INSERT INTO bang_luong (nhan_vien_id, thang, nam, trang_thai) VALUES (?, ?, ?, ?)";
        try (PreparedStatement psIns = conn.prepareStatement(insert)) {
            psIns.setInt(1, nvId);
            psIns.setInt(2, thang);
            psIns.setInt(3, nam);
            psIns.setString(4, trangThai);
            psIns.executeUpdate();
        }
    }

    public void loadData() {
        tableModel.setRowCount(0);

        int selectedMonth = (int) cbThang.getSelectedItem();
        int selectedYear = (int) cbNam.getSelectedItem();
        String keyword = txtTimKiem != null ? txtTimKiem.getText().trim().toLowerCase() : "";

        StringBuilder sql = new StringBuilder(
                "SELECT n.id AS nhan_vien_id, n.ma_nv, n.ho_ten, " +
                        "COALESCE(n.luong_co_ban, 0) AS lc_cb, " +
                        "(SELECT COALESCE(SUM(so_tien), 0) FROM phu_cap_khau_tru pck WHERE pck.nhan_vien_id = n.id AND pck.loai = 'Phụ cấp') AS pc, " +
                        "(SELECT COALESCE(SUM(so_tien), 0) FROM phu_cap_khau_tru pck WHERE pck.nhan_vien_id = n.id AND pck.loai = 'Khấu trừ') AS kt " +
                        "FROM nhan_vien n "
        );

        if (!keyword.isEmpty()) {
            sql.append(" WHERE (LOWER(n.ma_nv) LIKE ? OR LOWER(n.ho_ten) LIKE ?)");
        }

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            if (!keyword.isEmpty()) {
                ps.setString(1, "%" + keyword + "%");
                ps.setString(2, "%" + keyword + "%");
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int nvId = rs.getInt("nhan_vien_id");
                    double luongCoBan = rs.getDouble("lc_cb");
                    double phuCap = rs.getDouble("pc");
                    double thuong = 0.0;
                    double tangCa = layTienTangCaThucTe(conn, nvId, luongCoBan);
                    double khauTruPhat = rs.getDouble("kt");

                    double bhxh = luongCoBan * 0.08;
                    double bhyt = luongCoBan * 0.015;
                    double bhtn = luongCoBan * 0.01;

                    double tongThuNhap = luongCoBan + phuCap + thuong + tangCa;
                    double thuThuNhapChiuThue = tongThuNhap - (bhxh + bhyt + bhtn) - 11000000;
                    double thueTncn = (thuThuNhapChiuThue > 0) ? thuThuNhapChiuThue * 0.05 : 0;

                    double thucNhan = tongThuNhap - bhxh - bhyt - bhtn - thueTncn - khauTruPhat;
                    if (thucNhan < 0) thucNhan = 0;

                    String trangThai = layTrangThaiLuong(conn, nvId, selectedMonth, selectedYear);

                    Object[] row = {
                            nvId,
                            rs.getString("ma_nv"),
                            rs.getString("ho_ten"),
                            currencyFormat.format(luongCoBan),
                            currencyFormat.format(phuCap),
                            currencyFormat.format(thuong),
                            currencyFormat.format(tangCa),
                            currencyFormat.format(bhxh),
                            currencyFormat.format(bhyt),
                            currencyFormat.format(bhtn),
                            currencyFormat.format(thueTncn),
                            currencyFormat.format(khauTruPhat),
                            currencyFormat.format(thucNhan),
                            trangThai
                    };
                    tableModel.addRow(row);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void handleXemPhieuLuong() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một nhân viên trong bảng để xem phiếu lương!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String maNv = tableModel.getValueAt(selectedRow, 1).toString();
        String hoTen = tableModel.getValueAt(selectedRow, 2).toString();
        String luongCb = tableModel.getValueAt(selectedRow, 3).toString();
        String phuCap = tableModel.getValueAt(selectedRow, 4).toString();
        String thuong = tableModel.getValueAt(selectedRow, 5).toString();
        String tangCa = tableModel.getValueAt(selectedRow, 6).toString();
        String bhxh = tableModel.getValueAt(selectedRow, 7).toString();
        String bhyt = tableModel.getValueAt(selectedRow, 8).toString();
        String bhtn = tableModel.getValueAt(selectedRow, 9).toString();
        String thueTncn = tableModel.getValueAt(selectedRow, 10).toString();
        String khauTru = tableModel.getValueAt(selectedRow, 11).toString();
        String thucNhan = tableModel.getValueAt(selectedRow, 12).toString();
        String trangThai = tableModel.getValueAt(selectedRow, 13).toString();
        int thang = (int) cbThang.getSelectedItem();
        int nam = (int) cbNam.getSelectedItem();

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Phiếu Lương Nhân Viên", true);
        dialog.setSize(520, 650);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JTextPane txtPhieuLuong = new JTextPane();
        txtPhieuLuong.setContentType("text/html");
        txtPhieuLuong.setEditable(false);

        String htmlContent = "<html><body style='font-family: Segoe UI, sans-serif; padding: 15px; color: #333;'>"
                + "<div style='text-align: center; border-bottom: 2px solid #2980b9; padding-bottom: 10px;'>"
                + "<h2 style='color: #2980b9; margin: 0;'>CÔNG TY QUẢN LÝ NHÂN SỰ EAUT</h2>"
                + "<p style='font-size: 14px; font-weight: bold; margin: 5px 0;'>PHIẾU THANH TOÁN LƯƠNG</p>"
                + "<p style='font-size: 12px; color: #666; margin: 0;'>Tháng: " + thang + " / Năm: " + nam + "</p>"
                + "</div>"
                + "<div style='margin-top: 15px; font-size: 13px;'>"
                + "<table style='width: 100%; margin-bottom: 10px;'>"
                + "<tr><td><b>Mã nhân viên:</b> " + maNv + "</td><td><b>Trạng thái:</b> <span style='color: " + ("Đã chốt".equals(trangThai) ? "green" : "red") + ";'>" + trangThai + "</span></td></tr>"
                + "<tr><td colspan='2'><b>Họ và tên:</b> " + hoTen + "</td></tr>"
                + "</table>"
                + "<hr style='border: 0; border-top: 1px dashed #ccc;'/>"
                + "<table style='width: 100%; font-size: 13px; border-collapse: collapse;'>"
                + "<tr style='background-color: #f2f2f2;'><th style='text-align: left; padding: 6px;'>Khoản mục</th><th style='text-align: right; padding: 6px;'>Số tiền (VNĐ)</th></tr>"
                + "<tr><td style='padding: 5px;'>1. Lương cơ bản</td><td style='text-align: right;'>" + luongCb + "</td></tr>"
                + "<tr><td style='padding: 5px;'>2. Phụ cấp</td><td style='text-align: right;'>" + phuCap + "</td></tr>"
                + "<tr><td style='padding: 5px;'>3. Thưởng</td><td style='text-align: right;'>" + thuong + "</td></tr>"
                + "<tr><td style='padding: 5px;'>4. Tăng ca</td><td style='text-align: right;'>" + tangCa + "</td></tr>"
                + "<tr><td style='padding: 5px; color: #c0392b;'>5. BHXH (8%)</td><td style='text-align: right; color: #c0392b;'>- " + bhxh + "</td></tr>"
                + "<tr><td style='padding: 5px; color: #c0392b;'>6. BHYT (1.5%)</td><td style='text-align: right; color: #c0392b;'>- " + bhyt + "</td></tr>"
                + "<tr><td style='padding: 5px; color: #c0392b;'>7. BHTN (1%)</td><td style='text-align: right; color: #c0392b;'>- " + bhtn + "</td></tr>"
                + "<tr><td style='padding: 5px; color: #c0392b;'>8. Thuế TNCN</td><td style='text-align: right; color: #c0392b;'>- " + thueTncn + "</td></tr>"
                + "<tr><td style='padding: 5px; color: #c0392b;'>9. Khấu trừ / Phạt</td><td style='text-align: right; color: #c0392b;'>- " + khauTru + "</td></tr>"
                + "</table>"
                + "<hr style='border: 0; border-top: 2px solid #2980b9;'/>"
                + "<table style='width: 100%; font-size: 15px; font-weight: bold;'>"
                + "<tr><td style='color: #27ae60;'>THỰC NHẬN:</td><td style='text-align: right; color: #27ae60;'>" + thucNhan + " VNĐ</td></tr>"
                + "</table>"
                + "</div>"
                + "<div style='margin-top: 30px; text-align: center; font-size: 12px; color: #777;'>"
                + "<table style='width: 100%;'>"
                + "<tr><td style='text-align: center;'><b>Người lập bảng</b><br/><br/><br/>(Ký, họ tên)</td>"
                + "<td style='text-align: center;'><b>Xác nhận của nhân viên</b><br/><br/><br/>(Ký, họ tên)</td></tr>"
                + "</table>"
                + "</div>"
                + "</body></html>";

        txtPhieuLuong.setText(htmlContent);
        dialog.add(new JScrollPane(txtPhieuLuong), BorderLayout.CENTER);

        JPanel panelAction = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnInPhieu = new JButton("In / Lưu Phiếu (HTML)");
        styleButton(btnInPhieu, new Color(41, 128, 185));

        btnInPhieu.addActionListener(e -> savePhieuLuongToFile(maNv, hoTen, thang, nam, htmlContent));

        panelAction.add(btnInPhieu);
        dialog.add(panelAction, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }

    private void savePhieuLuongToFile(String maNv, String hoTen, int thang, int nam, String htmlContent) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Lưu Phiếu Lương");
        fileChooser.setFileFilter(new FileNameExtensionFilter("HTML Files (*.html)", "html"));
        fileChooser.setSelectedFile(new File("PhieuLuong_" + maNv + "_Thang_" + thang + "_" + nam + ".html"));

        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            if (!fileToSave.getAbsolutePath().endsWith(".html")) {
                fileToSave = new File(fileToSave.getAbsolutePath() + ".html");
            }

            try (FileOutputStream fos = new FileOutputStream(fileToSave);
                 OutputStreamWriter osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
                 PrintWriter pw = new PrintWriter(osw)) {

                fos.write(0xEF);
                fos.write(0xBB);
                fos.write(0xBF);
                pw.print(htmlContent);

                JOptionPane.showMessageDialog(this, "Lưu phiếu lương thành công tại:\n" + fileToSave.getAbsolutePath());
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi khi lưu phiếu lương!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleChotLuong() {
        int selectedRow = table.getSelectedRow();
        int month = (int) cbThang.getSelectedItem();
        int year = (int) cbNam.getSelectedItem();

        try (Connection conn = DatabaseConnection.getConnection()) {
            if (selectedRow != -1) {
                int nvId = Integer.parseInt(tableModel.getValueAt(selectedRow, 0).toString());
                ghiHoacCapNhatBangLuong(conn, nvId, month, year, "Đã chốt");
                tableModel.setValueAt("Đã chốt", selectedRow, 13);
                JOptionPane.showMessageDialog(this, "Đã chốt bảng lương cho nhân viên được chọn!");
            } else {
                int confirm = JOptionPane.showConfirmDialog(this, "Bạn có muốn chốt bảng lương cho toàn bộ danh sách?", "Xác nhận", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    for (int i = 0; i < tableModel.getRowCount(); i++) {
                        int nvId = Integer.parseInt(tableModel.getValueAt(i, 0).toString());
                        ghiHoacCapNhatBangLuong(conn, nvId, month, year, "Đã chốt");
                        tableModel.setValueAt("Đã chốt", i, 13);
                    }
                    JOptionPane.showMessageDialog(this, "Đã chốt toàn bộ bảng lương thành công!");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi khi chốt bảng lương!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleHuyChot() {
        int selectedRow = table.getSelectedRow();
        int month = (int) cbThang.getSelectedItem();
        int year = (int) cbNam.getSelectedItem();

        try (Connection conn = DatabaseConnection.getConnection()) {
            if (selectedRow != -1) {
                int nvId = Integer.parseInt(tableModel.getValueAt(selectedRow, 0).toString());
                ghiHoacCapNhatBangLuong(conn, nvId, month, year, "Chưa chốt");
                tableModel.setValueAt("Chưa chốt", selectedRow, 13);
                JOptionPane.showMessageDialog(this, "Đã hủy chốt bảng lương cho nhân viên được chọn!");
            } else {
                int confirm = JOptionPane.showConfirmDialog(this, "Bạn có muốn hủy chốt bảng lương toàn bộ danh sách?", "Xác nhận", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    for (int i = 0; i < tableModel.getRowCount(); i++) {
                        int nvId = Integer.parseInt(tableModel.getValueAt(i, 0).toString());
                        ghiHoacCapNhatBangLuong(conn, nvId, month, year, "Chưa chốt");
                        tableModel.setValueAt("Chưa chốt", i, 13);
                    }
                    JOptionPane.showMessageDialog(this, "Đã hủy chốt toàn bộ bảng lương thành công!");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi khi hủy chốt bảng lương!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleXuatExcel() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Xuất Bảng Lương Ra File CSV (Excel)");
        fileChooser.setFileFilter(new FileNameExtensionFilter("CSV Files (*.csv)", "csv"));
        int thang = (int) cbThang.getSelectedItem();
        int nam = (int) cbNam.getSelectedItem();
        fileChooser.setSelectedFile(new File("BangLuong_Thang_" + thang + "_" + nam + ".csv"));

        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            if (!fileToSave.getAbsolutePath().endsWith(".csv")) {
                fileToSave = new File(fileToSave.getAbsolutePath() + ".csv");
            }

            try (FileOutputStream fos = new FileOutputStream(fileToSave);
                 OutputStreamWriter osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
                 PrintWriter pw = new PrintWriter(osw)) {

                fos.write(0xEF);
                fos.write(0xBB);
                fos.write(0xBF);

                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    pw.print("\"" + tableModel.getColumnName(i) + "\"");
                    if (i < tableModel.getColumnCount() - 1) pw.print(",");
                }
                pw.println();

                for (int r = 0; r < tableModel.getRowCount(); r++) {
                    for (int c = 0; c < tableModel.getColumnCount(); c++) {
                        Object val = tableModel.getValueAt(r, c);
                        pw.print("\"" + (val != null ? val.toString() : "") + "\"");
                        if (c < tableModel.getColumnCount() - 1) pw.print(",");
                    }
                    pw.println();
                }

                JOptionPane.showMessageDialog(this, "Xuất file Excel (CSV) thành công tại:\n" + fileToSave.getAbsolutePath());
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi khi xuất file Excel!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}