package vn.edu.eaut.view;

import vn.edu.eaut.connection.DatabaseConnection;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class AuditLogFrame extends JPanel {
    private final JTable tblAuditLog;
    private final DefaultTableModel tableModel;
    private JTextField txtSearch;
    private JComboBox<String> cbUser, cbHanhDong, cbThoiGian;
    private JButton btnLoc, btnXuatExcel, btnReload;

    public AuditLogFrame() {
        setLayout(new BorderLayout(15, 15));
        setBackground(UITheme.BG);
        setBorder(new EmptyBorder(15, 15, 15, 15));

        // --- 1. Tiêu đề phía trên ---
        JPanel panelHeader = new JPanel(new BorderLayout());
        panelHeader.setOpaque(false);

        JLabel lblTitle = new JLabel("Lịch sử thao tác hệ thống (Audit Log)");
        lblTitle.setFont(UITheme.font(Font.BOLD, 20));
        lblTitle.setForeground(UITheme.NAVY);
        panelHeader.add(lblTitle, BorderLayout.WEST);

        // --- 2. Khung bộ lọc (Filter Card Panel) ---
        JPanel panelFilterCard = new JPanel(new GridBagLayout());
        panelFilterCard.setBackground(Color.WHITE);
        panelFilterCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(218, 225, 233)),
                new EmptyBorder(12, 15, 12, 15)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 8, 5, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtSearch = new JTextField();
        styleComponent(txtSearch);
        txtSearch.putClientProperty("JTextField.placeholderText", "Tìm kiếm nội dung chi tiết...");

        cbUser = new JComboBox<>();
        styleComponent(cbUser);

        cbHanhDong = new JComboBox<>();
        styleComponent(cbHanhDong);

        cbThoiGian = new JComboBox<>(new String[]{"Tất cả thời gian", "Hôm nay", "7 ngày gần nhất", "Tháng này"});
        styleComponent(cbThoiGian);

        btnLoc = new JButton("Lọc dữ liệu");
        styleButton(btnLoc, new Color(41, 128, 185));

        btnXuatExcel = new JButton("Xuất Excel");
        styleButton(btnXuatExcel, new Color(46, 204, 113));

        btnReload = new JButton("Làm mới");
        styleButton(btnReload, new Color(108, 117, 125));

        // Hàng 1 của bộ lọc
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        panelFilterCard.add(new JLabel("Từ khóa:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        panelFilterCard.add(txtSearch, gbc);

        gbc.gridx = 2; gbc.weightx = 0;
        panelFilterCard.add(new JLabel("Người dùng:"), gbc);
        gbc.gridx = 3; gbc.weightx = 1.0;
        panelFilterCard.add(cbUser, gbc);

        // Hàng 2 của bộ lọc
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        panelFilterCard.add(new JLabel("Hành động:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        panelFilterCard.add(cbHanhDong, gbc);

        gbc.gridx = 2; gbc.weightx = 0;
        panelFilterCard.add(new JLabel("Thời gian:"), gbc);
        gbc.gridx = 3; gbc.weightx = 1.0;
        panelFilterCard.add(cbThoiGian, gbc);

        // Hàng 3: Các nút chức năng căn phải
        JPanel panelButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panelButtons.setOpaque(false);
        panelButtons.add(btnLoc);
        panelButtons.add(btnXuatExcel);
        panelButtons.add(btnReload);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 4;
        gbc.insets = new Insets(10, 0, 0, 0);
        panelFilterCard.add(panelButtons, gbc);

        JPanel panelNorth = new JPanel(new BorderLayout(0, 10));
        panelNorth.setOpaque(false);
        panelNorth.add(panelHeader, BorderLayout.NORTH);
        panelNorth.add(panelFilterCard, BorderLayout.CENTER);
        add(panelNorth, BorderLayout.NORTH);

        // --- 3. Bảng hiển thị dữ liệu ---
        String[] columns = {"ID", "Họ Tên", "Hành động", "Đối tượng", "Chi tiết", "Thời gian"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblAuditLog = new JTable(tableModel);
        tblAuditLog.setRowHeight(28);
        tblAuditLog.setFont(UITheme.font(Font.PLAIN, 12));
        tblAuditLog.getTableHeader().setFont(UITheme.font(Font.BOLD, 12));
        tblAuditLog.getTableHeader().setPreferredSize(new Dimension(0, 32));

        // Căn chỉnh giao diện cột
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        tblAuditLog.getColumnModel().getColumn(0).setPreferredWidth(60);
        tblAuditLog.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tblAuditLog.getColumnModel().getColumn(5).setPreferredWidth(150);
        tblAuditLog.getColumnModel().getColumn(5).setCellRenderer(centerRenderer);

        JScrollPane scrollPane = new JScrollPane(tblAuditLog);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(218, 225, 233)),
                " Danh sách nhật ký hoạt động hệ thống ",
                0, 0, UITheme.font(Font.BOLD, 13), UITheme.NAVY
        ));
        add(scrollPane, BorderLayout.CENTER);

        // --- 4. Tải dữ liệu & Gắn sự kiện ---
        loadFilterCombos();
        loadData("SELECT * FROM audit_log ORDER BY thoi_gian DESC LIMIT 500");

        btnLoc.addActionListener(e -> applyFilter());
        txtSearch.addActionListener(e -> applyFilter());
        btnReload.addActionListener(e -> {
            resetFilters();
            loadData("SELECT * FROM audit_log ORDER BY thoi_gian DESC LIMIT 500");
        });
        btnXuatExcel.addActionListener(e -> exportToCSV());
    }

    private void styleComponent(JComponent comp) {
        comp.setFont(UITheme.font(Font.PLAIN, 12));
        comp.setPreferredSize(new Dimension(0, 30));
    }

    private void styleButton(JButton btn, Color bgColor) {
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFont(UITheme.font(Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(105, 30));
    }

    // Hàm chuyển đổi tên đối tượng từ dạng mã/tên bảng sang tên tiếng Việt dễ đọc
    private String formatDoiTuong(String rawDoiTuong) {
        if (rawDoiTuong == null) return "";
        switch (rawDoiTuong.trim()) {
            case "TaiKhoan":
                return "Tài khoản";
            case "NhanVien":
                return "Nhân viên";
            case "PhongBan":
                return "Phòng ban";
            case "ChucVu":
                return "Chức vụ";
            case "HopDong":
                return "Hợp đồng";
            case "ChamCong":
                return "Chấm công";
            case "NghiPhep":
                return "Nghỉ phép";
            case "TangCa":
                return "Tăng ca";
            case "PhuCap":
                return "Phụ cấp & Khấu trừ";
            case "Luong":
            case "BangLuong":
                return "Bảng lương";
            default:
                return rawDoiTuong; // Trả về nguyên bản nếu không khớp
        }
    }

    private void loadFilterCombos() {
        cbUser.removeAllItems();
        cbUser.addItem("Tất cả người dùng");
        cbHanhDong.removeAllItems();
        cbHanhDong.addItem("Tất cả hành động");

        try (Connection conn = DatabaseConnection.getConnection()) {
            Statement stmt1 = conn.createStatement();
            ResultSet rs1 = stmt1.executeQuery("SELECT DISTINCT ho_ten FROM audit_log WHERE ho_ten IS NOT NULL");
            while (rs1.next()) {
                cbUser.addItem(rs1.getString("ho_ten"));
            }

            Statement stmt2 = conn.createStatement();
            ResultSet rs2 = stmt2.executeQuery("SELECT DISTINCT hanh_dong FROM audit_log WHERE hanh_dong IS NOT NULL");
            while (rs2.next()) {
                cbHanhDong.addItem(rs2.getString("hanh_dong"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadData(String sql) {
        tableModel.setRowCount(0);
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Object[] row = {
                        rs.getInt("id"),
                        rs.getString("ho_ten"),
                        rs.getString("hanh_dong"),
                        formatDoiTuong(rs.getString("doi_tuong")), // <--- Đã áp dụng hàm chuyển đổi tiếng Việt
                        rs.getString("chi_tiet"),
                        rs.getTimestamp("thoi_gian")
                };
                tableModel.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi tải dữ liệu audit log: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void applyFilter() {
        StringBuilder sql = new StringBuilder("SELECT * FROM audit_log WHERE 1=1");

        String keyword = txtSearch.getText().trim();
        if (!keyword.isEmpty()) {
            sql.append(" AND (chi_tiet LIKE '%").append(keyword).append("%' OR doi_tuong LIKE '%").append(keyword).append("%')");
        }

        String selectedUser = (String) cbUser.getSelectedItem();
        if (selectedUser != null && !selectedUser.equals("Tất cả người dùng")) {
            sql.append(" AND ho_ten = '").append(selectedUser).append("'");
        }

        String selectedAction = (String) cbHanhDong.getSelectedItem();
        if (selectedAction != null && !selectedAction.equals("Tất cả hành động")) {
            sql.append(" AND hanh_dong = '").append(selectedAction).append("'");
        }

        String selectedTime = (String) cbThoiGian.getSelectedItem();
        if (selectedTime != null) {
            if (selectedTime.equals("Hôm nay")) {
                sql.append(" AND DATE(thoi_gian) = CURDATE()");
            } else if (selectedTime.equals("7 ngày gần nhất")) {
                sql.append(" AND thoi_gian >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
            } else if (selectedTime.equals("Tháng này")) {
                sql.append(" AND MONTH(thoi_gian) = MONTH(NOW()) AND YEAR(thoi_gian) = YEAR(NOW())");
            }
        }

        sql.append(" ORDER BY thoi_gian DESC LIMIT 500");
        loadData(sql.toString());
    }

    private void resetFilters() {
        txtSearch.setText("");
        if (cbUser.getItemCount() > 0) cbUser.setSelectedIndex(0);
        if (cbHanhDong.getItemCount() > 0) cbHanhDong.setSelectedIndex(0);
        cbThoiGian.setSelectedIndex(0);
    }

    private void exportToCSV() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Xuất file Lịch sử thao tác");
        fileChooser.setSelectedFile(new File("AuditLog_Report.csv"));

        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (PrintWriter pw = new PrintWriter(file, StandardCharsets.UTF_8)) {
                pw.write('\ufeff');

                for (int i = 0; i < tblAuditLog.getColumnCount(); i++) {
                    pw.print("\"" + tblAuditLog.getColumnName(i) + "\"");
                    if (i < tblAuditLog.getColumnCount() - 1) pw.print(",");
                }
                pw.println();

                for (int r = 0; r < tblAuditLog.getRowCount(); r++) {
                    for (int c = 0; c < tblAuditLog.getColumnCount(); c++) {
                        Object val = tblAuditLog.getValueAt(r, c);
                        pw.print("\"" + (val != null ? val.toString().replace("\"", "\"\"") : "") + "\"");
                        if (c < tblAuditLog.getColumnCount() - 1) pw.print(",");
                    }
                    pw.println();
                }

                JOptionPane.showMessageDialog(this, "Xuất file Excel thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi khi xuất file: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}