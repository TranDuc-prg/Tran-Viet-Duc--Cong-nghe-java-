package vn.edu.eaut.view;

import vn.edu.eaut.connection.DatabaseConnection;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.text.DecimalFormat;

public class PhuCapFrame extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField txtMaNV, txtTenKhoan, txtSoTien;
    private JComboBox<String> cbLoai;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi;
    private DecimalFormat currencyFormat = new DecimalFormat("#,###");

    public PhuCapFrame() {
        setLayout(new BorderLayout(12, 12));
        setBackground(UITheme.BG);
        setBorder(new EmptyBorder(12, 12, 12, 12));

        // Header Tiêu đề
        JPanel header = new JPanel();
        header.setOpaque(false);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        JLabel lblHeader = UITheme.sectionTitle("Phụ cấp & khấu trừ");
        JLabel sub = UITheme.sectionSubtitle("Quản lý các khoản cộng thêm và khấu trừ vào thu nhập");
        header.add(lblHeader);
        header.add(Box.createVerticalStrut(3));
        header.add(sub);
        add(header, BorderLayout.NORTH);

        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setBackground(Color.WHITE);
        panelForm.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                new EmptyBorder(12, 12, 12, 12)
        ));
        panelForm.setPreferredSize(new Dimension(340, 0));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        panelForm.add(new JLabel("Mã Nhân Viên:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtMaNV = new JTextField(15);
        panelForm.add(txtMaNV, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        panelForm.add(new JLabel("Loại khoản:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        cbLoai = new JComboBox<>(new String[]{"Phụ cấp", "Khấu trừ"});
        panelForm.add(cbLoai, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0;
        panelForm.add(new JLabel("Tên khoản:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtTenKhoan = new JTextField(15);
        panelForm.add(txtTenKhoan, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0;
        panelForm.add(new JLabel("Số tiền (VNĐ):"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtSoTien = new JTextField(15);
        panelForm.add(txtSoTien, gbc);

        // Nút bấm
        JPanel panelButtons = new JPanel(new GridLayout(2, 2, 8, 8));
        panelButtons.setOpaque(false);

        btnThem = new JButton("Thêm");
        btnSua = new JButton("Sửa");
        btnXoa = new JButton("Xóa");
        btnLamMoi = new JButton("Làm mới");

        // Áp dụng style chuẩn màu
        styleButton(btnThem, UITheme.GREEN);
        styleButton(btnSua, new Color(230, 126, 34));
        styleButton(btnXoa, new Color(231, 76, 60));
        styleButton(btnLamMoi, UITheme.NAVY_2);

        panelButtons.add(btnThem);
        panelButtons.add(btnSua);
        panelButtons.add(btnXoa);
        panelButtons.add(btnLamMoi);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        gbc.insets = new Insets(15, 8, 8, 8);
        panelForm.add(panelButtons, gbc);

        // Đẩy form dồn lên trên
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2; gbc.weighty = 1.0;
        panelForm.add(new JLabel(""), gbc);

        add(panelForm, BorderLayout.WEST);

        tableModel = new DefaultTableModel(new String[]{"ID", "Mã NV", "Loại", "Tên Khoản", "Số Tiền"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        UITheme.styleTable(table);

        // FIX TIÊU ĐỀ BẢNG MẤT CHỮ:
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setPreferredSize(new Dimension(0, 30));

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setBackground(new Color(41, 128, 185));
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        headerRenderer.setFont(new Font("Segoe UI", Font.BOLD, 13));

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }

        // Định dạng căn lề các cột
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);

        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(1).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(2).setPreferredWidth(90);
        table.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(UITheme.BORDER));
        add(scrollPane, BorderLayout.CENTER);

        loadDataToTable();

        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    txtMaNV.setText(tableModel.getValueAt(row, 1).toString());
                    cbLoai.setSelectedItem(tableModel.getValueAt(row, 2).toString());
                    txtTenKhoan.setText(tableModel.getValueAt(row, 3).toString());

                    String rawVal = tableModel.getValueAt(row, 4).toString().replace(" VNĐ", "").replace(",", "").trim();
                    txtSoTien.setText(rawVal);
                }
            }
        });

        // Sự kiện các nút
        btnThem.addActionListener(e -> handleAdd());
        btnSua.addActionListener(e -> handleUpdate());
        btnXoa.addActionListener(e -> handleDelete());
        btnLamMoi.addActionListener(e -> {
            clearForm();
            loadDataToTable();
        });
    }

    private void styleButton(JButton btn, Color bgColor) {
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void loadDataToTable() {
        tableModel.setRowCount(0);
        // Sử dụng JOIN để lấy ma_nv từ bảng nhan_vien dựa trên nhan_vien_id
        String sql = "SELECT p.*, n.ma_nv FROM phu_cap_khau_tru p LEFT JOIN nhan_vien n ON p.nhan_vien_id = n.id";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                double val = rs.getDouble("so_tien");
                tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("ma_nv"),
                        rs.getString("loai"),
                        rs.getString("ten_khoan"),
                        currencyFormat.format(val) + " VNĐ"
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void handleAdd() {
        String maNV = txtMaNV.getText().trim();
        String tenKhoan = txtTenKhoan.getText().trim();
        String soTienStr = txtSoTien.getText().trim();

        if (maNV.isEmpty() || tenKhoan.isEmpty() || soTienStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Tìm id của nhân viên dựa vào ma_nv nhập vào
            String sqlFindId = "SELECT id FROM nhan_vien WHERE ma_nv = ?";
            int nhanVienId = -1;
            try (PreparedStatement pstmtFind = conn.prepareStatement(sqlFindId)) {
                pstmtFind.setString(1, maNV);
                try (ResultSet rs = pstmtFind.executeQuery()) {
                    if (rs.next()) {
                        nhanVienId = rs.getInt("id");
                    }
                }
            }

            if (nhanVienId == -1) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy mã nhân viên này trong hệ thống!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String sqlInsert = "INSERT INTO phu_cap_khau_tru (nhan_vien_id, loai, ten_khoan, so_tien) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sqlInsert)) {
                pstmt.setInt(1, nhanVienId);
                pstmt.setString(2, cbLoai.getSelectedItem().toString());
                pstmt.setString(3, tenKhoan);
                pstmt.setDouble(4, Double.parseDouble(soTienStr));
                pstmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Thêm thành công!");
                loadDataToTable();
                clearForm();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi thêm dữ liệu (Kiểm tra lại định dạng số tiền)!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleUpdate() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn dòng cần sửa trên bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = Integer.parseInt(tableModel.getValueAt(row, 0).toString());
        String maNV = txtMaNV.getText().trim();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sqlFindId = "SELECT id FROM nhan_vien WHERE ma_nv = ?";
            int nhanVienId = -1;
            try (PreparedStatement pstmtFind = conn.prepareStatement(sqlFindId)) {
                pstmtFind.setString(1, maNV);
                try (ResultSet rs = pstmtFind.executeQuery()) {
                    if (rs.next()) {
                        nhanVienId = rs.getInt("id");
                    }
                }
            }

            if (nhanVienId == -1) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy mã nhân viên này trong hệ thống!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String sqlUpdate = "UPDATE phu_cap_khau_tru SET nhan_vien_id = ?, loai = ?, ten_khoan = ?, so_tien = ? WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sqlUpdate)) {
                pstmt.setInt(1, nhanVienId);
                pstmt.setString(2, cbLoai.getSelectedItem().toString());
                pstmt.setString(3, txtTenKhoan.getText().trim());
                pstmt.setDouble(4, Double.parseDouble(txtSoTien.getText().trim()));
                pstmt.setInt(5, id);
                pstmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Cập nhật thành công!");
                loadDataToTable();
                clearForm();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi cập nhật dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleDelete() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn dòng cần xóa trên bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = Integer.parseInt(tableModel.getValueAt(row, 0).toString());
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement("DELETE FROM phu_cap_khau_tru WHERE id = ?")) {
                pstmt.setInt(1, id);
                pstmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Xóa thành công!");
                loadDataToTable();
                clearForm();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private void clearForm() {
        txtMaNV.setText("");
        cbLoai.setSelectedIndex(0);
        txtTenKhoan.setText("");
        txtSoTien.setText("");
        table.clearSelection();
    }
}