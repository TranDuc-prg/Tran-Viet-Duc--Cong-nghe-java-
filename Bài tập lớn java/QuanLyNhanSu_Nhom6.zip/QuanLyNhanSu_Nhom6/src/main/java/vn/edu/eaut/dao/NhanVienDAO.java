package vn.edu.eaut.dao;

import org.mindrot.jbcrypt.BCrypt;
import vn.edu.eaut.connection.DatabaseConnection;
import vn.edu.eaut.model.NhanVien;
import vn.edu.eaut.model.NhanVienTrangThaiDTO;
import vn.edu.eaut.model.UserSession;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class NhanVienDAO {

    public List<NhanVien> getAllNhanVien() {
        List<NhanVien> list = new ArrayList<>();
        String sql = "SELECT * FROM nhan_vien";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                NhanVien nv = new NhanVien();
                nv.setId(rs.getInt("id"));
                nv.setMaNv(rs.getString("ma_nv"));
                nv.setHoTen(rs.getString("ho_ten"));
                nv.setGioiTinh(rs.getString("gioi_tinh"));
                nv.setNgaySinh(rs.getDate("ngay_sinh"));
                nv.setDienThoai(rs.getString("dien_thoai"));
                nv.setEmail(rs.getString("email"));
                nv.setPhongBanId(rs.getInt("phong_ban_id"));
                nv.setLuongCoBan(rs.getDouble("luong_co_ban"));
                nv.setTrangThai(rs.getString("trang_thai"));

                list.add(nv);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<NhanVienTrangThaiDTO> getDanhSachNhanVienTrangThai() {
        List<NhanVienTrangThaiDTO> list = new ArrayList<>();
        String sql = "SELECT nv.ma_nv, nv.ho_ten, pb.ten_phong_ban, " +
                "nv.trang_thai AS trang_thai_nhan_vien, " +
                "cc.trang_thai AS trang_thai_cham_cong, cc.ngay_gio AS thoi_gian_cham_cong " +
                "FROM nhan_vien nv " +
                "LEFT JOIN phong_ban pb ON nv.phong_ban_id = pb.id " +
                "LEFT JOIN (" +
                "    SELECT nhan_vien_id, trang_thai, ngay_gio, " +
                "           ROW_NUMBER() OVER(PARTITION BY nhan_vien_id ORDER BY ngay_gio DESC) as rk " +
                "    FROM cham_cong" +
                ") cc ON nv.id = cc.nhan_vien_id AND cc.rk = 1";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                NhanVienTrangThaiDTO dto = new NhanVienTrangThaiDTO();
                dto.setMaNv(rs.getString("ma_nv"));
                dto.setHoTen(rs.getString("ho_ten"));
                dto.setTenPhongBan(rs.getString("ten_phong_ban"));
                dto.setTrangThaiNhanVien(rs.getString("trang_thai_nhan_vien"));
                dto.setTrangThaiChamCong(rs.getString("trang_thai_cham_cong"));
                dto.setThoiGianChamCong(rs.getString("thoi_gian_cham_cong"));
                list.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean insertNhanVien(NhanVien nv) {
        String sql = "INSERT INTO nhan_vien (ma_nv, ho_ten, gioi_tinh, ngay_sinh, dien_thoai, email, phong_ban_id, luong_co_ban, trang_thai) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nv.getMaNv());
            ps.setString(2, nv.getHoTen());
            ps.setString(3, nv.getGioiTinh());

            if (nv.getNgaySinh() != null) {
                ps.setDate(4, new java.sql.Date(nv.getNgaySinh().getTime()));
            } else {
                ps.setNull(4, java.sql.Types.DATE);
            }

            ps.setString(5, nv.getDienThoai());
            ps.setString(6, nv.getEmail());
            ps.setInt(7, nv.getPhongBanId());
            ps.setDouble(8, nv.getLuongCoBan());
            ps.setString(9, nv.getTrangThai() != null ? nv.getTrangThai() : "Đang làm việc");

            boolean success = ps.executeUpdate() > 0;

            if (success) {
                String currentUser = UserSession.getUsername() != null ? UserSession.getUsername() : "Admin";
                AuditLogDAO.log(
                        currentUser,
                        "INSERT",
                        "NhanVien",
                        "Thêm mới nhân viên: " + nv.getHoTen()
                );
            }

            return success;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateNhanVien(NhanVien nv) {
        String sql = "UPDATE nhan_vien SET ma_nv = ?, ho_ten = ?, gioi_tinh = ?, ngay_sinh = ?, dien_thoai = ?, email = ?, phong_ban_id = ?, luong_co_ban = ?, trang_thai = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nv.getMaNv());
            ps.setString(2, nv.getHoTen());
            ps.setString(3, nv.getGioiTinh());

            if (nv.getNgaySinh() != null) {
                ps.setDate(4, new java.sql.Date(nv.getNgaySinh().getTime()));
            } else {
                ps.setNull(4, java.sql.Types.DATE);
            }

            ps.setString(5, nv.getDienThoai());
            ps.setString(6, nv.getEmail());
            ps.setInt(7, nv.getPhongBanId());
            ps.setDouble(8, nv.getLuongCoBan());
            ps.setString(9, nv.getTrangThai());
            ps.setInt(10, nv.getId());

            boolean success = ps.executeUpdate() > 0;

            if (success) {
                String currentUser = UserSession.getUsername() != null ? UserSession.getUsername() : "Admin";
                AuditLogDAO.log(
                        currentUser,
                        "UPDATE",
                        "NhanVien",
                        "Cập nhật nhân viên ID: " + nv.getId()
                );
            }

            return success;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteNhanVien(int id) {
        String sql = "DELETE FROM nhan_vien WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            boolean success = ps.executeUpdate() > 0;

            if (success) {
                String currentUser = UserSession.getUsername() != null ? UserSession.getUsername() : "Admin";
                AuditLogDAO.log(
                        currentUser,
                        "DELETE",
                        "NhanVien",
                        "Xóa nhân viên ID: " + id
                );
            }

            return success;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public String checkLogin(String username, String password) {
        String sql = "SELECT password, role FROM tai_khoan WHERE username = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String hashedPassword = rs.getString("password");
                    String role = rs.getString("role");

                    if (hashedPassword != null && hashedPassword.startsWith("$2")) {
                        if (BCrypt.checkpw(password, hashedPassword)) {
                            return role;
                        }
                    } else if (password.equals(hashedPassword)) {
                        return role;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean registerAccount(String username, String password) {
        String checkSql = "SELECT * FROM tai_khoan WHERE username = ?";
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt(10));
        String insertSql = "INSERT INTO tai_khoan (username, password, role) VALUES (?, ?, 'USER')";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement checkPs = conn.prepareStatement(checkSql)) {

            checkPs.setString(1, username);
            try (ResultSet rs = checkPs.executeQuery()) {
                if (rs.next()) {
                    return false;
                }
            }

            try (PreparedStatement insertPs = conn.prepareStatement(insertSql)) {
                insertPs.setString(1, username);
                insertPs.setString(2, hashedPassword);
                return insertPs.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Tìm ID nhân viên tương ứng với tài khoản đăng nhập.
     * Ưu tiên mã nhân viên, đồng thời hỗ trợ email/số điện thoại.
     */
    public int getNhanVienIdByUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            return -1;
        }

        String sql = "SELECT id FROM nhan_vien " +
                "WHERE ma_nv = ? OR email = ? OR dien_thoai = ? " +
                "ORDER BY CASE " +
                "WHEN ma_nv = ? THEN 1 " +
                "WHEN email = ? THEN 2 " +
                "WHEN dien_thoai = ? THEN 3 ELSE 4 END " +
                "LIMIT 1";

        String value = username.trim();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, value);
            ps.setString(2, value);
            ps.setString(3, value);
            ps.setString(4, value);
            ps.setString(5, value);
            ps.setString(6, value);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;
    }

    public boolean saveChamCong(int nhanVienId) {
        String sql = "INSERT INTO cham_cong (nhan_vien_id, ngay_gio, trang_thai) VALUES (?, NOW(), 'Đúng giờ')";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, nhanVienId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}