package vn.edu.eaut.service;

import vn.edu.eaut.connection.DatabaseConnection;
import vn.edu.eaut.dao.LuongDAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ThongKeService {

    private final LuongDAO luongDAO = new LuongDAO();

    public int getTongNhanVien() {
        String sql = "SELECT COUNT(*) FROM nhan_vien";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public int getTongPhongBan() {
        String sql = "SELECT COUNT(*) FROM phong_ban";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public int getChamCongHomNay() {
        String sql = "SELECT COUNT(DISTINCT nhan_vien_id) FROM cham_cong WHERE DATE(ngay_gio) = CURDATE()";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public int getDonChoDuyet() {
        String sql = "SELECT " +
                "(SELECT COUNT(*) FROM nghi_phep WHERE trang_thai = 'Chờ duyệt') + " +
                "(SELECT COUNT(*) FROM tang_ca WHERE trang_thai = 'Chờ duyệt') AS total";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt("total");
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public List<String> getHoạtDongGầnĐây() {
        List<String> list = new ArrayList<>();
        String sql = "SELECT nv.ho_ten, cc.trang_thai, cc.ngay_gio FROM cham_cong cc " +
                "JOIN nhan_vien nv ON cc.nhan_vien_id = nv.id " +
                "ORDER BY cc.ngay_gio DESC LIMIT 5";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String ten = rs.getString("ho_ten");
                String trangThai = rs.getString("trang_thai");
                String thoiGian = rs.getString("ngay_gio");
                list.add(" • Nhân sự " + ten + " đã thực hiện: " + trangThai + " (" + thoiGian + ")");
            }
        } catch (SQLException e) { e.printStackTrace(); }

        if (list.isEmpty()) {
            list.add(" • Chưa có hoạt động chấm công nào trong cơ sở dữ liệu hôm nay.");
        }
        return list;
    }

    public List<String> getCanhBaoHeThong() {
        List<String> list = new ArrayList<>();
        int nghiPhep = 0, tangCa = 0;

        String sql1 = "SELECT COUNT(*) FROM nghi_phep WHERE trang_thai = 'Chờ duyệt'";
        String sql2 = "SELECT COUNT(*) FROM tang_ca WHERE trang_thai = 'Chờ duyệt'";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement()) {
            ResultSet rs1 = st.executeQuery(sql1);
            if (rs1.next()) nghiPhep = rs1.getInt(1);

            ResultSet rs2 = st.executeQuery(sql2);
            if (rs2.next()) tangCa = rs2.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }

        if (nghiPhep > 0) {
            list.add("⚠ Có " + nghiPhep + " đơn nghỉ phép mới đang chờ cấp trên phê duyệt.");
        }
        if (tangCa > 0) {
            list.add("⚠ Có " + tangCa + " yêu cầu đăng ký tăng ca cần được xem xét.");
        }
        if (list.isEmpty()) {
            list.add("✔ Hệ thống ổn định, không có cảnh báo hoặc đơn chờ quá hạn.");
        }
        return list;
    }

    public Map<String, Integer> getNhanVienTheoPhongBan(String phongBanFilter, String tuNgay, String denNgay) {
        Map<String, Integer> map = new LinkedHashMap<>();

        StringBuilder sql = new StringBuilder(
                "SELECT pb.ten_phong_ban, COUNT(nv.id) AS tong_nv " +
                        "FROM phong_ban pb " +
                        "LEFT JOIN nhan_vien nv ON pb.id = nv.phong_ban_id WHERE 1=1"
        );

        boolean hasPhongBan = phongBanFilter != null && !phongBanFilter.isEmpty() && !phongBanFilter.equals("Tất cả");
        boolean hasTuNgay = tuNgay != null && !tuNgay.isEmpty();
        boolean hasDenNgay = denNgay != null && !denNgay.isEmpty();

        if (hasPhongBan) {
            sql.append(" AND pb.ten_phong_ban = ?");
        }
        if (hasTuNgay) {
            sql.append(" AND nv.ngay_vao_lam >= ?");
        }
        if (hasDenNgay) {
            sql.append(" AND nv.ngay_vao_lam <= ?");
        }

        sql.append(" GROUP BY pb.id, pb.ten_phong_ban");

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            int index = 1;
            if (hasPhongBan) {
                ps.setString(index++, phongBanFilter);
            }
            if (hasTuNgay) {
                ps.setString(index++, tuNgay);
            }
            if (hasDenNgay) {
                ps.setString(index++, denNgay);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    map.put(rs.getString("ten_phong_ban"), rs.getInt("tong_nv"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return map;
    }

    public Map<Integer, Double> getMucLuongTrungBinh5Nam() {
        return luongDAO.getMucLuongTrungBinh5Nam();
    }
}