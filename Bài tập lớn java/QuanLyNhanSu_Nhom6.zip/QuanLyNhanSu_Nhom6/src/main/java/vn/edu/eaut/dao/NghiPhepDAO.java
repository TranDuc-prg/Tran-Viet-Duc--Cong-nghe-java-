package vn.edu.eaut.dao;

import vn.edu.eaut.connection.DatabaseConnection;
import vn.edu.eaut.model.NghiPhep;
import vn.edu.eaut.model.UserSession;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NghiPhepDAO {

    public List<NghiPhep> getAll() {
        List<NghiPhep> list = new ArrayList<>();
        String sql = "SELECT p.id, p.nhan_vien_id, n.ma_nv, n.ho_ten, p.ngay_bat_dau, p.ngay_ket_thuc, " +
                "p.so_ngay_nghi, p.ly_do, p.trang_thai " +
                "FROM nghi_phep p " +
                "JOIN nhan_vien n ON p.nhan_vien_id = n.id " +
                "ORDER BY p.id DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                NghiPhep np = new NghiPhep();
                np.setId(rs.getInt("id"));
                np.setNhanVienId(rs.getInt("nhan_vien_id"));
                np.setMaNv(rs.getString("ma_nv"));
                np.setHoTen(rs.getString("ho_ten"));
                np.setNgayBatDau(rs.getString("ngay_bat_dau"));
                np.setNgayKetThuc(rs.getString("ngay_ket_thuc"));
                np.setSoNgayNghi(rs.getInt("so_ngay_nghi"));
                np.setLyDo(rs.getString("ly_do"));
                np.setTrangThai(rs.getString("trang_thai"));
                list.add(np);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public int getNhanVienIdByMaNv(String maNv) {
        String sql = "SELECT id FROM nhan_vien WHERE ma_nv = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maNv);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public boolean insert(NghiPhep np) {
        String sql = "INSERT INTO nghi_phep (nhan_vien_id, ngay_bat_dau, ngay_ket_thuc, so_ngay_nghi, ly_do, trang_thai) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, np.getNhanVienId());
            ps.setString(2, np.getNgayBatDau());
            ps.setString(3, np.getNgayKetThuc());
            ps.setInt(4, np.getSoNgayNghi());
            ps.setString(5, np.getLyDo());
            ps.setString(6, np.getTrangThai());

            boolean success = ps.executeUpdate() > 0;
            if (success) {
                String currentUser = UserSession.getUsername() != null ? UserSession.getUsername() : "Admin";
                AuditLogDAO.log(
                        currentUser,
                        "INSERT",
                        "NghiPhep",
                        "Tạo đơn nghỉ phép"
                );
            }
            return success;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean update(NghiPhep np) {
        String sql = "UPDATE nghi_phep SET ngay_bat_dau = ?, ngay_ket_thuc = ?, ly_do = ?, trang_thai = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, np.getNgayBatDau());
            ps.setString(2, np.getNgayKetThuc());
            ps.setString(3, np.getLyDo());
            ps.setString(4, np.getTrangThai());
            ps.setInt(5, np.getId());

            boolean success = ps.executeUpdate() > 0;
            if (success) {
                String currentUser = UserSession.getUsername() != null ? UserSession.getUsername() : "Admin";
                AuditLogDAO.log(
                        currentUser,
                        "UPDATE",
                        "NghiPhep",
                        "Cập nhật đơn nghỉ phép ID: " + np.getId()
                );
            }
            return success;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateTrangThai(int id, String trangThaiMoi) {
        String sql = "UPDATE nghi_phep SET trang_thai = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, trangThaiMoi);
            ps.setInt(2, id);

            boolean success = ps.executeUpdate() > 0;
            if (success) {
                String currentUser = UserSession.getUsername() != null ? UserSession.getUsername() : "Admin";
                AuditLogDAO.log(
                        currentUser,
                        "APPROVE_REJECT",
                        "NghiPhep",
                        "Đổi trạng thái đơn ID " + id + " thành " + trangThaiMoi
                );
            }
            return success;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM nghi_phep WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);

            boolean success = ps.executeUpdate() > 0;
            if (success) {
                String currentUser = UserSession.getUsername() != null ? UserSession.getUsername() : "Admin";
                AuditLogDAO.log(
                        currentUser,
                        "DELETE",
                        "NghiPhep",
                        "Xóa đơn nghỉ phép ID: " + id
                );
            }
            return success;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}