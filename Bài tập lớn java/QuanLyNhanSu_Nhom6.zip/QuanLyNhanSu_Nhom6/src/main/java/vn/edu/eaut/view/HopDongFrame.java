package vn.edu.eaut.view;

import vn.edu.eaut.connection.DatabaseConnection;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.sql.*;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class HopDongFrame extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField txtMaHD, txtLuong, txtNgayBD, txtNgayKT;
    private JComboBox<String> cbNhanVien, cbLoaiHD, cbTrangThai;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi, btnChiTiet, btnThongKe, btnIn, btnInHopDong, btnXuatExcel;
    private JPanel panelCanhBaoContent;

    public HopDongFrame() {
        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(new Color(245, 247, 250));

        // Tiêu đề
        JLabel lblHeader = new JLabel("QUẢN LÝ THÔNG TIN HỢP ĐỒNG LAO ĐỘNG", JLabel.CENTER);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblHeader.setForeground(new Color(41, 128, 185));
        lblHeader.setBorder(new EmptyBorder(0, 0, 5, 0));
        add(lblHeader, BorderLayout.NORTH);

        // --- Panel bên trái chứa Form và Khung Cảnh Báo ---
        JPanel panelLeftContainer = new JPanel(new BorderLayout(0, 10));
        panelLeftContainer.setOpaque(false);
        panelLeftContainer.setPreferredSize(new Dimension(360, 0));

        // 1. Form nhập liệu
        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setBackground(Color.WHITE);
        panelForm.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(200, 200, 200)),
                        " Chi tiết hợp đồng ",
                        0, 0, new Font("Segoe UI", Font.BOLD, 13), new Color(41, 128, 185)
                ),
                new EmptyBorder(10, 10, 10, 10)
        ));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; panelForm.add(createLabel("Mã hợp đồng:"), gbc);
        gbc.gridx = 1; txtMaHD = new JTextField(15); styleTextField(txtMaHD); panelForm.add(txtMaHD, gbc);

        gbc.gridx = 0; gbc.gridy = 1; panelForm.add(createLabel("Nhân viên:"), gbc);
        gbc.gridx = 1; cbNhanVien = new JComboBox<>(); loadNhanVienCombobox(); styleComboBox(cbNhanVien); panelForm.add(cbNhanVien, gbc);

        gbc.gridx = 0; gbc.gridy = 2; panelForm.add(createLabel("Loại hợp đồng:"), gbc);
        gbc.gridx = 1; cbLoaiHD = new JComboBox<>(new String[]{"Thử việc", "Xác định thời hạn", "Không xác định thời hạn"}); styleComboBox(cbLoaiHD); panelForm.add(cbLoaiHD, gbc);

        gbc.gridx = 0; gbc.gridy = 3; panelForm.add(createLabel("Ngày bắt đầu (YYYY-MM-DD):"), gbc);
        gbc.gridx = 1; txtNgayBD = new JTextField(15); styleTextField(txtNgayBD); panelForm.add(txtNgayBD, gbc);

        gbc.gridx = 0; gbc.gridy = 4; panelForm.add(createLabel("Ngày kết thúc (YYYY-MM-DD):"), gbc);
        gbc.gridx = 1; txtNgayKT = new JTextField(15); styleTextField(txtNgayKT); panelForm.add(txtNgayKT, gbc);

        gbc.gridx = 0; gbc.gridy = 5; panelForm.add(createLabel("Mức lương HĐ:"), gbc);
        gbc.gridx = 1; txtLuong = new JTextField(15); styleTextField(txtLuong); panelForm.add(txtLuong, gbc);

        gbc.gridx = 0; gbc.gridy = 6; panelForm.add(createLabel("Trạng thái:"), gbc);
        gbc.gridx = 1; cbTrangThai = new JComboBox<>(new String[]{"Hiệu lực", "Hết hiệu lực", "Đã thanh lý"}); styleComboBox(cbTrangThai); panelForm.add(cbTrangThai, gbc);

        // Panel chứa các nút chức năng (5 hàng x 2 cột = 10 nút)
        JPanel panelButtons = new JPanel(new GridLayout(5, 2, 6, 6));
        panelButtons.setBackground(Color.WHITE);
        btnThem = new JButton("Thêm mới");
        btnSua = new JButton("Cập nhật");
        btnXoa = new JButton("Xóa bỏ");
        btnLamMoi = new JButton("Làm mới");
        btnChiTiet = new JButton("Xem chi tiết");
        btnThongKe = new JButton("Thống kê HĐ");
        btnIn = new JButton("In danh sách");
        btnInHopDong = new JButton("In hợp đồng");
        btnXuatExcel = new JButton("Xuất Excel");

        styleButton(btnThem, new Color(46, 204, 113));
        styleButton(btnSua, new Color(230, 126, 34));
        styleButton(btnXoa, new Color(231, 76, 60));
        styleButton(btnLamMoi, new Color(52, 152, 219));
        styleButton(btnChiTiet, new Color(155, 89, 182));
        styleButton(btnThongKe, new Color(26, 188, 156));
        styleButton(btnIn, new Color(52, 73, 94));
        styleButton(btnInHopDong, new Color(41, 128, 185));
        styleButton(btnXuatExcel, new Color(39, 174, 96));

        panelButtons.add(btnThem);
        panelButtons.add(btnSua);
        panelButtons.add(btnXoa);
        panelButtons.add(btnLamMoi);
        panelButtons.add(btnChiTiet);
        panelButtons.add(btnThongKe);
        panelButtons.add(btnIn);
        panelButtons.add(btnInHopDong);
        panelButtons.add(btnXuatExcel);

        gbc.gridx = 0; gbc.gridy = 7; gbc.gridwidth = 2;
        gbc.insets = new Insets(8, 5, 5, 5);
        panelForm.add(panelButtons, gbc);

        panelLeftContainer.add(panelForm, BorderLayout.CENTER);

        // 2. Khung Cảnh Báo Hợp Đồng Sắp Hết Hạn
        JPanel panelCanhBaoOuter = new JPanel(new BorderLayout());
        panelCanhBaoOuter.setBackground(Color.WHITE);
        panelCanhBaoOuter.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(231, 76, 60), 2),
                        " ⚠ CẢNH BÁO HỢP ĐỒNG SẮP HẾT HẠN ",
                        0, 0, new Font("Segoe UI", Font.BOLD, 12), new Color(231, 76, 60)
                ),
                new EmptyBorder(5, 5, 5, 5)
        ));
        panelCanhBaoOuter.setPreferredSize(new Dimension(0, 140));

        panelCanhBaoContent = new JPanel();
        panelCanhBaoContent.setLayout(new BoxLayout(panelCanhBaoContent, BoxLayout.Y_AXIS));
        panelCanhBaoContent.setBackground(Color.WHITE);

        JScrollPane scrollCanhBao = new JScrollPane(panelCanhBaoContent);
        scrollCanhBao.setBorder(null);
        panelCanhBaoOuter.add(scrollCanhBao, BorderLayout.CENTER);

        panelLeftContainer.add(panelCanhBaoOuter, BorderLayout.SOUTH);
        add(panelLeftContainer, BorderLayout.WEST);

        // --- Panel bên phải: Bảng hiển thị danh sách ---
        tableModel = new DefaultTableModel(new String[]{"ID", "Mã HĐ", "Tên Nhân Viên", "Loại HĐ", "Ngày BĐ", "Ngày KT", "Lương", "Trạng Thái"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setSelectionBackground(new Color(210, 230, 245));
        table.setSelectionForeground(Color.BLACK);

        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.setFillsViewportHeight(true);

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                c.setBackground(new Color(52, 152, 219));
                c.setForeground(Color.WHITE);
                setFont(new Font("Segoe UI", Font.BOLD, 13));
                setHorizontalAlignment(JLabel.CENTER);
                return c;
            }
        };
        table.getTableHeader().setDefaultRenderer(headerRenderer);
        table.getTableHeader().setOpaque(false);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(1).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                " Danh sách hợp đồng lao động ",
                0, 0, new Font("Segoe UI", Font.BOLD, 13), new Color(41, 128, 185)
        ));
        add(scrollPane, BorderLayout.CENTER);

        loadDataToTable();
        capNhatDanhSachCanhBao();
        clearForm();

        cbLoaiHD.addActionListener(e -> tuDongTinhNgayKetThuc());

        // Sự kiện chuột trên bảng
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    if (evt.getClickCount() == 2) {
                        hienThiChiTietHopDong();
                    } else {
                        txtMaHD.setText(tableModel.getValueAt(row, 1).toString());

                        String tenNV = tableModel.getValueAt(row, 2).toString();
                        for (int i = 0; i < cbNhanVien.getItemCount(); i++) {
                            String item = cbNhanVien.getItemAt(i);
                            if (item.contains(tenNV)) {
                                cbNhanVien.setSelectedIndex(i);
                                break;
                            }
                        }

                        cbLoaiHD.setSelectedItem(tableModel.getValueAt(row, 3).toString());
                        txtNgayBD.setText(tableModel.getValueAt(row, 4) != null ? tableModel.getValueAt(row, 4).toString() : "");
                        txtNgayKT.setText(tableModel.getValueAt(row, 5) != null ? tableModel.getValueAt(row, 5).toString() : "");

                        Object valLuong = tableModel.getValueAt(row, 6);
                        if (valLuong != null) {
                            String luongStr = valLuong.toString().replace(".", "").replace(",", "").replace("VNĐ", "").trim();
                            txtLuong.setText(luongStr);
                        } else {
                            txtLuong.setText("");
                        }

                        cbTrangThai.setSelectedItem(tableModel.getValueAt(row, 7).toString());
                        txtMaHD.setEditable(false);
                    }
                }
            }
        });

        // Gắn sự kiện cho các nút chức năng
        btnThem.addActionListener(e -> {
            handleAdd();
            capNhatDanhSachCanhBao();
        });
        btnSua.addActionListener(e -> {
            handleUpdate();
            capNhatDanhSachCanhBao();
        });
        btnXoa.addActionListener(e -> {
            handleDelete();
            capNhatDanhSachCanhBao();
        });
        btnLamMoi.addActionListener(e -> {
            clearForm();
            loadNhanVienCombobox();
            loadDataToTable();
            capNhatDanhSachCanhBao();
        });
        btnChiTiet.addActionListener(e -> hienThiChiTietHopDong());
        btnThongKe.addActionListener(e -> hienThiThongKeHopDong());
        btnIn.addActionListener(e -> handlePrintTable());
        btnInHopDong.addActionListener(e -> handlePrintSingleContract());
        btnXuatExcel.addActionListener(e -> handleExportExcel());
    }

    private void handlePrintTable() {
        try {
            boolean complete = table.print(
                    JTable.PrintMode.FIT_WIDTH,
                    new MessageFormat("DANH SÁCH HỢP ĐỒNG LAO ĐỘNG"),
                    new MessageFormat("Trang - {0}")
            );
            if (complete) {
                JOptionPane.showMessageDialog(this, "In danh sách thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Đã hủy lệnh in.", "Thông báo", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi in: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handlePrintSingleContract() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn hợp đồng cần in trên bảng!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int idHopDong = Integer.parseInt(tableModel.getValueAt(selectedRow, 0).toString());
        String sql = "SELECT h.*, n.ma_nv, n.ho_ten, n.email, n.dien_thoai " +
                "FROM hop_dong h JOIN nhan_vien n ON h.nhan_vien_id = n.id " +
                "WHERE h.id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idHopDong);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    JTextPane printPane = new JTextPane();
                    printPane.setContentType("text/html");

                    String htmlContent = "<html>" +
                            "<body style='font-family: Times New Roman; font-size: 13pt; padding: 30px;'>" +
                            "<div style='text-align: center;'><b>CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</b><br><b>Độc lập - Tự do - Hạnh phúc</b><br>---o0o---</div><br>" +
                            "<h2 style='text-align: center;'>HỢP ĐỒNG LAO ĐỘNG</h2>" +
                            "<p style='text-align: center;'><i>Mã số HĐ: " + rs.getString("ma_hop_dong") + "</i></p>" +
                            "<p>Hôm nay, tại văn phòng công ty, chúng tôi gồm các bên sau:</p>" +
                            "<p><b>1. Người sử dụng lao động:</b> Đại diện hệ thống quản lý nhân sự EAUT</p>" +
                            "<p><b>2. Người lao động:</b> " + rs.getString("ho_ten") + " (Mã NV: " + rs.getString("ma_nv") + ")</p>" +
                            "<p>- Điện thoại liên hệ: " + (rs.getString("dien_thoai") != null ? rs.getString("dien_thoai") : "Chưa cập nhật") + "</p>" +
                            "<p><b>Các điều khoản thỏa thuận hợp đồng:</b></p>" +
                            "<ul>" +
                            "<li>Loại hợp đồng: <b>" + rs.getString("loai_hop_dong") + "</b></li>" +
                            "<li>Ngày bắt đầu có hiệu lực: " + rs.getDate("ngay_bat_dau") + "</li>" +
                            "<li>Ngày kết thúc: " + (rs.getDate("ngay_ket_thuc") != null ? rs.getDate("ngay_ket_thuc") : "Không xác định thời hạn") + "</li>" +
                            "<li>Mức lương thỏa thuận: <b>" + String.format("%,.0f VNĐ", rs.getDouble("muc_luong")) + "</b></li>" +
                            "<li>Trạng thái hợp đồng: " + rs.getString("trang_thai") + "</li>" +
                            "</ul>" +
                            "<br><br>" +
                            "<table width='100%'>" +
                            "<tr>" +
                            "<td align='center'><b>NGƯỜI LAO ĐỘNG</b><br><br><br><br>(Ký, ghi rõ họ tên)</td>" +
                            "<td align='center'><b>ĐẠI DIỆN CÔNG TY</b><br><br><br><br>(Ký, đóng dấu)</td>" +
                            "</tr>" +
                            "</table>" +
                            "</body>" +
                            "</html>";

                    printPane.setText(htmlContent);

                    boolean complete = printPane.print(null, null, true, null, null, true);
                    if (complete) {
                        JOptionPane.showMessageDialog(this, "In hợp đồng thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi khi in hợp đồng: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleExportExcel() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Chọn vị trí lưu file Excel");
        fileChooser.setSelectedFile(new File("DanhSachHopDong.csv"));
        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            String filePath = fileToSave.getAbsolutePath();
            if (!filePath.toLowerCase().endsWith(".csv")) {
                filePath += ".csv";
            }

            try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filePath), "UTF-8"))) {
                writer.write("\uFEFF");

                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    writer.write("\"" + tableModel.getColumnName(i) + "\"");
                    if (i < tableModel.getColumnCount() - 1) {
                        writer.write(",");
                    }
                }
                writer.newLine();

                for (int row = 0; row < tableModel.getRowCount(); row++) {
                    for (int col = 0; col < tableModel.getColumnCount(); col++) {
                        Object value = tableModel.getValueAt(row, col);
                        String valStr = value != null ? value.toString().replace("\"", "\"\"") : "";
                        writer.write("\"" + valStr + "\"");
                        if (col < tableModel.getColumnCount() - 1) {
                            writer.write(",");
                        }
                    }
                    writer.newLine();
                }

                JOptionPane.showMessageDialog(this, "Xuất file Excel thành công!\nĐường dẫn: " + filePath, "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi khi xuất file: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void capNhatDanhSachCanhBao() {
        panelCanhBaoContent.removeAll();
        String sql = "SELECT h.*, n.ma_nv, n.ho_ten FROM hop_dong h JOIN nhan_vien n ON h.nhan_vien_id = n.id WHERE h.ngay_ket_thuc IS NOT NULL AND h.trang_thai = 'Hiệu lực'";

        LocalDate today = LocalDate.now();
        boolean hasWarning = false;

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Date ngayKtSql = rs.getDate("ngay_ket_thuc");
                if (ngayKtSql == null) continue;
                LocalDate ngayKT = ngayKtSql.toLocalDate();
                long conLai = ChronoUnit.DAYS.between(today, ngayKT);

                if (conLai <= 30) {
                    hasWarning = true;
                    String maNv = rs.getString("ma_nv");
                    String hoTen = rs.getString("ho_ten");

                    JPanel itemPanel = new JPanel(new BorderLayout(5, 2));
                    itemPanel.setOpaque(true);
                    itemPanel.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));

                    JLabel lblInfo = new JLabel();
                    lblInfo.setFont(new Font("Segoe UI", Font.PLAIN, 11));

                    if (conLai < 0) {
                        itemPanel.setBackground(new Color(253, 237, 236));
                        lblInfo.setForeground(new Color(192, 57, 43));
                        lblInfo.setText("<html><b>" + maNv + " – " + hoTen + "</b><br>Hết hạn: " + ngayKT + " <font color='red'><b>(Đã quá hạn " + Math.abs(conLai) + " ngày)</b></font></html>");
                    } else if (conLai <= 7) {
                        itemPanel.setBackground(new Color(253, 237, 236));
                        lblInfo.setForeground(new Color(192, 57, 43));
                        lblInfo.setText("<html><b>" + maNv + " – " + hoTen + "</b><br>Hết hạn: " + ngayKT + " <font color='red'><b>Còn: " + conLai + " ngày (Cận kề)</b></font></html>");
                    } else {
                        itemPanel.setBackground(new Color(254, 249, 231));
                        lblInfo.setForeground(new Color(180, 100, 0));
                        lblInfo.setText("<html><b>" + maNv + " – " + hoTen + "</b><br>Hết hạn: " + ngayKT + " <font color='#b46400'><b>Sắp hết hạn (Còn: " + conLai + " ngày)</b></font></html>");
                    }

                    itemPanel.add(lblInfo, BorderLayout.CENTER);
                    panelCanhBaoContent.add(itemPanel);
                    panelCanhBaoContent.add(Box.createRigidArea(new Dimension(0, 4)));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (!hasWarning) {
            JLabel lblNoWarning = new JLabel(" Không có hợp đồng nào sắp hết hạn.", JLabel.CENTER);
            lblNoWarning.setFont(new Font("Segoe UI", Font.ITALIC, 11));
            lblNoWarning.setForeground(new Color(120, 120, 120));
            panelCanhBaoContent.add(lblNoWarning);
        }

        panelCanhBaoContent.revalidate();
        panelCanhBaoContent.repaint();
    }

    private void hienThiChiTietHopDong() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn hợp đồng cần xem chi tiết trên bảng!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int idHopDong = Integer.parseInt(tableModel.getValueAt(selectedRow, 0).toString());
        String sql = "SELECT h.*, n.ma_nv, n.ho_ten, n.email, n.dien_thoai " +
                "FROM hop_dong h JOIN nhan_vien n ON h.nhan_vien_id = n.id " +
                "WHERE h.id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idHopDong);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Chi tiết Hợp đồng lao động", true);
                    dialog.setSize(450, 420);
                    dialog.setLocationRelativeTo(this);
                    dialog.setLayout(new BorderLayout(10, 10));

                    JPanel panelContent = new JPanel(new GridLayout(0, 2, 8, 8));
                    panelContent.setBorder(new EmptyBorder(15, 15, 15, 15));
                    panelContent.setBackground(Color.WHITE);

                    addDetailRow(panelContent, "ID Hợp đồng:", String.valueOf(rs.getInt("id")));
                    addDetailRow(panelContent, "Mã hợp đồng:", rs.getString("ma_hop_dong"));
                    addDetailRow(panelContent, "Mã nhân viên:", rs.getString("ma_nv"));
                    addDetailRow(panelContent, "Họ tên nhân viên:", rs.getString("ho_ten"));
                    addDetailRow(panelContent, "Điện thoại:", rs.getString("dien_thoai") != null ? rs.getString("dien_thoai") : "Chưa cập nhật");
                    addDetailRow(panelContent, "Loại hợp đồng:", rs.getString("loai_hop_dong"));
                    addDetailRow(panelContent, "Ngày bắt đầu:", String.valueOf(rs.getDate("ngay_bat_dau")));

                    Date ngayKT = rs.getDate("ngay_ket_thuc");
                    addDetailRow(panelContent, "Ngày kết thúc:", ngayKT != null ? ngayKT.toString() : "Không thời hạn");

                    double luong = rs.getDouble("muc_luong");
                    addDetailRow(panelContent, "Mức lương HĐ:", String.format("%,.0f VNĐ", luong));
                    addDetailRow(panelContent, "Trạng thái:", rs.getString("trang_thai"));

                    dialog.add(panelContent, BorderLayout.CENTER);

                    JPanel panelBottom = new JPanel();
                    panelBottom.setBackground(Color.WHITE);
                    JButton btnClose = new JButton("Đóng");
                    styleButton(btnClose, new Color(127, 140, 141));
                    btnClose.setPreferredSize(new Dimension(100, 30));
                    btnClose.addActionListener(e -> dialog.dispose());
                    panelBottom.add(btnClose);
                    dialog.add(panelBottom, BorderLayout.SOUTH);

                    dialog.setVisible(true);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi khi tải chi tiết hợp đồng: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addDetailRow(JPanel panel, String label, String value) {
        JLabel lblName = new JLabel(label);
        lblName.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblName.setForeground(new Color(50, 50, 50));

        JLabel lblVal = new JLabel(value);
        lblVal.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblVal.setForeground(new Color(0, 0, 0));

        panel.add(lblName);
        panel.add(lblVal);
    }

    private void hienThiThongKeHopDong() {
        int tongSoHD = 0;
        int hieuLuc = 0;
        int hetHieuLuc = 0;
        int thanhLy = 0;

        int thuViec = 0;
        int xdThoiHan = 0;
        int kxdThoiHan = 0;
        double tongQuyLuong = 0;

        String sql = "SELECT * FROM hop_dong";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                tongSoHD++;
                String tt = rs.getString("trang_thai");
                if ("Hiệu lực".equals(tt)) hieuLuc++;
                else if ("Hết hiệu lực".equals(tt)) hetHieuLuc++;
                else if ("Đã thanh lý".equals(tt)) thanhLy++;

                String loai = rs.getString("loai_hop_dong");
                if ("Thử việc".equals(loai)) thuViec++;
                else if ("Xác định thời hạn".equals(loai)) xdThoiHan++;
                else if ("Không xác định thời hạn".equals(loai)) kxdThoiHan++;

                tongQuyLuong += rs.getDouble("muc_luong");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        JDialog statDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Thống kê tổng quan Hợp đồng lao động", true);
        statDialog.setSize(420, 380);
        statDialog.setLocationRelativeTo(this);
        statDialog.setLayout(new BorderLayout(10, 10));

        JPanel panelMain = new JPanel(new GridLayout(0, 2, 8, 8));
        panelMain.setBorder(new EmptyBorder(15, 15, 15, 15));
        panelMain.setBackground(Color.WHITE);

        addDetailRow(panelMain, "Tổng số lượng hợp đồng:", tongSoHD + " hợp đồng");
        addDetailRow(panelMain, "----------------------------", "----------------------------");
        addDetailRow(panelMain, "• Đang có hiệu lực:", hieuLuc + " hợp đồng");
        addDetailRow(panelMain, "• Hết hiệu lực:", hetHieuLuc + " hợp đồng");
        addDetailRow(panelMain, "• Đã thanh lý:", thanhLy + " hợp đồng");
        addDetailRow(panelMain, "----------------------------", "----------------------------");
        addDetailRow(panelMain, "• Hợp đồng Thử việc:", thuViec + " hợp đồng");
        addDetailRow(panelMain, "• Xác định thời hạn:", xdThoiHan + " hợp đồng");
        addDetailRow(panelMain, "• Không xác định thời hạn:", kxdThoiHan + " hợp đồng");
        addDetailRow(panelMain, "----------------------------", "----------------------------");
        addDetailRow(panelMain, "Tổng quỹ lương HĐ:", String.format("%,.0f VNĐ", tongQuyLuong));

        statDialog.add(panelMain, BorderLayout.CENTER);

        JPanel panelBottom = new JPanel();
        panelBottom.setBackground(Color.WHITE);
        JButton btnClose = new JButton("Đóng");
        styleButton(btnClose, new Color(52, 152, 219));
        btnClose.setPreferredSize(new Dimension(100, 30));
        btnClose.addActionListener(e -> statDialog.dispose());
        panelBottom.add(btnClose);
        statDialog.add(panelBottom, BorderLayout.SOUTH);

        statDialog.setVisible(true);
    }

    private void tuDongTinhNgayKetThuc() {
        try {
            String ngayBDStr = txtNgayBD.getText().trim();
            if (ngayBDStr.isEmpty()) return;
            LocalDate ngayBD = LocalDate.parse(ngayBDStr);
            String loaiHD = (String) cbLoaiHD.getSelectedItem();

            if ("Thử việc".equals(loaiHD)) {
                txtNgayKT.setText(ngayBD.plusMonths(2).toString());
            } else if ("Xác định thời hạn".equals(loaiHD)) {
                txtNgayKT.setText(ngayBD.plusYears(1).toString());
            } else if ("Không xác định thời hạn".equals(loaiHD)) {
                txtNgayKT.setText("");
            }
        } catch (Exception ignored) {}
    }

    private JLabel createLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        return lbl;
    }

    private void styleTextField(JTextField tf) {
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setPreferredSize(new Dimension(0, 26));
    }

    private void styleComboBox(JComboBox<String> cb) {
        cb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cb.setBackground(Color.WHITE);
        cb.setPreferredSize(new Dimension(0, 26));
    }

    private void styleButton(JButton btn, Color bgColor) {
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void loadNhanVienCombobox() {
        cbNhanVien.removeAllItems();
        String sql = "SELECT id, ma_nv, ho_ten FROM nhan_vien";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                cbNhanVien.addItem(rs.getInt("id") + " - " + rs.getString("ho_ten") + " (" + rs.getString("ma_nv") + ")");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadDataToTable() {
        tableModel.setRowCount(0);
        String sql = "SELECT h.*, n.ho_ten FROM hop_dong h JOIN nhan_vien n ON h.nhan_vien_id = n.id ORDER BY h.id DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("ma_hop_dong"),
                        rs.getString("ho_ten"),
                        rs.getString("loai_hop_dong"),
                        rs.getDate("ngay_bat_dau"),
                        rs.getDate("ngay_ket_thuc"),
                        String.format("%,.0f", rs.getDouble("muc_luong")),
                        rs.getString("trang_thai")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void handleAdd() {
        try {
            String maHD = txtMaHD.getText().trim();
            String selectedNV = (String) cbNhanVien.getSelectedItem();
            if (selectedNV == null || selectedNV.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Chưa chọn nhân viên!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int nvId = Integer.parseInt(selectedNV.split(" - ")[0]);
            String loaiHD = (String) cbLoaiHD.getSelectedItem();
            String ngayBDStr = txtNgayBD.getText().trim();
            String ngayKTStr = txtNgayKT.getText().trim();

            if (maHD.isEmpty() || ngayBDStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập mã hợp đồng và ngày bắt đầu!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String checkSql = "SELECT COUNT(*) FROM hop_dong WHERE ma_hop_dong = ?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
                checkPs.setString(1, maHD);
                try (ResultSet rs = checkPs.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        JOptionPane.showMessageDialog(this, "Mã hợp đồng này đã tồn tại trong hệ thống!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

            String mucLuongRaw = txtLuong.getText().replace(".", "").replace(",", "").replace("VNĐ", "").trim();
            double mucLuong = 0.0;
            if (!mucLuongRaw.isEmpty()) {
                try {
                    mucLuong = Double.parseDouble(mucLuongRaw);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Mức lương phải là số hợp lệ!", "Lỗi định dạng số", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            String trangThai = (String) cbTrangThai.getSelectedItem();

            Date ngayBD;
            Date ngayKT = null;
            try {
                ngayBD = Date.valueOf(ngayBDStr);
                if (!ngayKTStr.isEmpty()) {
                    ngayKT = Date.valueOf(ngayKTStr);
                }
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, "Định dạng ngày phải đúng chuẩn YYYY-MM-DD (Ví dụ: 2026-09-09)!", "Lỗi định dạng ngày", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (ngayKT != null && ngayKT.before(ngayBD)) {
                JOptionPane.showMessageDialog(this, "Ngày kết thúc không được nhỏ hơn ngày bắt đầu!", "Lỗi logic ngày", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement("INSERT INTO hop_dong (ma_hop_dong, nhan_vien_id, loai_hop_dong, ngay_bat_dau, ngay_ket_thuc, muc_luong, trang_thai) VALUES (?, ?, ?, ?, ?, ?, ?)")) {
                pstmt.setString(1, maHD);
                pstmt.setInt(2, nvId);
                pstmt.setString(3, loaiHD);
                pstmt.setDate(4, ngayBD);
                if (ngayKT == null) {
                    pstmt.setNull(5, Types.DATE);
                } else {
                    pstmt.setDate(5, ngayKT);
                }
                pstmt.setDouble(6, mucLuong);
                pstmt.setString(7, trangThai);
                pstmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Thêm hợp đồng thành công!");
                loadDataToTable();
                clearForm();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi thêm hợp đồng: " + ex.getMessage(), "Lỗi CSDL", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleUpdate() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn hợp đồng cần cập nhật trên bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            int id = Integer.parseInt(tableModel.getValueAt(selectedRow, 0).toString());
            String selectedNV = (String) cbNhanVien.getSelectedItem();
            if (selectedNV == null || selectedNV.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Chưa chọn nhân viên!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int nvId = Integer.parseInt(selectedNV.split(" - ")[0]);
            String loaiHD = (String) cbLoaiHD.getSelectedItem();
            String ngayBDStr = txtNgayBD.getText().trim();
            String ngayKTStr = txtNgayKT.getText().trim();

            String mucLuongRaw = txtLuong.getText().replace(".", "").replace(",", "").replace("VNĐ", "").trim();
            double mucLuong = 0.0;
            if (!mucLuongRaw.isEmpty()) {
                try {
                    mucLuong = Double.parseDouble(mucLuongRaw);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Mức lương phải là số hợp lệ!", "Lỗi định dạng số", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            String trangThai = (String) cbTrangThai.getSelectedItem();

            Date ngayBD;
            Date ngayKT = null;
            try {
                ngayBD = Date.valueOf(ngayBDStr);
                if (!ngayKTStr.isEmpty()) {
                    ngayKT = Date.valueOf(ngayKTStr);
                }
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, "Định dạng ngày phải đúng chuẩn YYYY-MM-DD (Ví dụ: 2026-09-09)!", "Lỗi định dạng ngày", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (ngayKT != null && ngayKT.before(ngayBD)) {
                JOptionPane.showMessageDialog(this, "Ngày kết thúc không được nhỏ hơn ngày bắt đầu!", "Lỗi logic ngày", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement("UPDATE hop_dong SET nhan_vien_id = ?, loai_hop_dong = ?, ngay_bat_dau = ?, ngay_ket_thuc = ?, muc_luong = ?, trang_thai = ? WHERE id = ?")) {
                pstmt.setInt(1, nvId);
                pstmt.setString(2, loaiHD);
                pstmt.setDate(3, ngayBD);
                if (ngayKT == null) {
                    pstmt.setNull(4, Types.DATE);
                } else {
                    pstmt.setDate(4, ngayKT);
                }
                pstmt.setDouble(5, mucLuong);
                pstmt.setString(6, trangThai);
                pstmt.setInt(7, id);
                pstmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Cập nhật hợp đồng thành công!");
                loadDataToTable();
                clearForm();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi cập nhật hợp đồng: " + ex.getMessage(), "Lỗi CSDL", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleDelete() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn hợp đồng cần xóa trên bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = Integer.parseInt(tableModel.getValueAt(selectedRow, 0).toString());
        String maHD = tableModel.getValueAt(selectedRow, 1).toString();

        int confirm = JOptionPane.showConfirmDialog(this, "Xác nhận xóa hợp đồng mã: " + maHD + "?", "Cảnh báo", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement("DELETE FROM hop_dong WHERE id = ?")) {
                pstmt.setInt(1, id);
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Xóa hợp đồng thành công!");
                loadDataToTable();
                clearForm();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi khi xóa hợp đồng: " + ex.getMessage(), "Lỗi CSDL", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void clearForm() {
        txtMaHD.setText("");
        txtLuong.setText("");

        LocalDate today = LocalDate.now();
        txtNgayBD.setText(today.toString());

        cbLoaiHD.setSelectedIndex(0);
        txtNgayKT.setText(today.plusMonths(2).toString());

        txtMaHD.setEditable(true);
        table.clearSelection();
    }
}