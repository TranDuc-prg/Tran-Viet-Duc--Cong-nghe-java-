package vn.edu.eaut.dao;

import vn.edu.eaut.connection.DatabaseConnection;
import vn.edu.eaut.model.NhanVienBaoCaoDTO;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class BaoCaoDAO {

    // =========================================================
    // 1. LẤY DANH SÁCH NHÂN VIÊN CHO BÁO CÁO
    // =========================================================

    public List<NhanVienBaoCaoDTO> getDanhSachBaoCaoNhanSu() {

        List<NhanVienBaoCaoDTO> list = new ArrayList<>();

        String query =
                "SELECT " +
                        "    nv.ma_nv, " +
                        "    nv.ho_ten, " +
                        "    nv.gioi_tinh, " +
                        "    nv.ngay_sinh, " +
                        "    pb.ten_phong_ban, " +
                        "    'Chưa cập nhật' AS ten_chuc_vu, " +
                        "    COALESCE(NULLIF(TRIM(nv.trang_thai), ''), 'Đang làm việc') AS trang_thai, " +
                        "    MIN(hd.ngay_bat_dau) AS ngay_vao_lam " +
                        "FROM nhan_vien nv " +
                        "LEFT JOIN phong_ban pb " +
                        "    ON nv.phong_ban_id = pb.id " +
                        "LEFT JOIN hop_dong hd " +
                        "    ON nv.id = hd.nhan_vien_id " +
                        "GROUP BY " +
                        "    nv.id, " +
                        "    nv.ma_nv, " +
                        "    nv.ho_ten, " +
                        "    nv.gioi_tinh, " +
                        "    nv.ngay_sinh, " +
                        "    pb.ten_phong_ban, " +
                        "    nv.trang_thai " +
                        "ORDER BY nv.id ASC";

        try (
                Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(query);
                ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                NhanVienBaoCaoDTO dto =
                        new NhanVienBaoCaoDTO(
                                rs.getString("ma_nv"),
                                rs.getString("ho_ten"),
                                rs.getString("gioi_tinh"),
                                rs.getDate("ngay_sinh"),
                                rs.getString("ten_phong_ban"),
                                rs.getString("ten_chuc_vu"),
                                rs.getString("trang_thai"),
                                rs.getDate("ngay_vao_lam")
                        );

                list.add(dto);
            }

        } catch (Exception e) {

            System.err.println(
                    "LỖI: Không thể lấy danh sách nhân sự!"
            );

            e.printStackTrace();
        }

        return list;
    }


    // =========================================================
    // 2. BÁO CÁO QUỸ LƯƠNG 5 NĂM
    // =========================================================

    public DefaultCategoryDataset getDatasetQuyLuong5Nam() {

        DefaultCategoryDataset dataset =
                new DefaultCategoryDataset();

        String query =
                "SELECT " +
                        "    b.nam, " +
                        "    SUM(n.luong_co_ban) AS tong_quy_luong " +
                        "FROM bang_luong b " +
                        "JOIN nhan_vien n " +
                        "    ON b.nhan_vien_id = n.id " +
                        "WHERE b.nam >= YEAR(CURDATE()) - 4 " +
                        "GROUP BY b.nam " +
                        "ORDER BY b.nam ASC";

        try (
                Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(query);
                ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                int nam =
                        rs.getInt("nam");

                double tongTien =
                        rs.getDouble("tong_quy_luong");

                dataset.addValue(
                        tongTien / 1_000_000.0,
                        "Quỹ Lương (Triệu VNĐ)",
                        String.valueOf(nam)
                );
            }

        } catch (Exception e) {

            System.err.println(
                    "LỖI: Không thể lấy dữ liệu quỹ lương 5 năm!"
            );

            e.printStackTrace();
        }

        return dataset;
    }


    // =========================================================
    // 3. TỶ LỆ CHẤM CÔNG
    // =========================================================

    public DefaultPieDataset getDatasetTyLeChamCong() {

        DefaultPieDataset dataset =
                new DefaultPieDataset();

        String query =
                "SELECT " +
                        "    trang_thai_cham_cong, " +
                        "    COUNT(*) AS so_luong " +
                        "FROM cham_cong " +
                        "GROUP BY trang_thai_cham_cong";

        try (
                Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(query);
                ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                String trangThai =
                        rs.getString("trang_thai_cham_cong");

                int soLuong =
                        rs.getInt("so_luong");

                if (trangThai == null ||
                        trangThai.trim().isEmpty()) {

                    trangThai = "Khác";
                }

                dataset.setValue(
                        trangThai,
                        soLuong
                );
            }

        } catch (Exception e) {

            System.err.println(
                    "LỖI: Không thể lấy dữ liệu chấm công!"
            );

            e.printStackTrace();
        }

        return dataset;
    }
}