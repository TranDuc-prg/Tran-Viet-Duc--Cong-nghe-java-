package vn.edu.eaut.service;

import vn.edu.eaut.dao.NhanVienDAO;

public class NhanVienService {
    private final NhanVienDAO nhanVienDAO;

    public NhanVienService() {
        this.nhanVienDAO = new NhanVienDAO();
    }

    public int getNhanVienIdByUsername(String username) {
        return nhanVienDAO.getNhanVienIdByUsername(username);
    }

    public String login(String username, String password) throws Exception {
        if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Tài khoản và mật khẩu không được để trống!");
        }
        return nhanVienDAO.checkLogin(username.trim(), password.trim());
    }
}