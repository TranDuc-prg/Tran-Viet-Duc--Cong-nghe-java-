package vn.edu.eaut.dao;

import vn.edu.eaut.connection.DatabaseConnection;
import vn.edu.eaut.model.UserSession;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

public class LuongDAO {
    public boolean chotBangLuongThang(int thang, int nam) {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            String sqlNV = "SELECT id FROM nhan_vien";
            try (PreparedStatement psNV = conn.prepareStatement(sqlNV);
                 ResultSet rsNV = psNV.executeQuery()) {

                while (rsNV.next()) {
                    int nvId = rsNV.getInt("id");
                    ghiHoacCapNhatBangLuong(conn, nvId, thang, nam, "Đã chốt");
                }
            }

            conn.commit();

            try {
                String currentUser = UserSession.getUsername() != null ? UserSession.getUsername() : "Admin";
                AuditLogDAO.log(
                        currentUser,
                        "CHOT_LUONG",
                        "BangLuong",
                        "Chốt bảng lương tháng " + thang + "/" + nam
                );
            } catch (Exception logEx) {
                logEx.printStackTrace();
            }

            return true;
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return false;
    }

    private void ghiHoacCapNhatBangLuong(Connection conn, int nvId, int thang, int nam, String trangThai) throws SQLException {
        String checkSql = "SELECT id FROM bang_luong WHERE nhan_vien_id = ? AND thang = ? AND nam = ?";
        try (PreparedStatement ps = conn.prepareStatement(checkSql)) {
            ps.setInt(1, nvId);
            ps.setInt(2, thang);
            ps.setInt(3, nam);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String update = "UPDATE bang_luong SET trang_thai = ? WHERE nhan_vien_id = ? AND thang = ? AND nam = ?";
                    try (PreparedStatement psUp = conn.prepareStatement(update)) {
                        psUp.setString(1, trangThai);
                        psUp.setInt(2, nvId);
                        psUp.setInt(3, thang);
                        psUp.setInt(4, nam);
                        psUp.executeUpdate();
                    }
                    return;
                }
            }
        }

        String insert = "INSERT INTO bang_luong (nhan_vien_id, thang, nam, trang_thai) VALUES (?, ?, ?, ?)";
        try (PreparedStatement psIns = conn.prepareStatement(insert)) {
            psIns.setInt(1, nvId);
            psIns.setInt(2, thang);
            psIns.setInt(3, nam);
            psIns.setString(4, trangThai);
            psIns.executeUpdate();
        }
    }

    public Map<Integer, Double> getMucLuongTrungBinh5Nam() {
        Map<Integer, Double> map = new LinkedHashMap<>();
        String sql = "SELECT b.nam, SUM(n.luong_co_ban) AS tong_quy " +
                "FROM bang_luong b " +
                "JOIN nhan_vien n ON b.nhan_vien_id = n.id " +
                "WHERE b.nam >= YEAR(NOW()) - 5 " +
                "GROUP BY b.nam " +
                "ORDER BY b.nam ASC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                map.put(rs.getInt("nam"), rs.getDouble("tong_quy"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return map;
    }
}