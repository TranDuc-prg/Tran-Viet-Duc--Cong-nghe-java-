package vn.edu.eaut.dao;

import vn.edu.eaut.connection.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AuditLogDAO {

    // Đã cắt bỏ tham số ma_nv, chỉ truyền các thông tin cần thiết
    public static void log(String hoTen, String hanhDong, String doiTuong, String chiTiet) {
        String sql = "INSERT INTO audit_log (ho_ten, hanh_dong, doi_tuong, chi_tiet) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, hoTen);
            pstmt.setString(2, hanhDong);
            pstmt.setString(3, doiTuong);
            pstmt.setString(4, chiTiet);

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}