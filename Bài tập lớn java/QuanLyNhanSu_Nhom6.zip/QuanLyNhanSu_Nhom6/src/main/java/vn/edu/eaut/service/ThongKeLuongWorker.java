package vn.edu.eaut.service;

import javax.swing.*;
import java.util.Map;

public class ThongKeLuongWorker extends SwingWorker<Map<Integer, Double>, Void> {
    private final ThongKeService thongKeService;
    private final JProgressBar progressBar;
    private final Runnable onSuccess;

    public ThongKeLuongWorker(ThongKeService thongKeService, JProgressBar progressBar, Runnable onSuccess) {
        this.thongKeService = thongKeService;
        this.progressBar = progressBar;
        this.onSuccess = onSuccess;
    }

    @Override
    protected Map<Integer, Double> doInBackground() throws Exception {
        if (progressBar != null) {
            progressBar.setIndeterminate(true);
        }
        return thongKeService.getMucLuongTrungBinh5Nam();
    }

    @Override
    protected void done() {
        if (progressBar != null) {
            progressBar.setIndeterminate(false);
        }
        try {
            Map<Integer, Double> data = get();
            if (onSuccess != null && data != null) {
                onSuccess.run();
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi khi tải dữ liệu thống kê: " + e.getMessage());
        }
    }
}