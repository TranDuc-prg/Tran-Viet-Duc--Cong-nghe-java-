package vn.edu.eaut.view;

import vn.edu.eaut.model.UserSession;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class AdminMainFrame extends JFrame {
    private CardLayout cardLayout;
    private JPanel panelCenter;
    private JButton activeButton;
    private JButton firstButton;

    // Các thành phần giao diện cần tùy biến theo vai trò
    private JButton btnTaiKhoan;
    private JButton btnBaoCao;
    private JButton btnPhongBan;
    private JButton btnChucVu;
    private JButton btnHopDong;
    private JButton btnPhuCap;
    private JButton btnBangLuong;
    private JButton btnAuditLog;
    private JButton btnThongBao;
    private JButton btnBackupRestore;
    private JButton btnTrangThai; // Nút mới thêm

    public AdminMainFrame() {
        UITheme.install();

        String role = UserSession.getRole();
        String roleTitle = "QUẢN TRỊ HỆ THỐNG • ADMIN";
        if ("HR".equals(role)) {
            roleTitle = "QUẢN LÝ NHÂN SỰ • HR";
        } else if ("NHAN_VIEN".equals(role)) {
            roleTitle = "NHÂN VIÊN • NHÂN SỰ";
        }

        setTitle("Quản Lý Nhân Sự | " + roleTitle);
        setSize(1280, 800);
        setMinimumSize(new Dimension(1150, 720));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        add(createHeader(), BorderLayout.NORTH);
        add(createSidebar(), BorderLayout.WEST);

        cardLayout = new CardLayout();
        panelCenter = new JPanel(cardLayout);
        panelCenter.setBackground(UITheme.BG);
        panelCenter.setBorder(new EmptyBorder(14, 14, 14, 14));

        // Thêm các Panel chức năng vào CardLayout
        panelCenter.add(new DashboardPanel(), "DASHBOARD");
        panelCenter.add(new NhanVienFrame(role), "NHAN_VIEN");
        panelCenter.add(new PhongBanFrame(), "PHONG_BAN");
        panelCenter.add(new ChucVuFrame(), "CHUC_VU");
        panelCenter.add(new HopDongFrame(), "HOP_DONG");
        panelCenter.add(new ChamCongFrame(role), "CHAM_CONG");
        panelCenter.add(new NghiPhepFrame(), "NGHI_PHEP");
        panelCenter.add(new TangCaFrame(), "TANG_CA");
        panelCenter.add(new PhuCapFrame(), "PHU_CAP");
        panelCenter.add(new BangLuongFrame(), "BANG_LUONG");
        panelCenter.add(new BaoCaoThongKeFrame(), "BAO_CAO");
        panelCenter.add(new TaiKhoanFrame(), "TAI_KHOAN");
        panelCenter.add(new AuditLogFrame(), "AUDIT_LOG");
        panelCenter.add(new QuanLyThongBaoPanel(), "THONG_BAO");
        panelCenter.add(new BackupRestorePanel(), "BACKUP_RESTORE");

        // Thêm Panel trạng thái nhân viên phòng ban vừa tạo
        panelCenter.add(new NhanVienTrangThaiPanel(), "TRANG_THAI");

        add(panelCenter, BorderLayout.CENTER);
        add(createFooter(), BorderLayout.SOUTH);

        // Áp dụng phân quyền hiển thị menu sidebar
        applyRoleAuthorization();

        // Hiển thị trang Dashboard mặc định khi khởi động
        showPage(firstButton, "DASHBOARD");
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setPreferredSize(new Dimension(0, 72));
        header.setBackground(UITheme.GREEN);
        header.setBorder(new EmptyBorder(0, 24, 0, 24));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 14));
        left.setOpaque(false);

        JLabel logo = new JLabel("HR", SwingConstants.CENTER);
        logo.setPreferredSize(new Dimension(44, 44));
        logo.setFont(UITheme.font(Font.BOLD, 15));
        logo.setForeground(UITheme.GREEN);
        logo.setBackground(Color.WHITE);
        logo.setOpaque(true);

        JPanel titles = new JPanel();
        titles.setOpaque(false);
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("HỆ THỐNG QUẢN LÝ NHÂN SỰ");
        title.setFont(UITheme.font(Font.BOLD, 16));
        title.setForeground(Color.WHITE);

        String role = UserSession.getRole();
        String subText = "QUẢN TRỊ HỆ THỐNG • ADMIN";
        if ("HR".equals(role)) {
            subText = "QUẢN LÝ NHÂN SỰ • HR";
        } else if ("NHAN_VIEN".equals(role)) {
            subText = "NHÂN VIÊN • " + (UserSession.getUsername() != null ? UserSession.getUsername() : "");
        }

        JLabel sub = new JLabel(subText);
        sub.setFont(UITheme.font(Font.PLAIN, 10));
        sub.setForeground(new Color(209, 250, 229));

        titles.add(title);
        titles.add(Box.createVerticalStrut(3));
        titles.add(sub);
        left.add(logo);
        left.add(titles);

        JPanel user = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 14));
        user.setOpaque(false);

        String displayName = "Quản trị viên";
        if ("HR".equals(role)) displayName = "Nhân sự (HR)";
        else if ("NHAN_VIEN".equals(role)) displayName = UserSession.getUsername();

        JLabel info = new JLabel("<html><b>" + displayName + "</b><br><font size='2'>" + role + " • Đang hoạt động</font></html>");
        info.setForeground(Color.WHITE);
        info.setHorizontalAlignment(SwingConstants.RIGHT);

        JLabel avatar = new JLabel(role != null && !role.isEmpty() ? role.substring(0, 1) : "U", SwingConstants.CENTER);
        avatar.setPreferredSize(new Dimension(40, 40));
        avatar.setFont(UITheme.font(Font.BOLD, 15));
        avatar.setForeground(UITheme.GREEN);
        avatar.setBackground(Color.WHITE);
        avatar.setOpaque(true);

        user.add(info);
        user.add(avatar);

        header.add(left, BorderLayout.WEST);
        header.add(user, BorderLayout.EAST);
        return header;
    }

    private JPanel createSidebar() {
        JPanel sidebarContent = new JPanel();
        sidebarContent.setLayout(new BoxLayout(sidebarContent, BoxLayout.Y_AXIS));
        sidebarContent.setBackground(UITheme.NAVY);
        sidebarContent.setBorder(new EmptyBorder(18, 14, 16, 14));

        sidebarContent.add(UITheme.createSidebarHeader(
                "QUẢN TRỊ HỆ THỐNG",
                "Quản lý toàn bộ nghiệp vụ"
        ));
        sidebarContent.add(Box.createVerticalStrut(18));

        JLabel menu = new JLabel("  CHỨC NĂNG QUẢN TRỊ");
        menu.setFont(UITheme.font(Font.BOLD, 10));
        menu.setForeground(new Color(148, 163, 184));
        menu.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebarContent.add(menu);
        sidebarContent.add(Box.createVerticalStrut(8));

        // Khởi tạo các nút chức năng
        JButton btnDashboard = UITheme.navButton("DB", "Tổng quan Dashboard");
        firstButton = btnDashboard;

        JButton btnNhanVien = UITheme.navButton("NV", "Quản lý Nhân Viên");
        btnPhongBan = UITheme.navButton("PB", "Quản lý Phòng Ban");
        btnChucVu = UITheme.navButton("CV", "Quản lý Chức Vụ");
        btnHopDong = UITheme.navButton("HD", "Quản lý Hợp Đồng");
        JButton btnChamCong = UITheme.navButton("CC", "Quản lý Chấm Công");
        JButton btnNghiPhep = UITheme.navButton("NP", "Quản lý Nghỉ Phép");
        JButton btnTangCa = UITheme.navButton("TC", "Quản lý Tăng Ca");
        btnPhuCap = UITheme.navButton("PC", "Phụ Cấp & Khấu Trừ");
        btnBangLuong = UITheme.navButton("BL", "Tính Lương & Bảng Lương");
        btnBaoCao = UITheme.navButton("BC", "Báo Cáo & Thống Kê");
        btnTaiKhoan = UITheme.navButton("TK", "Quản lý Tài Khoản");
        btnAuditLog = UITheme.navButton("AL", "Lịch sử thao tác (Log)");
        btnThongBao = UITheme.navButton("TB", "Quản lý Thông Báo");
        btnBackupRestore = UITheme.navButton("BR", "Sao lưu & Khôi phục");

        // Khởi tạo nút Trạng Thái Phòng Ban / Nhân sự mới
        btnTrangThai = UITheme.navButton("TT", "Trạng Thái & Phòng Ban");

        JButton[] buttons = {btnDashboard, btnNhanVien, btnPhongBan, btnChucVu, btnHopDong,
                btnChamCong, btnNghiPhep, btnTangCa, btnPhuCap, btnBangLuong,
                btnTrangThai, btnBaoCao, btnTaiKhoan, btnAuditLog, btnThongBao, btnBackupRestore};

        for (JButton b : buttons) {
            sidebarContent.add(b);
            sidebarContent.add(Box.createVerticalStrut(4));
        }

        sidebarContent.add(Box.createVerticalStrut(10));
        JButton logout = UITheme.logoutButton();
        sidebarContent.add(logout);

        // Đăng ký sự kiện điều hướng
        btnDashboard.addActionListener(e -> showPage(btnDashboard, "DASHBOARD"));
        btnNhanVien.addActionListener(e -> showPage(btnNhanVien, "NHAN_VIEN"));
        btnPhongBan.addActionListener(e -> showPage(btnPhongBan, "PHONG_BAN"));
        btnChucVu.addActionListener(e -> showPage(btnChucVu, "CHUC_VU"));
        btnHopDong.addActionListener(e -> showPage(btnHopDong, "HOP_DONG"));
        btnChamCong.addActionListener(e -> showPage(btnChamCong, "CHAM_CONG"));
        btnNghiPhep.addActionListener(e -> showPage(btnNghiPhep, "NGHI_PHEP"));
        btnTangCa.addActionListener(e -> showPage(btnTangCa, "TANG_CA"));
        btnPhuCap.addActionListener(e -> showPage(btnPhuCap, "PHU_CAP"));
        btnBangLuong.addActionListener(e -> showPage(btnBangLuong, "BANG_LUONG"));
        btnTrangThai.addActionListener(e -> showPage(btnTrangThai, "TRANG_THAI")); // Sự kiện nút mới
        btnBaoCao.addActionListener(e -> showPage(btnBaoCao, "BAO_CAO"));
        btnTaiKhoan.addActionListener(e -> showPage(btnTaiKhoan, "TAI_KHOAN"));
        btnAuditLog.addActionListener(e -> showPage(btnAuditLog, "AUDIT_LOG"));
        btnThongBao.addActionListener(e -> showPage(btnThongBao, "THONG_BAO"));
        btnBackupRestore.addActionListener(e -> showPage(btnBackupRestore, "BACKUP_RESTORE"));
        logout.addActionListener(e -> logout());

        // Bọc vào JScrollPane để có thanh cuộn dọc và cố định chiều rộng
        JScrollPane scrollPane = new JScrollPane(sidebarContent);
        scrollPane.setPreferredSize(new Dimension(260, 0));
        scrollPane.setBorder(null);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        JPanel sidebarWrapper = new JPanel(new BorderLayout());
        sidebarWrapper.add(scrollPane, BorderLayout.CENTER);
        return sidebarWrapper;
    }

    private void applyRoleAuthorization() {
        String role = UserSession.getRole();
        if (role == null) return;

        if ("NHAN_VIEN".equals(role)) {
            if (btnTaiKhoan != null) btnTaiKhoan.setVisible(false);
            if (btnBaoCao != null) btnBaoCao.setVisible(false);
            if (btnPhongBan != null) btnPhongBan.setVisible(false);
            if (btnChucVu != null) btnChucVu.setVisible(false);
            if (btnPhuCap != null) btnPhuCap.setVisible(false);
            if (btnBangLuong != null) btnBangLuong.setVisible(false);
            if (btnAuditLog != null) btnAuditLog.setVisible(false);
            if (btnThongBao != null) btnThongBao.setVisible(false);
            if (btnBackupRestore != null) btnBackupRestore.setVisible(false);
        } else if ("HR".equals(role)) {
            if (btnTaiKhoan != null) btnTaiKhoan.setVisible(false);
            if (btnAuditLog != null) btnAuditLog.setVisible(false);
            if (btnThongBao != null) btnThongBao.setVisible(true);
            if (btnBackupRestore != null) btnBackupRestore.setVisible(false);
        }
    }

    private void showPage(JButton button, String page) {
        if (activeButton != null) UITheme.setNavActive(activeButton, false);
        activeButton = button;
        UITheme.setNavActive(button, true);
        cardLayout.show(panelCenter, page);
    }

    private JPanel createFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setPreferredSize(new Dimension(0, 30));
        footer.setBackground(Color.WHITE);
        footer.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UITheme.BORDER));

        JLabel left = new JLabel("  © 2026 EAUT • Hệ thống quản lý nhân sự");
        left.setFont(UITheme.font(Font.PLAIN, 9));
        left.setForeground(UITheme.MUTED);

        String role = UserSession.getRole();
        String rightText = "ADMIN • TOÀN QUYỀN QUẢN TRỊ  ";
        if ("HR".equals(role)) {
            rightText = "HR • QUẢN LÝ NHÂN SỰ  ";
        } else if ("NHAN_VIEN".equals(role)) {
            rightText = "NHÂN VIÊN • XEM THÔNG TIN CÁ NHÂN  ";
        }

        JLabel right = new JLabel(rightText);
        right.setFont(UITheme.font(Font.BOLD, 9));
        right.setForeground(UITheme.GREEN_DARK);

        footer.add(left, BorderLayout.WEST);
        footer.add(right, BorderLayout.EAST);
        return footer;
    }

    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc chắn muốn đăng xuất khỏi hệ thống?",
                "Xác nhận đăng xuất",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            UserSession.logout();
            dispose();
            new LoginFrame().setVisible(true);
        }
    }
}