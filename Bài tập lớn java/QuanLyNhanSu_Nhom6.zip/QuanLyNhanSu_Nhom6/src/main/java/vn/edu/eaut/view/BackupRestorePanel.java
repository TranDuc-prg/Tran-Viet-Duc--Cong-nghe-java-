package vn.edu.eaut.view;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BackupRestorePanel extends JPanel {
    private JButton btnBackup, btnRestore;
    private JTextArea txtLog;

    // Cấu hình thông tin kết nối Database của bạn
    private final String dbUser = "root";
    private final String dbPassword = ""; // Nhập mật khẩu MySQL của bạn nếu có
    private final String dbName = "quan_ly_nhan_su"; // Tên database thực tế

    // Đường dẫn tuyệt đối tới thư mục bin chứa mysqldump.exe và mysql.exe khớp với máy của bạn
    private final String MYSQL_BIN = "C:\\xampp2\\mysql\\bin\\";

    public BackupRestorePanel() {
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        setBackground(UITheme.BG);

        // Panel chứa các nút chức năng quản trị
        JPanel panelControls = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        panelControls.setBackground(Color.WHITE);
        panelControls.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                new TitledBorder("⚙ QUẢN TRỊ HỆ THỐNG - Sao lưu & Khôi phục dữ liệu")
        ));

        btnBackup = new JButton("💾 Sao lưu dữ liệu");
        btnRestore = new JButton("📂 Khôi phục dữ liệu");

        // Tùy chỉnh giao diện nút bấm cơ bản
        btnBackup.setFont(UITheme.font(Font.BOLD, 12));
        btnBackup.setBackground(UITheme.GREEN);
        btnBackup.setForeground(Color.black);
        btnBackup.setFocusPainted(false);

        btnRestore.setFont(UITheme.font(Font.BOLD, 12));
        btnRestore.setBackground(new Color(217, 119, 6));
        btnRestore.setForeground(Color.black);
        btnRestore.setFocusPainted(false);

        panelControls.add(btnBackup);
        panelControls.add(btnRestore);
        add(panelControls, BorderLayout.NORTH);

        // Vùng hiển thị nhật ký thao tác trực tiếp trên giao diện
        txtLog = new JTextArea();
        txtLog.setEditable(false);
        txtLog.setFont(new Font("Consolas", Font.PLAIN, 12));
        txtLog.setBackground(new Color(248, 250, 252));

        JScrollPane scrollPane = new JScrollPane(txtLog);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                new TitledBorder("Nhật ký hoạt động hệ thống")
        ));
        add(scrollPane, BorderLayout.CENTER);

        // Sự kiện Sao lưu
        btnBackup.addActionListener(e -> handleBackup());

        // Sự kiện Khôi phục
        btnRestore.addActionListener(e -> handleRestore());

        appendLog("Hệ thống quản lý sao lưu & khôi phục đã sẵn sàng.");
    }

    private void handleBackup() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Chọn thư mục lưu file Backup");
        String timeStamp = new SimpleDateFormat("yyyy_MM_dd_HHmmss").format(new Date());
        fileChooser.setSelectedFile(new File("backup_" + dbName + "_" + timeStamp + ".sql"));

        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            String filePath = fileToSave.getAbsolutePath();
            if (!filePath.endsWith(".sql")) {
                filePath += ".sql";
            }

            final String finalFilePath = filePath;

            // Sử dụng SwingWorker để chạy tiến trình ngầm, tránh đơ giao diện ứng dụng
            SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
                @Override
                protected Boolean doInBackground() throws Exception {
                    appendLog("Đang tiến hành sao lưu cơ sở dữ liệu...");

                    String mysqldumpPath = MYSQL_BIN + "mysqldump.exe";

                    List<String> command = new ArrayList<>();
                    command.add(mysqldumpPath);
                    command.add("-u" + dbUser);
                    if (dbPassword != null && !dbPassword.isEmpty()) {
                        command.add("-p" + dbPassword);
                    }
                    command.add(dbName);
                    command.add("-r");
                    command.add(finalFilePath);

                    ProcessBuilder pb = new ProcessBuilder(command);
                    pb.redirectErrorStream(true); // Gộp luồng lỗi để bắt thông điệp log chi tiết
                    Process process = pb.start();

                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            appendLog("  -> " + line);
                        }
                    }

                    int exitCode = process.waitFor();
                    return exitCode == 0;
                }

                @Override
                protected void done() {
                    try {
                        if (get()) {
                            appendLog("-> Sao lưu thành công! File lưu tại: " + finalFilePath);
                            JOptionPane.showMessageDialog(BackupRestorePanel.this,
                                    "Sao lưu dữ liệu thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            appendLog("-> Lỗi: Không thể sao lưu cơ sở dữ liệu. Kiểm tra các dòng log phía trên.");
                            JOptionPane.showMessageDialog(BackupRestorePanel.this,
                                    "Sao lưu thất bại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception ex) {
                        appendLog("-> Lỗi ngoại lệ: " + ex.getMessage());
                    }
                }
            };
            worker.execute();
        }
    }

    private void handleRestore() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "CẢNH BÁO: Khôi phục dữ liệu sẽ ghi đè lên toàn bộ cơ sở dữ liệu hiện tại!\nBạn có chắc chắn muốn tiếp tục không?",
                "Xác nhận khôi phục", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Chọn file .sql cần khôi phục");
        int userSelection = fileChooser.showOpenDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToRestore = fileChooser.getSelectedFile();

            SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
                @Override
                protected Boolean doInBackground() throws Exception {
                    appendLog("Đang tiến hành khôi phục cơ sở dữ liệu từ: " + fileToRestore.getName() + "...");

                    String mysqlPath = MYSQL_BIN + "mysql.exe";

                    List<String> command = new ArrayList<>();
                    command.add(mysqlPath);
                    command.add("-u" + dbUser);
                    if (dbPassword != null && !dbPassword.isEmpty()) {
                        command.add("-p" + dbPassword);
                    }
                    command.add(dbName);

                    ProcessBuilder pb = new ProcessBuilder(command);
                    pb.redirectInput(fileToRestore); // Đọc file SQL trực tiếp vào tiến trình mysql
                    pb.redirectErrorStream(true);
                    Process process = pb.start();

                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            appendLog("  -> " + line);
                        }
                    }

                    int exitCode = process.waitFor();
                    return exitCode == 0;
                }

                @Override
                protected void done() {
                    try {
                        if (get()) {
                            appendLog("-> Khôi phục dữ liệu thành công từ file: " + fileToRestore.getName());
                            JOptionPane.showMessageDialog(BackupRestorePanel.this,
                                    "Khôi phục cơ sở dữ liệu thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            appendLog("-> Lỗi: Không thể khôi phục cơ sở dữ liệu.");
                            JOptionPane.showMessageDialog(BackupRestorePanel.this,
                                    "Khôi phục thất bại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception ex) {
                        appendLog("-> Lỗi ngoại lệ: " + ex.getMessage());
                    }
                }
            };
            worker.execute();
        }
    }

    private void appendLog(String message) {
        String time = new SimpleDateFormat("HH:mm:ss").format(new Date());
        txtLog.append("[" + time + "] " + message + "\n");
        txtLog.setCaretPosition(txtLog.getDocument().getLength());
    }
}