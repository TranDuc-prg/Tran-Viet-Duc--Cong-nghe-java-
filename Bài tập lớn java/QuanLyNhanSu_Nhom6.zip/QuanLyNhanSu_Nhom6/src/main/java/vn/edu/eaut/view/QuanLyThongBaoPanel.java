package vn.edu.eaut.view;

import vn.edu.eaut.connection.DatabaseConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class QuanLyThongBaoPanel extends JPanel {
    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField txtTimKiem, txtTieuDe;
    private JTextArea txtNoiDung;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi, btnTimKiem;

    public QuanLyThongBaoPanel() {
        setLayout(new BorderLayout(15, 15));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setBackground(new Color(245, 247, 250));

        // --- 1. Tiêu đề & Cụm Tìm Kiếm (Phía trên) ---
        JPanel panelTop = new JPanel(new BorderLayout(10, 10));
        panelTop.setOpaque(false);

        JLabel lblTitle = new JLabel("📢 QUẢN LÝ THÔNG BÁO NỘI BỘ");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(new Color(41, 128, 185));
        panelTop.add(lblTitle, BorderLayout.WEST);

        JPanel panelSearch = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        panelSearch.setOpaque(false);

        JLabel lblSearch = new JLabel("Tìm kiếm:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSearch.setForeground(new Color(40, 40, 40));
        panelSearch.add(lblSearch);

        txtTimKiem = new JTextField(20);
        txtTimKiem.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        panelSearch.add(txtTimKiem);

        btnTimKiem = createButton("Tìm Kiếm", new Color(52, 152, 219));
        panelSearch.add(btnTimKiem);

        panelTop.add(panelSearch, BorderLayout.EAST);
        add(panelTop, BorderLayout.NORTH);

        // --- 2. Bảng Danh Sách Thông Báo (Giữa) ---
        String[] columns = {"ID", "Tiêu Đề", "Nội Dung", "Ngày Tạo"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Không cho phép sửa trực tiếp trên ô
            }
        };

        table = new JTable(tableModel);
        table.setRowHeight(32);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setForeground(Color.BLACK); // Đảm bảo chữ trong bảng màu đen
        table.setGridColor(new Color(220, 224, 230));
        table.setSelectionBackground(new Color(52, 152, 219, 50));
        table.setSelectionForeground(Color.BLACK);

        // Header của bảng
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(41, 128, 185));
        table.getTableHeader().setForeground(Color.BLACK);
        table.getTableHeader().setPreferredSize(new Dimension(0, 35));

        // Thiết lập Renderer để hiển thị chữ màu đen cho tất cả các cột và căn lề hợp lý
        DefaultTableCellRenderer leftRenderer = new DefaultTableCellRenderer();
        leftRenderer.setForeground(Color.BLACK);
        leftRenderer.setHorizontalAlignment(SwingConstants.LEFT);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setForeground(Color.BLACK);
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(1).setCellRenderer(leftRenderer);
        table.getColumnModel().getColumn(2).setCellRenderer(leftRenderer);
        table.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);

        // Điều chỉnh kích thước cột
        table.getColumnModel().getColumn(0).setPreferredWidth(60);
        table.getColumnModel().getColumn(1).setPreferredWidth(220);
        table.getColumnModel().getColumn(2).setPreferredWidth(450);
        table.getColumnModel().getColumn(3).setPreferredWidth(160);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.getViewport().setBackground(Color.WHITE);
        add(scrollPane, BorderLayout.CENTER);

        // --- 3. Form Nhập Liệu & Nút Chức Năng (Phía dưới) ---
        JPanel panelBottom = new JPanel(new BorderLayout(10, 10));
        panelBottom.setOpaque(false);
        panelBottom.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(200, 205, 215)),
                        " Thông Tin Chi Tiết ",
                        javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
                        javax.swing.border.TitledBorder.DEFAULT_POSITION,
                        new Font("Segoe UI", Font.BOLD, 13),
                        new Color(41, 128, 185)
                ),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 6, 6, 6);

        // Nhãn và ô Tiêu đề
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        JLabel lblTieuDe = new JLabel("Tiêu Đề:");
        lblTieuDe.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTieuDe.setForeground(new Color(40, 40, 40));
        panelForm.add(lblTieuDe, gbc);

        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0;
        txtTieuDe = new JTextField();
        txtTieuDe.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtTieuDe.setPreferredSize(new Dimension(0, 30));
        panelForm.add(txtTieuDe, gbc);

        // Nhãn và ô Nội dung
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        JLabel lblNoiDung = new JLabel("Nội Dung:");
        lblNoiDung.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblNoiDung.setForeground(new Color(40, 40, 40));
        panelForm.add(lblNoiDung, gbc);

        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 1.0;
        txtNoiDung = new JTextArea(3, 20);
        txtNoiDung.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtNoiDung.setForeground(Color.BLACK);
        txtNoiDung.setLineWrap(true);
        txtNoiDung.setWrapStyleWord(true);

        JScrollPane scrollNoiDung = new JScrollPane(txtNoiDung);
        panelForm.add(scrollNoiDung, gbc);

        panelBottom.add(panelForm, BorderLayout.CENTER);

        // Cụm nút thao tác
        JPanel panelActions = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        panelActions.setOpaque(false);

        btnThem = createButton("Thêm Mới", new Color(46, 204, 113));
        btnSua = createButton("Cập Nhật", new Color(241, 196, 15));
        btnXoa = createButton("Xóa Bỏ", new Color(231, 76, 60));
        btnLamMoi = createButton("Làm Mới", new Color(149, 165, 166));

        panelActions.add(btnThem);
        panelActions.add(btnSua);
        panelActions.add(btnXoa);
        panelActions.add(btnLamMoi);
        panelBottom.add(panelActions, BorderLayout.SOUTH);

        add(panelBottom, BorderLayout.SOUTH);

        // --- 4. Gắn Sự Kiện (Event Listeners) ---
        setupListeners();
        loadData(""); // Tải dữ liệu ban đầu
    }

    private JButton createButton(String text, Color bgColor) {
        JButton btn = new JButton(text);
        btn.setBackground(bgColor);
        // Nếu là nút màu sáng (Vàng Cập Nhật), đổi màu chữ sang tối để dễ nhìn
        if (bgColor.equals(new Color(241, 196, 15))) {
            btn.setForeground(new Color(40, 40, 40));
        } else {
            btn.setForeground(Color.BLACK);
        }
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(110, 35));
        return btn;
    }

    private void setupListeners() {
        // Sự kiện click vào bảng để đẩy dữ liệu lên form
        table.getSelectionModel().addListSelectionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                Object valTieuDe = tableModel.getValueAt(selectedRow, 1);
                Object valNoiDung = tableModel.getValueAt(selectedRow, 2);
                txtTieuDe.setText(valTieuDe != null ? valTieuDe.toString() : "");
                txtNoiDung.setText(valNoiDung != null ? valNoiDung.toString() : "");
            }
        });

        // Nút Tìm Kiếm
        btnTimKiem.addActionListener(e -> loadData(txtTimKiem.getText().trim()));
        txtTimKiem.addActionListener(e -> loadData(txtTimKiem.getText().trim())); // Cho phép nhấn Enter để tìm

        // Nút Làm Mới
        btnLamMoi.addActionListener(e -> {
            txtTimKiem.setText("");
            txtTieuDe.setText("");
            txtNoiDung.setText("");
            table.clearSelection();
            loadData("");
        });

        // Nút Thêm Mới
        btnThem.addActionListener(e -> addThongBao());

        // Nút Cập Nhật (Sửa)
        btnSua.addActionListener(e -> updateThongBao());

        // Nút Xóa
        btnXoa.addActionListener(e -> deleteThongBao());
    }

    // --- CÁC PHƯƠNG THỨC THAO TÁC CƠ SỞ DỮ LIỆU ---

    private void loadData(String keyword) {
        tableModel.setRowCount(0);
        String sql = "SELECT * FROM thong_bao WHERE tieu_de LIKE ? OR noi_dung LIKE ? ORDER BY id DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");

            try (ResultSet rs = ps.executeQuery()) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String tieuDe = rs.getString("tieu_de");
                    String noiDung = rs.getString("noi_dung");
                    Timestamp ngayTaoTs = rs.getTimestamp("ngay_tao");

                    String ngayTao = "";
                    if (ngayTaoTs != null) {
                        ngayTao = ngayTaoTs.toLocalDateTime().format(formatter);
                    }

                    tableModel.addRow(new Object[]{id, tieuDe, noiDung, ngayTao});
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi tải dữ liệu thông báo: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addThongBao() {
        String tieuDe = txtTieuDe.getText().trim();
        String noiDung = txtNoiDung.getText().trim();

        if (tieuDe.isEmpty() || noiDung.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ Tiêu đề và Nội dung!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql = "INSERT INTO thong_bao (tieu_de, noi_dung, ngay_tao) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, tieuDe);
            ps.setString(2, noiDung);
            ps.setString(3, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Thêm thông báo thành công!");
            btnLamMoi.doClick();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi khi thêm: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateThongBao() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn thông báo cần sửa từ bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String tieuDe = txtTieuDe.getText().trim();
        String noiDung = txtNoiDung.getText().trim();
        int id = (int) tableModel.getValueAt(selectedRow, 0);

        if (tieuDe.isEmpty() || noiDung.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tiêu đề và nội dung không được để trống!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql = "UPDATE thong_bao SET tieu_de = ?, noi_dung = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, tieuDe);
            ps.setString(2, noiDung);
            ps.setInt(3, id);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Cập nhật thông báo thành công!");
            loadData(txtTimKiem.getText().trim());

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteThongBao() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn thông báo cần xóa từ bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) tableModel.getValueAt(selectedRow, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa thông báo này không?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            String sql = "DELETE FROM thong_bao WHERE id = ?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, id);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Xóa thông báo thành công!");
                btnLamMoi.doClick();

            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi khi xóa: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}