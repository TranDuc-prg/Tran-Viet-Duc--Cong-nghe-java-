package vn.edu.eaut.service;

import vn.edu.eaut.dao.PhongBanDAO;
import vn.edu.eaut.model.PhongBan;

import java.util.List;

public class PhongBanService {
    private PhongBanDAO phongBanDAO = new PhongBanDAO();

    public List<PhongBan> getAllPhongBan() {
        return phongBanDAO.getAllPhongBan();
    }

    public boolean addPhongBan(PhongBan pb) {
        return phongBanDAO.addPhongBan(pb);
    }
}