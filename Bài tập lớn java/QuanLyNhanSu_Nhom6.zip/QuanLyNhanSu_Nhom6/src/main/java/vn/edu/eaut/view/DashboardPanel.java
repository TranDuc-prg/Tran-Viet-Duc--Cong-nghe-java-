package vn.edu.eaut.view;

import vn.edu.eaut.connection.DatabaseConnection;
import vn.edu.eaut.service.ThongKeService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DashboardPanel extends JPanel {
    private JLabel lblTongNV, lblPhongBan, lblChamCongHomNay, lblChoDuyet;
    private JPanel pnlActivityContent, pnlWarningContent;
    private PieChartPanel pnlPieChart;
    private AttendanceChartPanel pnlAttendanceChart;
    private ThongKeService thongKeService;

    public DashboardPanel() {
        thongKeService = new ThongKeService();

        setLayout(new BorderLayout(15, 15));
        setBackground(UITheme.BG);
        setBorder(new EmptyBorder(15, 15, 15, 15));

        // Tiêu đề phía trên kèm nút Làm mới dữ liệu
        JPanel pnlTop = new JPanel(new BorderLayout());
        pnlTop.setOpaque(false);

        JLabel lblWelcome = new JLabel("Tổng quan hệ thống quản lý nhân sự");
        lblWelcome.setFont(UITheme.font(Font.BOLD, 20));
        lblWelcome.setForeground(UITheme.NAVY);
        pnlTop.add(lblWelcome, BorderLayout.WEST);

        JPanel pnlTopRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        pnlTopRight.setOpaque(false);

        JLabel lblDate = new JLabel("Hôm nay: " + java.time.LocalDate.now());
        lblDate.setFont(UITheme.font(Font.PLAIN, 12));
        lblDate.setForeground(UITheme.MUTED);
        pnlTopRight.add(lblDate);

        JButton btnRefresh = new JButton("🔄 Làm mới");
        btnRefresh.setFont(UITheme.font(Font.BOLD, 12));
        btnRefresh.setBackground(new Color(37, 99, 235));
        btnRefresh.setForeground(Color.BLACK);
        btnRefresh.setOpaque(true);
        btnRefresh.setContentAreaFilled(true);
        btnRefresh.setFocusPainted(false);
        btnRefresh.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
        btnRefresh.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnRefresh.addActionListener(e -> loadDataFromDatabase());
        pnlTopRight.add(btnRefresh);

        pnlTop.add(pnlTopRight, BorderLayout.EAST);
        add(pnlTop, BorderLayout.NORTH);

        // Container chính chứa toàn bộ các khối (có thanh cuộn tổng)
        JPanel pnlMainBody = new JPanel();
        pnlMainBody.setLayout(new BoxLayout(pnlMainBody, BoxLayout.Y_AXIS));
        pnlMainBody.setOpaque(false);

        // 1. 4 Thẻ thống kê (Cards)
        JPanel pnlCards = new JPanel(new GridLayout(1, 4, 15, 0));
        pnlCards.setOpaque(false);
        pnlCards.setPreferredSize(new Dimension(0, 95));
        pnlCards.setMaximumSize(new Dimension(Integer.MAX_VALUE, 95));

        lblTongNV = new JLabel("0", JLabel.CENTER);
        lblPhongBan = new JLabel("0", JLabel.CENTER);
        lblChamCongHomNay = new JLabel("0", JLabel.CENTER);
        lblChoDuyet = new JLabel("0", JLabel.CENTER);

        pnlCards.add(createCard("Tổng Nhân Viên", lblTongNV, new Color(37, 99, 235)));
        pnlCards.add(createCard("Phòng Ban", lblPhongBan, new Color(13, 148, 136)));
        pnlCards.add(createCard("Chấm Công Hôm Nay", lblChamCongHomNay, new Color(22, 163, 74)));
        pnlCards.add(createCard("Đơn Chờ Duyệt", lblChoDuyet, new Color(217, 119, 6)));

        // 2. Hàng chứa 2 Biểu đồ song song
        JPanel pnlChartsRow = new JPanel(new GridLayout(1, 2, 15, 0));
        pnlChartsRow.setOpaque(false);
        pnlChartsRow.setPreferredSize(new Dimension(0, 310));
        pnlChartsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 310));

        pnlPieChart = new PieChartPanel();
        JPanel pnlPieSection = wrapInSection("Tỷ lệ nhân sự theo phòng ban", pnlPieChart);

        pnlAttendanceChart = new AttendanceChartPanel();
        JPanel pnlAttendanceSection = wrapInSection("Trạng thái chấm công hôm nay", pnlAttendanceChart);

        pnlChartsRow.add(pnlPieSection);
        pnlChartsRow.add(pnlAttendanceSection);

        // 3. Hàng dưới: Chia đôi 2 cột (Hoạt động chấm công gần đây & Cảnh báo hệ thống)
        JPanel pnlBottomRow = new JPanel(new GridLayout(1, 2, 15, 0));
        pnlBottomRow.setOpaque(false);
        pnlBottomRow.setPreferredSize(new Dimension(0, 240));
        pnlBottomRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 240));

        pnlActivityContent = new JPanel();
        pnlActivityContent.setLayout(new BoxLayout(pnlActivityContent, BoxLayout.Y_AXIS));
        pnlActivityContent.setBackground(Color.WHITE);
        JScrollPane scrollActivity = new JScrollPane(pnlActivityContent);
        scrollActivity.setBorder(null);
        scrollActivity.getViewport().setBackground(Color.WHITE);
        JPanel pnlActivitySection = wrapInSection("Hoạt động chấm công gần đây", scrollActivity);

        pnlWarningContent = new JPanel();
        pnlWarningContent.setLayout(new BoxLayout(pnlWarningContent, BoxLayout.Y_AXIS));
        pnlWarningContent.setBackground(Color.WHITE);
        JScrollPane scrollWarning = new JScrollPane(pnlWarningContent);
        scrollWarning.setBorder(null);
        scrollWarning.getViewport().setBackground(Color.WHITE);
        JPanel pnlWarningSection = wrapInSection("Cảnh báo & Đơn chờ xử lý hệ thống", scrollWarning);

        pnlBottomRow.add(pnlActivitySection);
        pnlBottomRow.add(pnlWarningSection);

        // Lắp ráp vào thân chính
        pnlMainBody.add(pnlCards);
        pnlMainBody.add(Box.createVerticalStrut(15));
        pnlMainBody.add(pnlChartsRow);
        pnlMainBody.add(Box.createVerticalStrut(15));
        pnlMainBody.add(pnlBottomRow);

        JScrollPane scrollMain = new JScrollPane(pnlMainBody);
        scrollMain.setBorder(null);
        scrollMain.setOpaque(false);
        scrollMain.getViewport().setOpaque(false);
        scrollMain.getVerticalScrollBar().setUnitIncrement(16);

        add(scrollMain, BorderLayout.CENTER);

        loadDataFromDatabase();
    }

    public void loadDataFromDatabase() {
        lblTongNV.setText(String.valueOf(thongKeService.getTongNhanVien()));
        lblPhongBan.setText(String.valueOf(thongKeService.getTongPhongBan()));
        lblChamCongHomNay.setText(String.valueOf(thongKeService.getChamCongHomNay()));
        lblChoDuyet.setText(String.valueOf(thongKeService.getDonChoDuyet()));

        pnlActivityContent.removeAll();
        List<String> activities = thongKeService.getHoạtDongGầnĐây();
        for (String act : activities) {
            JLabel lbl = new JLabel(act);
            lbl.setFont(UITheme.font(Font.PLAIN, 12));
            lbl.setForeground(UITheme.NAVY);
            lbl.setBorder(new EmptyBorder(5, 5, 5, 5));
            pnlActivityContent.add(lbl);
        }
        pnlActivityContent.revalidate();
        pnlActivityContent.repaint();

        pnlWarningContent.removeAll();
        List<String> warnings = thongKeService.getCanhBaoHeThong();
        for (String warn : warnings) {
            JLabel lbl = new JLabel(warn);
            lbl.setFont(UITheme.font(Font.PLAIN, 12));
            lbl.setForeground(new Color(192, 57, 43));
            lbl.setBorder(new EmptyBorder(6, 5, 6, 5));
            pnlWarningContent.add(lbl);
        }
        pnlWarningContent.revalidate();
        pnlWarningContent.repaint();

        pnlPieChart.loadChartData();
        pnlAttendanceChart.loadChartData();
    }

    private JPanel createCard(String title, JLabel valueLabel, Color accentColor) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, accentColor),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(UITheme.font(Font.BOLD, 12));
        lblTitle.setForeground(UITheme.MUTED);

        valueLabel.setFont(UITheme.font(Font.BOLD, 24));
        valueLabel.setForeground(accentColor);

        card.add(lblTitle, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    private JPanel wrapInSection(String title, JComponent content) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(226, 232, 240)),
                new EmptyBorder(10, 12, 10, 12)
        ));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(UITheme.font(Font.BOLD, 13));
        lblTitle.setForeground(UITheme.NAVY);
        lblTitle.setBorder(new EmptyBorder(0, 0, 8, 0));

        panel.add(lblTitle, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        return panel;
    }

    // 1. Biểu đồ tròn (Pie Chart) - Tỷ lệ nhân sự phòng ban
    private static class PieChartPanel extends JPanel {
        private final List<String> phongBans = new ArrayList<>();
        private final List<Integer> soLuongs = new ArrayList<>();

        private final Color[] COLORS = {
                new Color(37, 99, 235),
                new Color(13, 148, 136),
                new Color(22, 163, 74),
                new Color(217, 119, 6),
                new Color(147, 51, 234),
                new Color(225, 29, 72),
                new Color(14, 165, 233),
                new Color(234, 179, 8)
        };

        public PieChartPanel() {
            setBackground(Color.WHITE);
            loadChartData();
        }

        public void loadChartData() {
            phongBans.clear();
            soLuongs.clear();
            String sql = "SELECT pb.ten_phong_ban, COUNT(nv.id) as sl " +
                    "FROM phong_ban pb LEFT JOIN nhan_vien nv ON pb.id = nv.phong_ban_id " +
                    "GROUP BY pb.id, pb.ten_phong_ban";
            try (Connection conn = DatabaseConnection.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    String ten = rs.getString("ten_phong_ban");
                    phongBans.add(ten != null ? ten : "Khác");
                    soLuongs.add(rs.getInt("sl"));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (phongBans.isEmpty()) return;

            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int width = getWidth();
            int height = getHeight();

            int total = 0;
            for (int val : soLuongs) total += val;
            if (total == 0) total = 1;

            int diameter = Math.min(height - 20, 150);
            int xPie = 15;
            int yPie = (height - diameter) / 2;

            int startAngle = 0;
            for (int i = 0; i < phongBans.size(); i++) {
                int val = soLuongs.get(i);
                int arcAngle = (int) Math.round((double) val / total * 360);
                if (i == phongBans.size() - 1) {
                    arcAngle = 360 - startAngle;
                }

                g2.setColor(COLORS[i % COLORS.length]);
                g2.fillArc(xPie, yPie, diameter, diameter, startAngle, arcAngle);

                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawArc(xPie, yPie, diameter, diameter, startAngle, arcAngle);

                startAngle += arcAngle;
            }

            int legendX = xPie + diameter + 15;
            int legendYStart = 10;
            int rowHeight = 20;

            g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            for (int i = 0; i < phongBans.size(); i++) {
                if (legendYStart + (i * rowHeight) > height - 10) break;

                String name = phongBans.get(i);
                int val = soLuongs.get(i);
                double percent = (double) val / total * 100;
                int currentY = legendYStart + (i * rowHeight);

                g2.setColor(COLORS[i % COLORS.length]);
                g2.fillRoundRect(legendX, currentY + 3, 10, 10, 3, 3);

                g2.setColor(new Color(51, 65, 85));
                String text = name + " (" + val + " - " + String.format("%.0f", percent) + "%)";
                if (text.length() > 25) text = text.substring(0, 22) + "...";
                g2.drawString(text, legendX + 16, currentY + 13);
            }
        }
    }

    // 2. Biểu đồ cột dọc kết hợp bảng chú thích (Legend) trạng thái chấm công
    private static class AttendanceChartPanel extends JPanel {
        private int dungGio = 0;
        private int diTre = 0;
        private int nghiPhep = 0;
        private int chuaChamCong = 0;

        private final Color[] barColors = {
                new Color(22, 163, 74),   // Xanh lá (Đúng giờ)
                new Color(217, 119, 6),   // Cam (Đi trễ)
                new Color(147, 51, 234),  // Tím (Nghỉ phép)
                new Color(148, 163, 184)  // Xám (Chưa chấm công)
        };
        private final String[] labels = {"Đúng giờ", "Đi trễ", "Nghỉ phép", "Chưa chấm công"};

        public AttendanceChartPanel() {
            setBackground(Color.WHITE);
            loadChartData();
        }

        public void loadChartData() {
            String today = java.time.LocalDate.now().toString();

            dungGio = 0;
            diTre = 0;
            nghiPhep = 0;

            // 1. Lấy dữ liệu từ bảng chấm công sử dụng cột ngay_gio (DATETIME) đúng với cơ sở dữ liệu
            String sqlCC = "SELECT trang_thai, COUNT(*) as sl FROM cham_cong WHERE DATE(ngay_gio) = '" + today + "' GROUP BY trang_thai";
            try (Connection conn = DatabaseConnection.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlCC)) {
                while (rs.next()) {
                    String status = rs.getString("trang_thai");
                    int sl = rs.getInt("sl");
                    if (status != null) {
                        if (status.equalsIgnoreCase("Đúng giờ") || status.equalsIgnoreCase("Vào ca")) {
                            dungGio += sl; // Gom nhóm "Vào ca" hoặc "Đúng giờ" chung vào mục chuyên cần
                        } else if (status.equalsIgnoreCase("Đi trễ")) {
                            diTre += sl;
                        } else if (status.equalsIgnoreCase("Nghỉ phép")) {
                            nghiPhep += sl;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            // 2. Lấy số lượng nhân viên đang được duyệt nghỉ phép trong ngày hôm nay từ bảng nghi_phep
            try (Connection conn = DatabaseConnection.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT COUNT(DISTINCT nhan_vien_id) FROM nghi_phep WHERE trang_thai = 'Đã duyệt' AND '" + today + "' BETWEEN ngay_bat_dau AND ngay_ket_thuc")) {
                if (rs.next()) {
                    int npCount = rs.getInt(1);
                    if (npCount > nghiPhep) {
                        nghiPhep = npCount;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Lấy tổng nhân viên để tính số chưa chấm công
            int totalNV = 13;
            try (Connection conn = DatabaseConnection.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM nhan_vien")) {
                if (rs.next()) totalNV = rs.getInt(1);
            } catch (Exception ignored) {}

            chuaChamCong = Math.max(0, totalNV - (dungGio + diTre + nghiPhep));
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int width = getWidth();
            int height = getHeight();

            int legendWidth = 140;
            int chartAreaWidth = width - legendWidth - 10;
            int padding = 20;
            int chartHeight = height - 40;

            int[] values = {dungGio, diTre, nghiPhep, chuaChamCong};
            int maxVal = 1;
            for (int v : values) if (v > maxVal) maxVal = v;

            int n = values.length;
            int colWidth = chartAreaWidth / n;
            int barWidth = Math.min(30, colWidth - 12);

            // Vẽ đường lưới ngang
            g2.setColor(new Color(235, 238, 242));
            for (int i = 0; i <= 4; i++) {
                int y = padding + (chartHeight * i / 4);
                g2.drawLine(padding, y, chartAreaWidth, y);
            }

            // Vẽ các cột biểu đồ
            for (int i = 0; i < n; i++) {
                int val = values[i];
                int barH = (int) ((double) val / maxVal * (chartHeight - 30));
                int x = padding + i * colWidth + (colWidth - barWidth) / 2;
                int y = padding + chartHeight - barH;

                g2.setColor(barColors[i]);
                g2.fillRoundRect(x, y, barWidth, barH, 5, 5);

                // Số lượng trên đầu cột
                g2.setFont(new Font("Segoe UI", Font.BOLD, 11));
                g2.setColor(new Color(51, 65, 85));
                String valStr = String.valueOf(val);
                int strW = g2.getFontMetrics().stringWidth(valStr);
                g2.drawString(valStr, x + (barWidth - strW) / 2, y - 5);
            }

            // Vẽ bảng chú thích (Legend) ở bên phải biểu đồ
            int legendX = chartAreaWidth + 10;
            int legendYStart = 25;
            int rowHeight = 25;

            g2.setFont(new Font("Segoe UI", Font.BOLD, 11));
            g2.setColor(new Color(30, 41, 59));
            g2.drawString("Chú thích trạng thái:", legendX, legendYStart);

            g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            for (int i = 0; i < n; i++) {
                int currentY = legendYStart + 18 + (i * rowHeight);

                g2.setColor(barColors[i]);
                g2.fillRoundRect(legendX, currentY, 12, 12, 3, 3);

                g2.setColor(new Color(51, 65, 85));
                String text = labels[i] + " (" + values[i] + ")";
                g2.drawString(text, legendX + 18, currentY + 10);
            }
        }
    }
}