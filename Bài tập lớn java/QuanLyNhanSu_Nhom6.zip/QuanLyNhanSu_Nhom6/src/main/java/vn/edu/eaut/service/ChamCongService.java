package vn.edu.eaut.service;

import vn.edu.eaut.connection.DatabaseConnection;
import vn.edu.eaut.model.ChamCong;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ChamCongService {

    /**
     * Kiểm tra xem nhân viên đã có đơn nghỉ phép được duyệt trong ngày hay chưa.
     * @param maNV Mã nhân viên
     * @param ngayChamCong Ngày chấm công (Định dạng: YYYY-MM-DD)
     * @return true nếu tồn tại đơn nghỉ phép đã duyệt, ngược lại trả về false.
     */
    public boolean kiemTraNghiPhepDaDuyet(String maNV, String ngayChamCong) {
        // Câu lệnh SQL kiểm tra ngày chấm công nằm trong khoảng từ_ngay và den_ngay của đơn đã duyệt
        String query = "SELECT COUNT(*) FROM nghi_phep WHERE ma_nv = ? AND ? BETWEEN tu_ngay AND den_ngay AND trang_thai = N'Đã duyệt'";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, maNV);
            pstmt.setString(2, ngayChamCong);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Các hàm xử lý chấm công khác có sẵn trong Service của bạn (ví dụ: thêm, sửa, xóa, lấy danh sách...)
    // ...
}