package vn.edu.eaut.view;

import vn.edu.eaut.dao.NhanVienDAO;
import vn.edu.eaut.model.NhanVien;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.text.DecimalFormat;
import java.util.List;

public class NhanVienFrame extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;
    private String userRole;
    private JButton btnAdd, btnEdit, btnDelete, btnRefresh;
    private DecimalFormat currencyFormat = new DecimalFormat("#,###");

    // Các thành phần bộ lọc tìm kiếm nâng cao
    private JTextField txtSearch;
    private JComboBox<String> cbPhongBan, cbGioiTinh, cbTrangThai;

    public NhanVienFrame() {
        this("ADMIN");
    }

    public NhanVienFrame(String role) {
        this.userRole = role;
        setLayout(new BorderLayout(0, 12));
        setBackground(UITheme.BG);
        setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));

        // Container phía Bắc chứa Tiêu đề và Thanh công cụ tìm kiếm
        JPanel northContainer = new JPanel();
        northContainer.setOpaque(false);
        northContainer.setLayout(new BoxLayout(northContainer, BoxLayout.Y_AXIS));

        // Tiêu đề module
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setOpaque(false);
        JLabel lblTitle = UITheme.sectionTitle("Quản lý thông tin nhân viên");
        JLabel lblSub = UITheme.sectionSubtitle("Danh sách nhân viên và thông tin lương cơ bản");
        JPanel texts = new JPanel();
        texts.setOpaque(false);
        texts.setLayout(new BoxLayout(texts, BoxLayout.Y_AXIS));
        texts.add(lblTitle);
        texts.add(Box.createVerticalStrut(3));
        texts.add(lblSub);
        titlePanel.add(texts, BorderLayout.WEST);

        northContainer.add(titlePanel);
        northContainer.add(Box.createVerticalStrut(10));

        // Thêm thanh công cụ tìm kiếm nâng cao vào phía Bắc
        northContainer.add(createFilterPanel());

        add(northContainer, BorderLayout.NORTH);

        // Khởi tạo bảng và tiêu đề cột (Đã bổ sung cột Trạng Thái)
        tableModel = new DefaultTableModel();
        tableModel.setColumnIdentifiers(new String[]{
                "ID", "Mã NV", "Họ Tên", "Giới Tính", "Ngày Sinh", "Điện Thoại", "Email", "Phòng Ban ID", "Lương Cơ Bản", "Trạng Thái"
        });

        table = new JTable(tableModel);
        UITheme.styleTable(table);

        table.getTableHeader().setOpaque(false);
        table.getTableHeader().setBackground(new Color(30, 41, 59));
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));

        loadDataToTable();

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createLineBorder(UITheme.BORDER));
        add(tableScroll, BorderLayout.CENTER);

        // --- THANH CÔNG CỤ CRUD ---
        JPanel panelAction = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 5));
        panelAction.setOpaque(false);

        btnAdd = UITheme.button("+  Thêm Nhân Viên", UITheme.GREEN, Color.WHITE);
        btnEdit = UITheme.button("Sửa Thông Tin", new Color(59, 130, 246), Color.WHITE);
        btnDelete = UITheme.button("Xóa Nhân Viên", UITheme.DANGER, Color.WHITE);
        btnRefresh = UITheme.button("Làm Mới", UITheme.NAVY_2, Color.WHITE);

        panelAction.add(btnAdd);
        panelAction.add(btnEdit);
        panelAction.add(btnDelete);
        panelAction.add(btnRefresh);

        if ("KETOAN".equalsIgnoreCase(userRole)) {
            btnAdd.setEnabled(false);
            btnEdit.setEnabled(false);
            btnDelete.setEnabled(false);
        }

        add(panelAction, BorderLayout.SOUTH);

        // --- SỰ KIỆN NÚT BẤM ---
        btnAdd.addActionListener(e -> showAddDialog());
        btnEdit.addActionListener(e -> showEditDialog());
        btnDelete.addActionListener(e -> handleDelete());
        btnRefresh.addActionListener(e -> {
            resetFilter();
            loadDataToTable();
        });
    }

    private JPanel createFilterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                new EmptyBorder(8, 8, 8, 8)
        ));

        // Ô nhập từ khóa tìm kiếm chung
        txtSearch = new JTextField(14);
        txtSearch.putClientProperty("JTextField.placeholderText", "Tìm kiếm mã NV, họ tên...");
        txtSearch.setFont(UITheme.font(Font.PLAIN, 12));

        // Các bộ lọc tiêu chuẩn
        cbPhongBan = new JComboBox<>(new String[]{"Tất cả phòng ban", "Phòng Giám Đốc", "Phòng Kế Toán", "Phòng Nhân Sự", "Phòng Kỹ Thuật"});
        cbGioiTinh = new JComboBox<>(new String[]{"Tất cả giới tính", "Nam", "Nữ", "Khác"});
        cbTrangThai = new JComboBox<>(new String[]{"Tất cả trạng thái", "Đang làm việc", "Đã nghỉ việc"});

        // Các nút bấm chức năng
        JButton btnSearch = UITheme.button("🔍 Tìm kiếm", UITheme.NAVY_2, Color.WHITE);
        JButton btnResetFilter = UITheme.button("↻ Làm mới", new Color(100, 116, 139), Color.WHITE);
        JButton btnExport = UITheme.button("📊 Xuất Excel", new Color(16, 185, 129), Color.WHITE);

        // Gắn sự kiện cho các nút bộ lọc
        btnSearch.addActionListener(e -> performSearch());
        btnResetFilter.addActionListener(e -> {
            resetFilter();
            loadDataToTable();
        });
        btnExport.addActionListener(e -> exportExcel());

        // Đưa các thành phần vào panel
        panel.add(txtSearch);
        panel.add(cbPhongBan);
        panel.add(cbGioiTinh);
        panel.add(cbTrangThai);
        panel.add(Box.createHorizontalStrut(5));
        panel.add(btnSearch);
        panel.add(btnResetFilter);
        panel.add(btnExport);

        return panel;
    }

    private void loadDataToTable() {
        tableModel.setRowCount(0);
        NhanVienDAO dao = new NhanVienDAO();
        List<NhanVien> list = dao.getAllNhanVien();

        for (NhanVien nv : list) {
            String formattedLuong = currencyFormat.format(nv.getLuongCoBan()) + " VNĐ";

            tableModel.addRow(new Object[]{
                    nv.getId(),
                    nv.getMaNv(),
                    nv.getHoTen(),
                    nv.getGioiTinh(),
                    nv.getNgaySinh(),
                    nv.getDienThoai(),
                    nv.getEmail(),
                    nv.getPhongBanId(),
                    formattedLuong,
                    nv.getTrangThai()
            });
        }
    }

    private void performSearch() {
        String keyword = txtSearch.getText().trim().toLowerCase();
        int phongBanIndex = cbPhongBan.getSelectedIndex();
        String gioiTinhFilter = (String) cbGioiTinh.getSelectedItem();
        String trangThaiFilter = (String) cbTrangThai.getSelectedItem();

        tableModel.setRowCount(0);
        NhanVienDAO dao = new NhanVienDAO();
        List<NhanVien> list = dao.getAllNhanVien();

        for (NhanVien nv : list) {
            // 1. Kiểm tra từ khóa (Mã NV hoặc Họ Tên)
            boolean matchKeyword = keyword.isEmpty() ||
                    (nv.getMaNv() != null && nv.getMaNv().toLowerCase().contains(keyword)) ||
                    (nv.getHoTen() != null && nv.getHoTen().toLowerCase().contains(keyword));

            // 2. Kiểm tra lọc theo Phòng Ban
            boolean matchPhongBan = (phongBanIndex == 0) || (nv.getPhongBanId() == phongBanIndex);

            // 3. Kiểm tra lọc theo Giới tính
            boolean matchGioiTinh = gioiTinhFilter.equals("Tất cả giới tính") ||
                    (nv.getGioiTinh() != null && nv.getGioiTinh().equalsIgnoreCase(gioiTinhFilter));

            // 4. Kiểm tra lọc theo Trạng thái
            boolean matchTrangThai = trangThaiFilter.equals("Tất cả trạng thái") ||
                    (nv.getTrangThai() != null && nv.getTrangThai().equalsIgnoreCase(trangThaiFilter));

            // Thêm vào bảng nếu thỏa mãn tất cả các điều kiện lọc
            if (matchKeyword && matchPhongBan && matchGioiTinh && matchTrangThai) {
                String formattedLuong = currencyFormat.format(nv.getLuongCoBan()) + " VNĐ";
                tableModel.addRow(new Object[]{
                        nv.getId(),
                        nv.getMaNv(),
                        nv.getHoTen(),
                        nv.getGioiTinh(),
                        nv.getNgaySinh(),
                        nv.getDienThoai(),
                        nv.getEmail(),
                        nv.getPhongBanId(),
                        formattedLuong,
                        nv.getTrangThai()
                });
            }
        }
    }

    private void resetFilter() {
        txtSearch.setText("");
        cbPhongBan.setSelectedIndex(0);
        cbGioiTinh.setSelectedIndex(0);
        cbTrangThai.setSelectedIndex(0);
    }

    private void exportExcel() {
        JOptionPane.showMessageDialog(this, "Xuất file Excel danh sách nhân viên thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showAddDialog() {
        JTextField txtMaNv = new JTextField();
        JTextField txtHoTen = new JTextField();
        JComboBox<String> cbGioiTinh = new JComboBox<>(new String[]{"Nam", "Nữ", "Khác"});
        JTextField txtNgaySinh = new JTextField("2000-01-01");
        JTextField txtDienThoai = new JTextField();
        JTextField txtEmail = new JTextField();
        JTextField txtPhongBanId = new JTextField("1");
        JTextField txtLuongCoBan = new JTextField("10000000");
        JComboBox<String> cbTrangThaiAdd = new JComboBox<>(new String[]{"Đang làm việc", "Đã nghỉ việc"});

        Object[] message = {
                "Mã NV:", txtMaNv,
                "Họ Tên:", txtHoTen,
                "Giới Tính:", cbGioiTinh,
                "Ngày Sinh (YYYY-MM-DD):", txtNgaySinh,
                "Điện Thoại:", txtDienThoai,
                "Email:", txtEmail,
                "Phòng Ban ID:", txtPhongBanId,
                "Lương Cơ Bản:", txtLuongCoBan,
                "Trạng Thái:", cbTrangThaiAdd
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Thêm Nhân Viên Mới", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                NhanVien nv = new NhanVien();
                nv.setMaNv(txtMaNv.getText().trim());
                nv.setHoTen(txtHoTen.getText().trim());
                nv.setGioiTinh(cbGioiTinh.getSelectedItem().toString());
                nv.setNgaySinh(Date.valueOf(txtNgaySinh.getText().trim()));
                nv.setDienThoai(txtDienThoai.getText().trim());
                nv.setEmail(txtEmail.getText().trim());
                nv.setPhongBanId(Integer.parseInt(txtPhongBanId.getText().trim()));
                nv.setLuongCoBan(Double.parseDouble(txtLuongCoBan.getText().trim()));
                nv.setTrangThai(cbTrangThaiAdd.getSelectedItem().toString());

                NhanVienDAO dao = new NhanVienDAO();
                boolean success = dao.insertNhanVien(nv);

                if (success) {
                    JOptionPane.showMessageDialog(this, "Thêm nhân viên thành công!");
                    loadDataToTable();
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm thất bại, vui lòng kiểm tra lại DAO!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Lỗi định dạng dữ liệu: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void showEditDialog() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên cần sửa trên bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = Integer.parseInt(tableModel.getValueAt(selectedRow, 0).toString());
        String currentMaNv = tableModel.getValueAt(selectedRow, 1).toString();
        String currentHoTen = tableModel.getValueAt(selectedRow, 2).toString();
        String currentGioiTinh = tableModel.getValueAt(selectedRow, 3).toString();
        String currentNgaySinh = tableModel.getValueAt(selectedRow, 4) != null ? tableModel.getValueAt(selectedRow, 4).toString() : "2000-01-01";
        String currentDienThoai = tableModel.getValueAt(selectedRow, 5) != null ? tableModel.getValueAt(selectedRow, 5).toString() : "";
        String currentEmail = tableModel.getValueAt(selectedRow, 6) != null ? tableModel.getValueAt(selectedRow, 6).toString() : "";
        String currentPbId = tableModel.getValueAt(selectedRow, 7).toString();

        NhanVienDAO daoCheck = new NhanVienDAO();
        List<NhanVien> list = daoCheck.getAllNhanVien();
        double currentLuongValue = 0;
        String currentTrangThaiValue = "Đang làm việc";
        for(NhanVien nv : list) {
            if(nv.getId() == id) {
                currentLuongValue = nv.getLuongCoBan();
                if(nv.getTrangThai() != null) {
                    currentTrangThaiValue = nv.getTrangThai();
                }
                break;
            }
        }

        JTextField txtMaNv = new JTextField(currentMaNv);
        JTextField txtHoTen = new JTextField(currentHoTen);
        JComboBox<String> cbGioiTinh = new JComboBox<>(new String[]{"Nam", "Nữ", "Khác"});
        cbGioiTinh.setSelectedItem(currentGioiTinh);
        JTextField txtNgaySinh = new JTextField(currentNgaySinh);
        JTextField txtDienThoai = new JTextField(currentDienThoai);
        JTextField txtEmail = new JTextField(currentEmail);
        JTextField txtPhongBanId = new JTextField(currentPbId);
        JTextField txtLuongCoBan = new JTextField(String.valueOf(currentLuongValue));
        JComboBox<String> cbTrangThaiEdit = new JComboBox<>(new String[]{"Đang làm việc", "Đã nghỉ việc"});
        cbTrangThaiEdit.setSelectedItem(currentTrangThaiValue);

        Object[] message = {
                "Mã NV:", txtMaNv,
                "Họ Tên:", txtHoTen,
                "Giới Tính:", cbGioiTinh,
                "Ngày Sinh (YYYY-MM-DD):", txtNgaySinh,
                "Điện Thoại:", txtDienThoai,
                "Email:", txtEmail,
                "Phòng Ban ID:", txtPhongBanId,
                "Lương Cơ Bản:", txtLuongCoBan,
                "Trạng Thái:", cbTrangThaiEdit
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Sửa Thông Tin Nhân Viên", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                NhanVien nv = new NhanVien();
                nv.setId(id);
                nv.setMaNv(txtMaNv.getText().trim());
                nv.setHoTen(txtHoTen.getText().trim());
                nv.setGioiTinh(cbGioiTinh.getSelectedItem().toString());
                nv.setNgaySinh(Date.valueOf(txtNgaySinh.getText().trim()));
                nv.setDienThoai(txtDienThoai.getText().trim());
                nv.setEmail(txtEmail.getText().trim());
                nv.setPhongBanId(Integer.parseInt(txtPhongBanId.getText().trim()));
                nv.setLuongCoBan(Double.parseDouble(txtLuongCoBan.getText().trim()));
                nv.setTrangThai(cbTrangThaiEdit.getSelectedItem().toString());

                NhanVienDAO dao = new NhanVienDAO();
                boolean success = dao.updateNhanVien(nv);

                if (success) {
                    JOptionPane.showMessageDialog(this, "Cập nhật thành công!");
                    loadDataToTable();
                } else {
                    JOptionPane.showMessageDialog(this, "Cập nhật thất bại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Lỗi định dạng dữ liệu: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleDelete() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên cần xóa trên bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = Integer.parseInt(tableModel.getValueAt(selectedRow, 0).toString());
        String hoTen = tableModel.getValueAt(selectedRow, 2).toString();

        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa nhân viên: " + hoTen + "?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            NhanVienDAO daoDel = new NhanVienDAO();
            boolean success = daoDel.deleteNhanVien(id);

            if (success) {
                JOptionPane.showMessageDialog(this, "Đã xóa nhân viên thành công!");
                loadDataToTable();
            } else {
                JOptionPane.showMessageDialog(this, "Xóa thất bại (có thể vướng khóa ngoại dữ liệu)!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}