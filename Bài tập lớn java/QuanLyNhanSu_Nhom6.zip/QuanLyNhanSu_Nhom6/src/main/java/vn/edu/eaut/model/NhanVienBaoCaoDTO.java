package vn.edu.eaut.model;

import java.util.Date;

public class NhanVienBaoCaoDTO {
    private String maNV;
    private String hoTen;
    private String gioiTinh;
    private Date ngaySinh;
    private String phongBan;
    private String chucVu;
    private String trangThai;
    private Date ngayVaoLam;

    // Constructor, Getters, Setters
    public NhanVienBaoCaoDTO(String maNV, String hoTen, String gioiTinh, Date ngaySinh,
                             String phongBan, String chucVu, String trangThai, Date ngayVaoLam) {
        this.maNV = maNV;
        this.hoTen = hoTen;
        this.gioiTinh = gioiTinh;
        this.ngaySinh = ngaySinh;
        this.phongBan = phongBan;
        this.chucVu = chucVu;
        this.trangThai = trangThai;
        this.ngayVaoLam = ngayVaoLam;
    }

    public String getMaNV() { return maNV; }
    public String getHoTen() { return hoTen; }
    public String getGioiTinh() { return gioiTinh; }
    public Date getNgaySinh() { return ngaySinh; }
    public String getPhongBan() { return phongBan; }
    public String getChucVu() { return chucVu; }
    public String getTrangThai() { return trangThai; }
    public Date getNgayVaoLam() { return ngayVaoLam; }
}