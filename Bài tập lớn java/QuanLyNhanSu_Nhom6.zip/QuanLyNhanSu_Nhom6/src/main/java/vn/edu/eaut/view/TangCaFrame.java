package vn.edu.eaut.view;

import vn.edu.eaut.connection.DatabaseConnection;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class TangCaFrame extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField txtMaNV, txtNgayTangCa, txtSoGio, txtHeSo;
    private JComboBox<String> cbTrangThai;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi;

    public TangCaFrame() {
        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(new Color(245, 247, 250));

        // Tiêu đề
        JLabel lblHeader = new JLabel("QUẢN LÝ THÔNG TIN TĂNG CA NHÂN VIÊN", JLabel.CENTER);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblHeader.setForeground(new Color(41, 128, 185));
        lblHeader.setBorder(new EmptyBorder(0, 0, 5, 0));
        add(lblHeader, BorderLayout.NORTH);

        // --- Form nhập liệu bên trái ---
        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setBackground(Color.WHITE);
        panelForm.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(200, 200, 200)),
                        " Thông tin tăng ca ",
                        0, 0, new Font("Segoe UI", Font.BOLD, 13), new Color(41, 128, 185)
                ),
                new EmptyBorder(10, 10, 10, 10)
        ));
        panelForm.setPreferredSize(new Dimension(320, 0));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.weightx = 1.0;

        int row = 0;
        gbc.gridy = row++; panelForm.add(createLabel("Mã Nhân Viên:"), gbc);
        txtMaNV = new JTextField(); styleTextField(txtMaNV);
        gbc.gridy = row++; panelForm.add(txtMaNV, gbc);

        gbc.gridy = row++; panelForm.add(createLabel("Ngày (YYYY-MM-DD):"), gbc);
        txtNgayTangCa = new JTextField(); styleTextField(txtNgayTangCa);
        gbc.gridy = row++; panelForm.add(txtNgayTangCa, gbc);

        gbc.gridy = row++; panelForm.add(createLabel("Số giờ tăng ca:"), gbc);
        txtSoGio = new JTextField(); styleTextField(txtSoGio);
        gbc.gridy = row++; panelForm.add(txtSoGio, gbc);

        gbc.gridy = row++; panelForm.add(createLabel("Hệ số (VD: 1.5):"), gbc);
        txtHeSo = new JTextField("1.5"); styleTextField(txtHeSo);
        gbc.gridy = row++; panelForm.add(txtHeSo, gbc);

        gbc.gridy = row++; panelForm.add(createLabel("Trạng thái:"), gbc);
        cbTrangThai = new JComboBox<>(new String[]{"Chờ duyệt", "Đã duyệt", "Từ chối"});
        cbTrangThai.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cbTrangThai.setBackground(Color.WHITE);
        gbc.gridy = row++; panelForm.add(cbTrangThai, gbc);

        // Panel Nút bấm
        JPanel panelButtons = new JPanel(new GridLayout(2, 2, 10, 10));
        panelButtons.setBackground(Color.WHITE);

        btnThem = new JButton("Thêm mới");
        btnSua = new JButton("Cập nhật");
        btnXoa = new JButton("Xóa bỏ");
        btnLamMoi = new JButton("Làm mới");

        styleButton(btnThem, new Color(46, 204, 113));
        styleButton(btnSua, new Color(230, 126, 34));
        styleButton(btnXoa, new Color(231, 76, 60));
        styleButton(btnLamMoi, new Color(52, 152, 219));

        panelButtons.add(btnThem);
        panelButtons.add(btnSua);
        panelButtons.add(btnXoa);
        panelButtons.add(btnLamMoi);

        gbc.gridy = row++;
        gbc.insets = new Insets(15, 5, 5, 5);
        panelForm.add(panelButtons, gbc);

        gbc.gridy = row++;
        gbc.weighty = 1.0;
        panelForm.add(new JLabel(""), gbc);

        add(panelForm, BorderLayout.WEST);

        // --- Bảng danh sách bên phải (Đã bổ sung cột Trạng Thái) ---
        tableModel = new DefaultTableModel(new String[]{"ID", "Mã NV", "Họ Tên", "Ngày Tăng Ca", "Số Giờ", "Hệ Số", "Trạng Thái"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setPreferredSize(new Dimension(0, 30));

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setBackground(new Color(41, 128, 185));
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        headerRenderer.setFont(new Font("Segoe UI", Font.BOLD, 13));

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(1).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(3).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(6).setPreferredWidth(90);
        table.getColumnModel().getColumn(6).setCellRenderer(centerRenderer);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                " Danh sách tăng ca ",
                0, 0, new Font("Segoe UI", Font.BOLD, 13), new Color(41, 128, 185)
        ));
        add(scrollPane, BorderLayout.CENTER);

        loadDataToTable();
        clearForm();

        // Sự kiện click bảng
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    txtMaNV.setText(tableModel.getValueAt(row, 1).toString());
                    txtNgayTangCa.setText(tableModel.getValueAt(row, 3).toString());
                    txtSoGio.setText(tableModel.getValueAt(row, 4).toString());
                    txtHeSo.setText(tableModel.getValueAt(row, 5).toString());
                    cbTrangThai.setSelectedItem(tableModel.getValueAt(row, 6).toString());
                }
            }
        });

        // Xử lý sự kiện các nút
        btnThem.addActionListener(e -> handleAdd());
        btnSua.addActionListener(e -> handleUpdate());
        btnXoa.addActionListener(e -> handleDelete());
        btnLamMoi.addActionListener(e -> {
            clearForm();
            loadDataToTable();
        });
    }

    private JLabel createLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        return lbl;
    }

    private void styleTextField(JTextField tf) {
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setPreferredSize(new Dimension(0, 28));
    }

    private void styleButton(JButton btn, Color bgColor) {
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void loadDataToTable() {
        tableModel.setRowCount(0);
        // Đã bổ sung t.trang_thai vào câu truy vấn SQL
        String sql = "SELECT t.id, n.ma_nv, n.ho_ten, t.ngay_tang_ca, t.so_gio, t.he_so, t.trang_thai " +
                "FROM tang_ca t " +
                "JOIN nhan_vien n ON t.nhan_vien_id = n.id " +
                "ORDER BY t.id DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("ma_nv"),
                        rs.getString("ho_ten"),
                        rs.getDate("ngay_tang_ca"),
                        rs.getDouble("so_gio"),
                        rs.getDouble("he_so"),
                        rs.getString("trang_thai")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void handleAdd() {
        String maNV = txtMaNV.getText().trim();
        String ngayStr = txtNgayTangCa.getText().trim();
        String soGio = txtSoGio.getText().trim();
        String heSo = txtHeSo.getText().trim();
        String trangThai = cbTrangThai.getSelectedItem().toString();

        if (maNV.isEmpty() || ngayStr.isEmpty() || soGio.isEmpty() || heSo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            LocalDate ngayTangCa = LocalDate.parse(ngayStr);
            LocalDate ngayHienTai = LocalDate.now();

            if (ngayTangCa.isBefore(ngayHienTai)) {
                JOptionPane.showMessageDialog(this,
                        "Không thể thêm tăng ca cho ngày trong quá khứ (" + ngayStr + ")!\nChỉ cho phép cập nhật/sửa các bản ghi đã có.",
                        "Cảnh báo ngày quá hạn", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Định dạng ngày không hợp lệ! Vui lòng nhập định dạng YYYY-MM-DD.", "Lỗi định dạng", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {
            int nhanVienId = -1;
            try (PreparedStatement psNv = conn.prepareStatement("SELECT id FROM nhan_vien WHERE ma_nv = ?")) {
                psNv.setString(1, maNV);
                try (ResultSet rs = psNv.executeQuery()) {
                    if (rs.next()) {
                        nhanVienId = rs.getInt("id");
                    } else {
                        JOptionPane.showMessageDialog(this, "Mã nhân viên không tồn tại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

            // Bổ sung thêm trường trang_thai vào lệnh INSERT
            String sql = "INSERT INTO tang_ca (nhan_vien_id, ngay_tang_ca, so_gio, he_so, trang_thai) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, nhanVienId);
                pstmt.setString(2, ngayStr);
                pstmt.setDouble(3, Double.parseDouble(soGio));
                pstmt.setDouble(4, Double.parseDouble(heSo));
                pstmt.setString(5, trangThai);
                pstmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Thêm tăng ca thành công!");
                loadDataToTable();
                clearForm();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi thêm dữ liệu! Kiểm tra số giờ/hệ số.", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleUpdate() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn dòng cần cập nhật trên bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = Integer.parseInt(tableModel.getValueAt(row, 0).toString());

        // Bổ sung cập nhật trạng thái vào câu lệnh UPDATE
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE tang_ca SET ngay_tang_ca = ?, so_gio = ?, he_so = ?, trang_thai = ? WHERE id = ?")) {
            pstmt.setString(1, txtNgayTangCa.getText().trim());
            pstmt.setDouble(2, Double.parseDouble(txtSoGio.getText().trim()));
            pstmt.setDouble(3, Double.parseDouble(txtHeSo.getText().trim()));
            pstmt.setString(4, cbTrangThai.getSelectedItem().toString());
            pstmt.setInt(5, id);
            pstmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Cập nhật thành công!");
            loadDataToTable();
            clearForm();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi cập nhật dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleDelete() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn dòng cần xóa trên bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = Integer.parseInt(tableModel.getValueAt(row, 0).toString());
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa bản ghi này?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement("DELETE FROM tang_ca WHERE id = ?")) {
                pstmt.setInt(1, id);
                pstmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Xóa thành công!");
                loadDataToTable();
                clearForm();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private void clearForm() {
        txtMaNV.setText("");
        txtNgayTangCa.setText(LocalDate.now().toString());
        txtSoGio.setText("");
        txtHeSo.setText("1.5");
        cbTrangThai.setSelectedItem("Chờ duyệt");
        table.clearSelection();
    }
}