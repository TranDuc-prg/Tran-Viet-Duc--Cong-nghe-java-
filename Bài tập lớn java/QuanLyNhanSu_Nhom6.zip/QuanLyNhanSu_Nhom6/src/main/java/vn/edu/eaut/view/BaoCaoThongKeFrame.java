package vn.edu.eaut.view;

import vn.edu.eaut.connection.DatabaseConnection;
import vn.edu.eaut.service.ThongKeLuongWorker;
import vn.edu.eaut.service.ThongKeService;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.FontFactory;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.Arc2D;
import java.awt.geom.RoundRectangle2D;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BaoCaoThongKeFrame extends JPanel {
    private JLabel lblTongNV, lblTongPB, lblTongHD, lblTongQuyLuong;
    private JTable tableThongKe;
    private DefaultTableModel tableModel;
    private DecimalFormat currencyFormat = new DecimalFormat("#,###");

    private JComboBox<String> cbThang, cbPhongBan;
    private JTextField txtTuNgay, txtDenNgay;
    private JButton btnThongKe, btnXuatExcel, btnXuatPDF, btnInBaoCao;
    private JProgressBar progressBarLuong;

    private BarChartPanel employeeChartPanel;
    private SalaryBarChartPanel salaryChartPanel;
    private AttendancePieChartPanel attendanceChartPanel;

    private final ThongKeService thongKeService;

    public BaoCaoThongKeFrame() {
        thongKeService = new ThongKeService();
        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(new Color(245, 247, 250));

        JPanel panelHeader = new JPanel(new BorderLayout(10, 10));
        panelHeader.setOpaque(false);

        JLabel lblTitle = new JLabel("BÁO CÁO & THỐNG KÊ TỔNG QUAN DOANH NGHIỆP (5 NĂM)");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(new Color(41, 128, 185));

        JLabel lblSub = new JLabel("Thống kê chi tiết nhân sự, phân bổ phòng ban, quỹ lương và tỷ lệ chấm công chu kỳ 5 năm gần đây");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSub.setForeground(Color.GRAY);

        JPanel panelTitleText = new JPanel();
        panelTitleText.setOpaque(false);
        panelTitleText.setLayout(new BoxLayout(panelTitleText, BoxLayout.Y_AXIS));
        panelTitleText.add(lblTitle);
        panelTitleText.add(Box.createVerticalStrut(3));
        panelTitleText.add(lblSub);
        panelHeader.add(panelTitleText, BorderLayout.NORTH);

        JPanel panelFilterContainer = new JPanel(new BorderLayout());
        panelFilterContainer.setBackground(Color.WHITE);
        panelFilterContainer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 215, 220)),
                new EmptyBorder(10, 12, 10, 12)
        ));

        JPanel panelFilters = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        panelFilters.setOpaque(false);

        panelFilters.add(createLabel("Tháng:"));
        cbThang = new JComboBox<>(new String[]{"Tất cả", "T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8", "T9", "T10", "T11", "T12"});
        styleComboBox(cbThang);
        panelFilters.add(cbThang);

        panelFilters.add(createLabel("Phòng ban:"));
        cbPhongBan = new JComboBox<>(new String[]{"Tất cả phòng ban"});
        loadPhongBanCombobox();
        styleComboBox(cbPhongBan);
        panelFilters.add(cbPhongBan);

        panelFilters.add(createLabel("Từ ngày:"));
        txtTuNgay = new JTextField(LocalDate.now().minusYears(5).toString(), 10);
        styleTextField(txtTuNgay);
        panelFilters.add(txtTuNgay);

        panelFilters.add(createLabel("Đến ngày:"));
        txtDenNgay = new JTextField(LocalDate.now().toString(), 10);
        styleTextField(txtDenNgay);
        panelFilters.add(txtDenNgay);

        btnThongKe = new JButton("THỐNG KÊ");
        styleButton(btnThongKe, new Color(41, 128, 185));
        btnThongKe.addActionListener(e -> loadThongKeData());
        panelFilters.add(btnThongKe);

        JPanel panelActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 5));
        panelActions.setOpaque(false);

        progressBarLuong = new JProgressBar();
        progressBarLuong.setStringPainted(true);
        progressBarLuong.setString("Sẵn sàng");
        progressBarLuong.setPreferredSize(new Dimension(130, 26));

        btnXuatExcel = new JButton("Xuất Excel");
        btnXuatPDF = new JButton("Xuất PDF");
        btnInBaoCao = new JButton("In báo cáo");

        styleButton(btnXuatExcel, new Color(39, 174, 96));
        styleButton(btnXuatPDF, new Color(192, 57, 43));
        styleButton(btnInBaoCao, new Color(52, 73, 94));

        btnXuatExcel.addActionListener(e -> handleExportExcel());
        btnXuatPDF.addActionListener(e -> handleExportPDF());
        btnInBaoCao.addActionListener(e -> handlePrintBaoCao());

        panelActions.add(progressBarLuong);
        panelActions.add(btnXuatExcel);
        panelActions.add(btnXuatPDF);
        panelActions.add(btnInBaoCao);

        panelFilterContainer.add(panelFilters, BorderLayout.WEST);
        panelFilterContainer.add(panelActions, BorderLayout.EAST);
        panelHeader.add(panelFilterContainer, BorderLayout.SOUTH);

        add(panelHeader, BorderLayout.NORTH);

        JPanel panelCards = new JPanel(new GridLayout(1, 4, 15, 0));
        panelCards.setOpaque(false);
        panelCards.setPreferredSize(new Dimension(0, 90));

        lblTongNV = new JLabel("0", JLabel.LEFT);
        lblTongPB = new JLabel("0", JLabel.LEFT);
        lblTongHD = new JLabel("0", JLabel.LEFT);
        lblTongQuyLuong = new JLabel("0 VNĐ", JLabel.LEFT);

        panelCards.add(createModernCard("TỔNG NHÂN VIÊN", lblTongNV, "NV", new Color(46, 204, 113)));
        panelCards.add(createModernCard("PHÒNG BAN", lblTongPB, "PB", new Color(52, 152, 219)));
        panelCards.add(createModernCard("HỢP ĐỒNG HIỆU LỰC", lblTongHD, "HĐ", new Color(155, 89, 182)));
        panelCards.add(createModernCard("QUỸ LƯƠNG/THÁNG", lblTongQuyLuong, "LƯƠNG", new Color(230, 126, 34)));

        employeeChartPanel = new BarChartPanel();
        salaryChartPanel = new SalaryBarChartPanel();
        attendanceChartPanel = new AttendancePieChartPanel();

        JTabbedPane tabCharts = new JTabbedPane();
        tabCharts.setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabCharts.setBackground(Color.WHITE);
        tabCharts.addTab("📊 Nhân viên theo Phòng ban", employeeChartPanel);
        tabCharts.addTab("💰 Biểu đồ Quỹ Lương 5 năm", salaryChartPanel);
        tabCharts.addTab("📈 Tỷ lệ Chấm công", attendanceChartPanel);

        tableModel = new DefaultTableModel(new String[]{"Mã PB", "Tên Phòng Ban", "Số NV", "Tổng Lương Cơ Bản", "Lương TB"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tableThongKe = new JTable(tableModel);
        tableThongKe.setRowHeight(32);
        tableThongKe.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tableThongKe.setSelectionBackground(new Color(232, 244, 252));
        tableThongKe.setSelectionForeground(Color.BLACK);

        tableThongKe.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tableThongKe.getTableHeader().setPreferredSize(new Dimension(0, 35));

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setBackground(new Color(41, 128, 185));
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);

        for (int i = 0; i < tableThongKe.getColumnCount(); i++) {
            tableThongKe.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);

        tableThongKe.getColumnModel().getColumn(0).setPreferredWidth(60);
        tableThongKe.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tableThongKe.getColumnModel().getColumn(2).setPreferredWidth(60);
        tableThongKe.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        tableThongKe.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);
        tableThongKe.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);

        JScrollPane scrollPane = new JScrollPane(tableThongKe);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(210, 215, 220)),
                " Chi tiết nhân sự & chi phí theo Phòng Ban ",
                0, 0, new Font("Segoe UI", Font.BOLD, 12), new Color(41, 128, 185)
        ));
        scrollPane.setBackground(Color.WHITE);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tabCharts, scrollPane);
        splitPane.setResizeWeight(0.5);
        splitPane.setDividerLocation(580);
        splitPane.setOpaque(false);
        splitPane.setBorder(null);

        JPanel panelCenter = new JPanel(new BorderLayout(0, 15));
        panelCenter.setOpaque(false);
        panelCenter.add(panelCards, BorderLayout.NORTH);
        panelCenter.add(splitPane, BorderLayout.CENTER);

        add(panelCenter, BorderLayout.CENTER);

        loadThongKeData();
    }

    private JLabel createLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lbl.setForeground(new Color(80, 90, 100));
        return lbl;
    }

    private void styleTextField(JTextField tf) {
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tf.setPreferredSize(new Dimension(100, 28));
    }

    private void styleComboBox(JComboBox<String> cb) {
        cb.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cb.setBackground(Color.WHITE);
        cb.setPreferredSize(new Dimension(110, 28));
    }

    private void styleButton(JButton btn, Color bgColor) {
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(105, 28));
    }

    private JPanel createModernCard(String title, JLabel valueLabel, String tag, Color themeColor) {
        JPanel card = new JPanel(new BorderLayout(10, 5));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, themeColor),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(230, 235, 240)),
                        new EmptyBorder(10, 12, 10, 12)
                )
        ));

        JLabel lblTag = new JLabel(tag, JLabel.CENTER);
        lblTag.setFont(new Font("Segoe UI", Font.BOLD, 10));
        lblTag.setForeground(themeColor);
        lblTag.setBackground(new Color(themeColor.getRed(), themeColor.getGreen(), themeColor.getBlue(), 25));
        lblTag.setOpaque(true);
        lblTag.setPreferredSize(new Dimension(48, 22));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblTitle.setForeground(new Color(120, 130, 140));

        topPanel.add(lblTitle, BorderLayout.WEST);
        topPanel.add(lblTag, BorderLayout.EAST);

        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        valueLabel.setForeground(new Color(40, 50, 60));

        card.add(topPanel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    private void loadPhongBanCombobox() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT ten_phong_ban FROM phong_ban")) {
            while (rs.next()) {
                cbPhongBan.addItem(rs.getString("ten_phong_ban"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadThongKeData() {
        String selectedPB = (String) cbPhongBan.getSelectedItem();
        String selectedThang = (String) cbThang.getSelectedItem();
        String tuNgay = txtTuNgay.getText().trim();
        String denNgay = txtDenNgay.getText().trim();

        boolean hasPB = selectedPB != null && !selectedPB.equals("Tất cả phòng ban");
        boolean hasDate = !tuNgay.isEmpty() && !denNgay.isEmpty();
        boolean hasThang = selectedThang != null && !selectedThang.equals("Tất cả");

        try (Connection conn = DatabaseConnection.getConnection()) {
            StringBuilder sqlNV = new StringBuilder("SELECT COUNT(n.id) FROM nhan_vien n JOIN phong_ban p ON n.phong_ban_id = p.id WHERE 1=1");
            List<Object> paramsNV = new ArrayList<>();
            if (hasPB) {
                sqlNV.append(" AND p.ten_phong_ban = ?");
                paramsNV.add(selectedPB);
            }
            try (PreparedStatement pstmt = conn.prepareStatement(sqlNV.toString())) {
                for (int i = 0; i < paramsNV.size(); i++) {
                    pstmt.setObject(i + 1, paramsNV.get(i));
                }
                ResultSet rs1 = pstmt.executeQuery();
                if (rs1.next()) lblTongNV.setText(rs1.getInt(1) + " Người");
            }

            StringBuilder sqlPB = new StringBuilder("SELECT COUNT(*) FROM phong_ban p WHERE 1=1");
            List<Object> paramsPB = new ArrayList<>();
            if (hasPB) {
                sqlPB.append(" AND p.ten_phong_ban = ?");
                paramsPB.add(selectedPB);
            }
            try (PreparedStatement pstmt = conn.prepareStatement(sqlPB.toString())) {
                for (int i = 0; i < paramsPB.size(); i++) {
                    pstmt.setObject(i + 1, paramsPB.get(i));
                }
                ResultSet rs2 = pstmt.executeQuery();
                if (rs2.next()) lblTongPB.setText(rs2.getInt(1) + " Phòng");
            }

            StringBuilder sqlHD = new StringBuilder("SELECT COUNT(h.id) FROM hop_dong h JOIN nhan_vien n ON h.nhan_vien_id = n.id JOIN phong_ban p ON n.phong_ban_id = p.id WHERE h.trang_thai = 'Hiệu lực'");
            List<Object> paramsHD = new ArrayList<>();
            if (hasPB) {
                sqlHD.append(" AND p.ten_phong_ban = ?");
                paramsHD.add(selectedPB);
            }
            if (hasDate) {
                sqlHD.append(" AND h.ngay_bat_dau BETWEEN ? AND ?");
                paramsHD.add(tuNgay);
                paramsHD.add(denNgay);
            }
            if (hasThang) {
                int thangNum = Integer.parseInt(selectedThang.replace("T", ""));
                sqlHD.append(" AND MONTH(h.ngay_bat_dau) = ?");
                paramsHD.add(thangNum);
            }
            try (PreparedStatement pstmt = conn.prepareStatement(sqlHD.toString())) {
                for (int i = 0; i < paramsHD.size(); i++) {
                    pstmt.setObject(i + 1, paramsHD.get(i));
                }
                ResultSet rs3 = pstmt.executeQuery();
                if (rs3.next()) lblTongHD.setText(rs3.getInt(1) + " HĐ");
            }

            StringBuilder sqlLuong = new StringBuilder("SELECT SUM(n.luong_co_ban) FROM nhan_vien n JOIN phong_ban p ON n.phong_ban_id = p.id WHERE 1=1");
            List<Object> paramsLuong = new ArrayList<>();
            if (hasPB) {
                sqlLuong.append(" AND p.ten_phong_ban = ?");
                paramsLuong.add(selectedPB);
            }
            try (PreparedStatement pstmt = conn.prepareStatement(sqlLuong.toString())) {
                for (int i = 0; i < paramsLuong.size(); i++) {
                    pstmt.setObject(i + 1, paramsLuong.get(i));
                }
                ResultSet rs4 = pstmt.executeQuery();
                if (rs4.next()) {
                    double tongLuong = rs4.getDouble(1);
                    lblTongQuyLuong.setText(currencyFormat.format(tongLuong) + " VNĐ");
                }
            }

            tableModel.setRowCount(0);
            List<BarChartPanel.BarData> empDataList = new ArrayList<>();

            StringBuilder sqlTable = new StringBuilder(
                    "SELECT p.ma_phong_ban, p.ten_phong_ban, " +
                            "COUNT(n.id) AS so_nv, " +
                            "COALESCE(SUM(n.luong_co_ban), 0) AS tong_luong, " +
                            "COALESCE(AVG(n.luong_co_ban), 0) AS luong_tb " +
                            "FROM phong_ban p " +
                            "LEFT JOIN nhan_vien n ON p.id = n.phong_ban_id WHERE 1=1"
            );
            List<Object> paramsTable = new ArrayList<>();
            if (hasPB) {
                sqlTable.append(" AND p.ten_phong_ban = ?");
                paramsTable.add(selectedPB);
            }
            sqlTable.append(" GROUP BY p.id, p.ma_phong_ban, p.ten_phong_ban HAVING so_nv > 0");

            try (PreparedStatement pstmt = conn.prepareStatement(sqlTable.toString())) {
                for (int i = 0; i < paramsTable.size(); i++) {
                    pstmt.setObject(i + 1, paramsTable.get(i));
                }
                ResultSet rsTable = pstmt.executeQuery();
                while (rsTable.next()) {
                    String maPB = rsTable.getString("ma_phong_ban");
                    int soNV = rsTable.getInt("so_nv");
                    double tongLuongPB = rsTable.getDouble("tong_luong");

                    tableModel.addRow(new Object[]{
                            maPB,
                            rsTable.getString("ten_phong_ban"),
                            soNV,
                            currencyFormat.format(tongLuongPB) + " VNĐ",
                            currencyFormat.format(rsTable.getDouble("luong_tb")) + " VNĐ"
                    });

                    empDataList.add(new BarChartPanel.BarData(maPB, soNV));
                }
            }

            employeeChartPanel.setData(empDataList);
            attendanceChartPanel.setData();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi khi lọc dữ liệu thống kê: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }

        progressBarLuong.setString("Đang tải quỹ lương...");
        ThongKeLuongWorker worker = new ThongKeLuongWorker(thongKeService, progressBarLuong, () -> {
            try {
                Map<Integer, Double> dataMap = thongKeService.getMucLuongTrungBinh5Nam();
                List<SalaryBarChartPanel.SalaryData> salaryDataList = new ArrayList<>();

                for (Map.Entry<Integer, Double> entry : dataMap.entrySet()) {
                    salaryDataList.add(new SalaryBarChartPanel.SalaryData(String.valueOf(entry.getKey()), entry.getValue()));
                }

                if (salaryDataList.isEmpty()) {
                    salaryDataList.add(new SalaryBarChartPanel.SalaryData("Chưa có", 0));
                }

                salaryChartPanel.setData(salaryDataList);
                progressBarLuong.setString("Hoàn tất!");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        worker.execute();
    }

    private void handleExportExcel() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Lưu Báo cáo Thống kê Excel");
        fileChooser.setSelectedFile(new File("BaoCaoThongKe5Nam.csv"));
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            String path = file.getAbsolutePath();
            if (!path.endsWith(".csv")) path += ".csv";

            try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path), "UTF-8"))) {
                writer.write("\uFEFF");
                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    writer.write("\"" + tableModel.getColumnName(i) + "\"");
                    if (i < tableModel.getColumnCount() - 1) writer.write(",");
                }
                writer.newLine();
                for (int r = 0; r < tableModel.getRowCount(); r++) {
                    for (int c = 0; c < tableModel.getColumnCount(); c++) {
                        Object val = tableModel.getValueAt(r, c);
                        writer.write("\"" + (val != null ? val.toString() : "") + "\"");
                        if (c < tableModel.getColumnCount() - 1) writer.write(",");
                    }
                    writer.newLine();
                }
                JOptionPane.showMessageDialog(this, "Xuất Excel thành công!\n" + path, "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Lỗi xuất file: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleExportPDF() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Lưu Báo cáo Thống kê PDF");
        fileChooser.setSelectedFile(new File("bc.pdf"));

        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            String path = file.getAbsolutePath();
            if (!path.endsWith(".pdf")) path += ".pdf";

            Document document = new Document();
            try {
                PdfWriter.getInstance(document, new FileOutputStream(path));
                document.open();

                com.itextpdf.text.Font titleFont = FontFactory.getFont("c:/windows/fonts/arial.ttf", "Identity-H", true, 16, com.itextpdf.text.Font.BOLD, com.itextpdf.text.BaseColor.BLUE);
                com.itextpdf.text.Font normalFont = FontFactory.getFont("c:/windows/fonts/arial.ttf", "Identity-H", true, 11, com.itextpdf.text.Font.NORMAL, com.itextpdf.text.BaseColor.BLACK);
                com.itextpdf.text.Font headerFont = FontFactory.getFont("c:/windows/fonts/arial.ttf", "Identity-H", true, 11, com.itextpdf.text.Font.BOLD, com.itextpdf.text.BaseColor.WHITE);

                document.add(new Paragraph("BÁO CÁO & THỐNG KÊ TỔNG QUAN DOANH NGHIỆP (5 NĂM)", titleFont));
                document.add(new Paragraph("Thời gian xuất báo cáo: " + LocalDate.now().toString(), normalFont));
                document.add(new Paragraph(" "));

                PdfPTable pdfTable = new PdfPTable(tableModel.getColumnCount());
                pdfTable.setWidthPercentage(100);

                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    com.itextpdf.text.pdf.PdfPCell cell = new com.itextpdf.text.pdf.PdfPCell(new com.itextpdf.text.Paragraph(tableModel.getColumnName(i), headerFont));
                    cell.setBackgroundColor(new com.itextpdf.text.BaseColor(41, 128, 185));
                    cell.setHorizontalAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
                    pdfTable.addCell(cell);
                }

                for (int r = 0; r < tableModel.getRowCount(); r++) {
                    for (int c = 0; c < tableModel.getColumnCount(); c++) {
                        Object val = tableModel.getValueAt(r, c);
                        pdfTable.addCell(new com.itextpdf.text.Paragraph(val != null ? val.toString() : "", normalFont));
                    }
                }

                document.add(pdfTable);
                document.close();

                JOptionPane.showMessageDialog(this, "Xuất file PDF thành công!\n" + path, "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Lỗi khi xuất PDF: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
    }

    private void handlePrintBaoCao() {
        try {
            boolean complete = tableThongKe.print(
                    JTable.PrintMode.FIT_WIDTH,
                    new java.text.MessageFormat("BÁO CÁO THỐNG KÊ TỔNG QUAN DOANH NGHIỆP (5 NĂM)"),
                    new java.text.MessageFormat("Trang - {0}")
            );
            if (complete) {
                JOptionPane.showMessageDialog(this, "In báo cáo thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi in báo cáo: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static class BarChartPanel extends JPanel {
        public static class BarData {
            String label;
            int value;
            public BarData(String label, int value) { this.label = label; this.value = value; }
        }
        private List<BarData> dataList = new ArrayList<>();

        public BarChartPanel() { setBackground(Color.WHITE); setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); }
        public void setData(List<BarData> dataList) { this.dataList = dataList; repaint(); }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (dataList == null || dataList.isEmpty()) {
                g2d.drawString("Chưa có dữ liệu biểu đồ nhân viên", 80, getHeight() / 2);
                return;
            }

            int pb = 40, pt = 35, pl = 40, pr = 30;
            int w = getWidth() - pl - pr, h = getHeight() - pt - pb;
            int max = 1; for (BarData d : dataList) if (d.value > max) max = d.value;

            g2d.setColor(new Color(230, 235, 240));
            g2d.drawLine(pl, getHeight() - pb, getWidth() - pr, getHeight() - pb);

            int count = dataList.size();
            int bWidth = Math.min(40, Math.max(15, w / (count * 2)));
            int gap = Math.max(5, (w - bWidth * count) / (count + 1));

            for (int i = 0; i < count; i++) {
                BarData d = dataList.get(i);
                int bHeight = (int) (((double) d.value / max) * h);
                int x = pl + gap + i * (bWidth + gap);
                int y = getHeight() - pb - bHeight;

                g2d.setPaint(new GradientPaint(x, y, new Color(52, 152, 219), x, y + bHeight, new Color(41, 128, 185)));
                g2d.fill(new RoundRectangle2D.Double(x, y, bWidth, bHeight, 8, 8));

                g2d.setFont(new Font("Segoe UI", Font.BOLD, 10));
                g2d.setColor(new Color(41, 128, 185));
                g2d.drawString(String.valueOf(d.value), x + 4, y - 6);
                g2d.drawString(d.label, x, getHeight() - pb + 18);
            }
        }
    }

    private static class SalaryBarChartPanel extends JPanel {
        public static class SalaryData {
            String label;
            double value;
            public SalaryData(String label, double value) { this.label = label; this.value = value; }
        }
        private List<SalaryData> dataList = new ArrayList<>();

        public SalaryBarChartPanel() { setBackground(Color.WHITE); setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); }
        public void setData(List<SalaryData> dataList) { this.dataList = dataList; repaint(); }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (dataList == null || dataList.isEmpty()) {
                g2d.drawString("Chưa có dữ liệu quỹ lương 5 năm", 80, getHeight() / 2);
                return;
            }

            int pb = 40, pt = 35, pl = 45, pr = 30;
            int w = getWidth() - pl - pr, h = getHeight() - pt - pb;
            double max = 1.0; for (SalaryData d : dataList) if (d.value > max) max = d.value;

            g2d.setColor(new Color(230, 235, 240));
            g2d.drawLine(pl, getHeight() - pb, getWidth() - pr, getHeight() - pb);

            int count = dataList.size();
            int bWidth = Math.min(35, Math.max(12, w / (count * 2)));
            int gap = Math.max(5, (w - bWidth * count) / (count + 1));
            DecimalFormat df = new DecimalFormat("#.#");

            for (int i = 0; i < count; i++) {
                SalaryData d = dataList.get(i);
                int bHeight = (int) ((d.value / max) * h);
                int x = pl + gap + i * (bWidth + gap);
                int y = getHeight() - pb - bHeight;

                g2d.setPaint(new GradientPaint(x, y, new Color(243, 156, 18), x, y + bHeight, new Color(211, 84, 0)));
                g2d.fill(new RoundRectangle2D.Double(x, y, bWidth, bHeight, 8, 8));

                g2d.setFont(new Font("Segoe UI", Font.BOLD, 9));
                g2d.setColor(new Color(211, 84, 0));
                g2d.drawString(df.format(d.value / 1_000_000) + "tr", x, y - 6);
                g2d.drawString(d.label, x, getHeight() - pb + 18);
            }
        }
    }

    private static class AttendancePieChartPanel extends JPanel {
        private String[] labels = {"Đúng giờ", "Đi muộn", "Nghỉ phép", "Vắng"};
        private double[] values = {85.0, 8.0, 5.0, 2.0};
        private Color[] colors = {new Color(46, 204, 113), new Color(241, 196, 15), new Color(52, 152, 219), new Color(231, 76, 60)};

        public AttendancePieChartPanel() { setBackground(Color.WHITE); setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); }
        public void setData() { repaint(); }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int size = Math.min(getWidth() - 130, getHeight() - 40);
            if (size < 60) size = 60;
            int x = 20, y = (getHeight() - size) / 2;

            double start = 0;
            for (int i = 0; i < values.length; i++) {
                double angle = (values[i] / 100.0) * 360;
                g2d.setColor(colors[i]);
                g2d.fill(new Arc2D.Double(x, y, size, size, start, angle, Arc2D.PIE));
                start += angle;
            }

            int lx = x + size + 20, ly = y + 10;
            g2d.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            for (int i = 0; i < labels.length; i++) {
                g2d.setColor(colors[i]);
                g2d.fillRect(lx, ly, 10, 10);
                g2d.setColor(new Color(60, 70, 80));
                g2d.drawString(labels[i] + " (" + values[i] + "%)", lx + 16, ly + 9);
                ly += 22;
            }
        }
    }
}