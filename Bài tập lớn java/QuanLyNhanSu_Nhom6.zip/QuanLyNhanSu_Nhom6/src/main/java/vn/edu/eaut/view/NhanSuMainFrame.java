package vn.edu.eaut.view;

import vn.edu.eaut.model.UserSession;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class NhanSuMainFrame extends JFrame {

    private CardLayout cardLayout;
    private JPanel panelCenter;
    private JButton activeButton;

    public NhanSuMainFrame() {

        UITheme.install();

        // =====================================================
        // CẤU HÌNH FRAME
        // =====================================================

        setTitle("Quản Lý Nhân Sự | PHÂN HỆ QUẢN LÝ");
        setSize(1280, 800);
        setMinimumSize(new Dimension(1150, 700));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // =====================================================
        // HEADER
        // =====================================================

        add(createHeader(), BorderLayout.NORTH);

        // =====================================================
        // SIDEBAR (Đã bọc JScrollPane để có thanh cuộn)
        // =====================================================

        add(createSidebar(), BorderLayout.WEST);

        // =====================================================
        // CENTER
        // =====================================================

        cardLayout = new CardLayout();

        panelCenter = new JPanel(cardLayout);
        panelCenter.setBackground(UITheme.BG);
        panelCenter.setBorder(
                new EmptyBorder(14, 14, 14, 14)
        );

        // =====================================================
        // 1. NHÂN VIÊN
        // =====================================================

        panelCenter.add(
                new NhanVienFrame("QUAN_LY"),
                "NHAN_VIEN"
        );

        // =====================================================
        // 2. PHÒNG BAN
        // =====================================================

        panelCenter.add(
                new PhongBanFrame(),
                "PHONG_BAN"
        );

        // =====================================================
        // 3. CHỨC VỤ
        // =====================================================

        panelCenter.add(
                new ChucVuFrame(),
                "CHUC_VU"
        );

        // =====================================================
        // 4. HỢP ĐỒNG
        // =====================================================

        panelCenter.add(
                new HopDongFrame(),
                "HOP_DONG"
        );

        // =====================================================
        // 5. CHẤM CÔNG
        // =====================================================

        panelCenter.add(
                new ChamCongFrame("QUAN_LY"),
                "CHAM_CONG"
        );

        // =====================================================
        // 6. NGHỈ PHÉP
        // =====================================================

        panelCenter.add(
                new NghiPhepFrame(),
                "NGHI_PHEP"
        );

        // =====================================================
        // 7. TĂNG CA
        // =====================================================

        panelCenter.add(
                new TangCaFrame(),
                "TANG_CA"
        );

        // =====================================================
        // 8. PHỤ CẤP & KHẤU TRỪ
        // =====================================================

        panelCenter.add(
                new PhuCapFrame(),
                "PHU_CAP"
        );

        // =====================================================
        // 9. BẢNG LƯƠNG
        // =====================================================

        panelCenter.add(
                new BangLuongFrame(),
                "BANG_LUONG"
        );

        // =====================================================
        // 10. BÁO CÁO NHÂN SỰ
        // =====================================================

        panelCenter.add(
                new BaoCaoNhanSuFrame(),
                "BAO_CAO_NHAN_SU"
        );

        // =====================================================
        // 11. BÁO CÁO THỐNG KÊ
        // =====================================================

        panelCenter.add(
                new BaoCaoThongKeFrame(),
                "BAO_CAO_THONG_KE"
        );

        // =====================================================
        // 12. QUẢN LÝ THÔNG BÁO
        // =====================================================

        panelCenter.add(
                new QuanLyThongBaoPanel(),
                "QUAN_LY_THONG_BAO"
        );

        // =====================================================
        // 13. TRẠNG THÁI NHÂN SỰ (Thêm mới)
        // =====================================================

        panelCenter.add(
                new NhanVienTrangThaiPanel(),
                "NHAN_VIEN_TRANG_THAI"
        );

        add(
                panelCenter,
                BorderLayout.CENTER
        );

        // =====================================================
        // FOOTER
        // =====================================================

        add(
                createFooter(),
                BorderLayout.SOUTH
        );
    }

    // =========================================================
    // HEADER
    // =========================================================

    private JPanel createHeader() {

        JPanel header = new JPanel(
                new BorderLayout()
        );

        header.setPreferredSize(
                new Dimension(0, 72)
        );

        header.setBackground(
                UITheme.GREEN
        );

        header.setBorder(
                new EmptyBorder(
                        0,
                        24,
                        0,
                        24
                )
        );

        // =====================================================
        // HEADER LEFT
        // =====================================================

        JPanel left = new JPanel(
                new FlowLayout(
                        FlowLayout.LEFT,
                        12,
                        14
                )
        );

        left.setOpaque(false);

        JLabel logo = new JLabel(
                "QL",
                SwingConstants.CENTER
        );

        logo.setPreferredSize(
                new Dimension(44, 44)
        );

        logo.setFont(
                UITheme.font(
                        Font.BOLD,
                        14
                )
        );

        logo.setForeground(
                UITheme.GREEN
        );

        logo.setBackground(
                Color.WHITE
        );

        logo.setOpaque(true);

        // =====================================================
        // TITLE
        // =====================================================

        JPanel titles = new JPanel();

        titles.setOpaque(false);

        titles.setLayout(
                new BoxLayout(
                        titles,
                        BoxLayout.Y_AXIS
                )
        );

        JLabel title = new JLabel(
                "HỆ THỐNG QUẢN LÝ NHÂN SỰ"
        );

        title.setFont(
                UITheme.font(
                        Font.BOLD,
                        16
                )
        );

        title.setForeground(
                Color.WHITE
        );

        JLabel sub = new JLabel(
                "PHÂN HỆ QUẢN LÝ"
        );

        sub.setFont(
                UITheme.font(
                        Font.PLAIN,
                        10
                )
        );

        sub.setForeground(
                new Color(
                        209,
                        250,
                        229
                )
        );

        titles.add(title);

        titles.add(
                Box.createVerticalStrut(3)
        );

        titles.add(sub);

        left.add(logo);
        left.add(titles);

        // =====================================================
        // USER INFO
        // =====================================================

        JPanel user = new JPanel(
                new FlowLayout(
                        FlowLayout.RIGHT,
                        10,
                        14
                )
        );

        user.setOpaque(false);

        String fullName = UserSession.getFullName();
        String username = UserSession.getUsername();

        if (fullName == null ||
                fullName.trim().isEmpty()) {

            fullName = "Quản lý";
        }

        if (username == null ||
                username.trim().isEmpty()) {

            username = "QuanLy";
        }

        JLabel info = new JLabel(
                "<html><b>" +
                        fullName +
                        "</b><br>" +
                        "<font size='2'>" +
                        username +
                        " • Đang hoạt động" +
                        "</font></html>"
        );

        info.setForeground(
                Color.WHITE
        );

        info.setHorizontalAlignment(
                SwingConstants.RIGHT
        );

        // =====================================================
        // AVATAR
        // =====================================================

        String avatarText =
                fullName.substring(0, 1).toUpperCase();

        JLabel avatar = new JLabel(
                avatarText,
                SwingConstants.CENTER
        );

        avatar.setPreferredSize(
                new Dimension(40, 40)
        );

        avatar.setFont(
                UITheme.font(
                        Font.BOLD,
                        15
                )
        );

        avatar.setForeground(
                UITheme.GREEN
        );

        avatar.setBackground(
                Color.WHITE
        );

        avatar.setOpaque(true);

        user.add(info);
        user.add(avatar);

        header.add(
                left,
                BorderLayout.WEST
        );

        header.add(
                user,
                BorderLayout.EAST
        );

        return header;
    }

    // =========================================================
    // SIDEBAR (Có tích hợp JScrollPane chứa thanh cuộn)
    // =========================================================

    private JPanel createSidebar() {
        JPanel sidebarContent = new JPanel();
        sidebarContent.setLayout(
                new BoxLayout(
                        sidebarContent,
                        BoxLayout.Y_AXIS
                )
        );

        sidebarContent.setBackground(
                UITheme.NAVY
        );

        sidebarContent.setBorder(
                new EmptyBorder(
                        18,
                        14,
                        16,
                        14
                )
        );

        // =====================================================
        // SIDEBAR HEADER
        // =====================================================

        sidebarContent.add(
                UITheme.createSidebarHeader(
                        "QUẢN LÝ",
                        "Quản lý nghiệp vụ nhân sự"
                )
        );

        sidebarContent.add(
                Box.createVerticalStrut(18)
        );

        // =====================================================
        // MENU TITLE
        // =====================================================

        JLabel menu = new JLabel(
                "  DANH MỤC NGHIỆP VỤ"
        );

        menu.setFont(
                UITheme.font(
                        Font.BOLD,
                        10
                )
        );

        menu.setForeground(
                new Color(
                        148,
                        163,
                        184
                )
        );

        menu.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        sidebarContent.add(menu);

        sidebarContent.add(
                Box.createVerticalStrut(8)
        );

        // =====================================================
        // CÁC CHỨC NĂNG CỦA QUẢN LÝ (Bao gồm Trạng Thái Nhân Sự)
        // =====================================================

        JButton btn0 = UITheme.navButton("NV", "Quản lý Nhân Viên");
        JButton btn1 = UITheme.navButton("PB", "Quản lý Phòng Ban");
        JButton btn2 = UITheme.navButton("CV", "Quản lý Chức Vụ");
        JButton btn3 = UITheme.navButton("HD", "Quản lý Hợp Đồng");
        JButton btn4 = UITheme.navButton("CC", "Quản lý Chấm Công");
        JButton btn5 = UITheme.navButton("NP", "Quản lý Nghỉ Phép");
        JButton btn6 = UITheme.navButton("TC", "Quản lý Tăng Ca");
        JButton btn7 = UITheme.navButton("PC", "Phụ Cấp & Khấu Trừ");
        JButton btn8 = UITheme.navButton("BL", "Tính Lương & Bảng Lương");
        JButton btn9 = UITheme.navButton("BC", "Báo Cáo Nhân Sự");
        JButton btn10 = UITheme.navButton("TK", "Báo Cáo Thống Kê");
        JButton btn11 = UITheme.navButton("TB", "Quản lý Thông Báo");
        JButton btn12 = UITheme.navButton("TT", "Trạng Thái Nhân Sự"); // Nút mới

        // =====================================================
        // ADD SIDEBAR BUTTONS
        // =====================================================

        JButton[] buttons = {btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12};
        for (JButton b : buttons) {
            sidebarContent.add(b);
            sidebarContent.add(Box.createVerticalStrut(4));
        }

        // =====================================================
        // LOGOUT
        // =====================================================

        sidebarContent.add(Box.createVerticalStrut(10));
        JButton logout = UITheme.logoutButton();
        sidebarContent.add(logout);

        // =====================================================
        // ACTION EVENTS
        // =====================================================

        btn0.addActionListener(e -> showPage(btn0, "NHAN_VIEN"));
        btn1.addActionListener(e -> showPage(btn1, "PHONG_BAN"));
        btn2.addActionListener(e -> showPage(btn2, "CHUC_VU"));
        btn3.addActionListener(e -> showPage(btn3, "HOP_DONG"));
        btn4.addActionListener(e -> showPage(btn4, "CHAM_CONG"));
        btn5.addActionListener(e -> showPage(btn5, "NGHI_PHEP"));
        btn6.addActionListener(e -> showPage(btn6, "TANG_CA"));
        btn7.addActionListener(e -> showPage(btn7, "PHU_CAP"));
        btn8.addActionListener(e -> showPage(btn8, "BANG_LUONG"));
        btn9.addActionListener(e -> showPage(btn9, "BAO_CAO_NHAN_SU"));
        btn10.addActionListener(e -> showPage(btn10, "BAO_CAO_THONG_KE"));
        btn11.addActionListener(e -> showPage(btn11, "QUAN_LY_THONG_BAO"));
        btn12.addActionListener(e -> showPage(btn12, "NHAN_VIEN_TRANG_THAI")); // Sự kiện cho nút mới
        logout.addActionListener(e -> logout());

        // =====================================================
        // WRAP TRONG JSCROLLPANE ĐỂ CÓ THANH CUỘN BÊN TRÁI
        // =====================================================

        JScrollPane scrollPane = new JScrollPane(sidebarContent);
        scrollPane.setPreferredSize(new Dimension(260, 0));
        scrollPane.setBorder(null);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        JPanel sidebarWrapper = new JPanel(new BorderLayout());
        sidebarWrapper.add(scrollPane, BorderLayout.CENTER);
        return sidebarWrapper;
    }

    // =========================================================
    // SHOW PAGE
    // =========================================================

    private void showPage(
            JButton button,
            String page
    ) {

        if (activeButton != null) {

            UITheme.setNavActive(
                    activeButton,
                    false
            );
        }

        activeButton = button;

        UITheme.setNavActive(
                button,
                true
        );

        cardLayout.show(
                panelCenter,
                page
        );
    }

    // =========================================================
    // FOOTER
    // =========================================================

    private JPanel createFooter() {

        JPanel footer = new JPanel(
                new BorderLayout()
        );

        footer.setPreferredSize(
                new Dimension(
                        0,
                        30
                )
        );

        footer.setBackground(
                Color.WHITE
        );

        footer.setBorder(
                BorderFactory.createMatteBorder(
                        1,
                        0,
                        0,
                        0,
                        UITheme.BORDER
                )
        );

        JLabel left = new JLabel(
                "  © 2026 EAUT • Hệ thống quản lý nhân sự"
        );

        left.setFont(
                UITheme.font(
                        Font.PLAIN,
                        9
                )
        );

        left.setForeground(
                UITheme.MUTED
        );

        JLabel right = new JLabel(
                "  QUAN_LY • PHÂN HỆ ĐƯỢC PHÂN QUYỀN  "
        );

        right.setFont(
                UITheme.font(
                        Font.BOLD,
                        9
                )
        );

        right.setForeground(
                UITheme.GREEN_DARK
        );

        footer.add(
                left,
                BorderLayout.WEST
        );

        footer.add(
                right,
                BorderLayout.EAST
        );

        return footer;
    }


    private void logout() {

        int confirm =
                JOptionPane.showConfirmDialog(
                        this,
                        "Bạn có chắc chắn muốn đăng xuất khỏi hệ thống?",
                        "Xác nhận đăng xuất",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

        if (confirm ==
                JOptionPane.YES_OPTION) {

            // Xóa thông tin phiên đăng nhập
            UserSession.logout();

            // Đóng cửa sổ hiện tại
            dispose();

            // Quay lại màn hình đăng nhập
            new LoginFrame().setVisible(true);
        }
    }
}