package vn.edu.eaut.view;

import vn.edu.eaut.connection.DatabaseConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.Locale;

public class NhanVienPortalFrame extends JFrame {
    private int currentNhanVienId; // ID nhân viên đang đăng nhập
    private String maNvLogin = "";
    private String hoTenLogin = "";

    private JPanel panelMainContent;
    private CardLayout cardLayout;
    private DecimalFormat currencyFormat = new DecimalFormat("#,###");

    // Các thành phần bảng/giao diện
    private DefaultTableModel modelLuongNv, modelChamCongNv, modelNghiPhep, modelTangCaNv;

    // Các thành phần cho tính năng Chấm công trực tiếp
    private JLabel lblCurrentTime, lblStatusChamCong;
    private JButton btnCheckIn, btnCheckOut;

    public NhanVienPortalFrame(int nhanVienId) {
        this.currentNhanVienId = nhanVienId;
        layThongTinNhanVien();

        setTitle("Quản Lý Nhân Sự | PHÂN HỆ NHÂN VIÊN - " + hoTenLogin);
        setSize(1100, 680);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // --- 1. HEADER TOP ---
        JPanel panelHeader = new JPanel(new BorderLayout());
        panelHeader.setBackground(new Color(41, 128, 185));
        panelHeader.setPreferredSize(new Dimension(0, 60));
        panelHeader.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        JLabel lblTitleSys = new JLabel("HỆ THỐNG QUẢN LÝ NHÂN SỰ - CỔNG THÔNG TIN NHÂN VIÊN");
        lblTitleSys.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTitleSys.setForeground(Color.WHITE);
        panelHeader.add(lblTitleSys, BorderLayout.WEST);

        JPanel panelUserRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 12));
        panelUserRight.setOpaque(false);
        JLabel lblUserWelcome = new JLabel("Xin chào: " + hoTenLogin + " (" + maNvLogin + ")");
        lblUserWelcome.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblUserWelcome.setForeground(Color.WHITE);
        panelUserRight.add(lblUserWelcome);
        panelHeader.add(panelUserRight, BorderLayout.EAST);

        add(panelHeader, BorderLayout.NORTH);

        // --- 2. SIDEBAR NAVIGATION ---
        JPanel panelSidebar = new JPanel();
        panelSidebar.setLayout(new BoxLayout(panelSidebar, BoxLayout.Y_AXIS));
        panelSidebar.setBackground(new Color(30, 41, 59));
        panelSidebar.setPreferredSize(new Dimension(220, 0));
        panelSidebar.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));

        JLabel lblMenuTitle = new JLabel("DANH MỤC CÁ NHÂN");
        lblMenuTitle.setForeground(new Color(148, 163, 184));
        lblMenuTitle.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblMenuTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        panelSidebar.add(lblMenuTitle);
        panelSidebar.add(Box.createVerticalStrut(15));

        JButton btnHome = createSidebarButton("📊 Tổng Quan");
        JButton btnLuong = createSidebarButton("💰 Tra Cứu Lương");
        JButton btnChamCong = createSidebarButton("⏱️ Chấm Công");
        JButton btnLichSu = createSidebarButton("📋 Lịch Sử Chấm Công");
        JButton btnNghiPhep = createSidebarButton("📝 Đơn Xin Nghỉ Phép");
        JButton btnDangKyTc = createSidebarButton("⚡ Đăng Ký Tăng Ca");
        JButton btnDangXuat = createSidebarButton("🚪 Đăng Xuất");

        panelSidebar.add(btnHome);
        panelSidebar.add(Box.createVerticalStrut(8));
        panelSidebar.add(btnLuong);
        panelSidebar.add(Box.createVerticalStrut(8));
        panelSidebar.add(btnChamCong);
        panelSidebar.add(Box.createVerticalStrut(8));
        panelSidebar.add(btnLichSu);
        panelSidebar.add(Box.createVerticalStrut(8));
        panelSidebar.add(btnNghiPhep);
        panelSidebar.add(Box.createVerticalStrut(8));
        panelSidebar.add(btnDangKyTc);
        panelSidebar.add(Box.createVerticalStrut(25));
        panelSidebar.add(btnDangXuat);

        add(panelSidebar, BorderLayout.WEST);

        // --- 3. MAIN CONTENT CONTAINER (CARD LAYOUT) ---
        cardLayout = new CardLayout();
        panelMainContent = new JPanel(cardLayout);
        panelMainContent.setBackground(new Color(245, 247, 250));

        panelMainContent.add(createDashboardPanel(), "HOME");
        panelMainContent.add(createLuongPanel(), "LUONG");
        panelMainContent.add(createChamCongPanel(), "CHAMCONG");
        panelMainContent.add(createLichSuChamCongPanel(), "LICHSU");
        panelMainContent.add(createNghiPhepPanel(), "NGHIPHEP");
        panelMainContent.add(createTangCaPanel(), "TANGCA");

        add(panelMainContent, BorderLayout.CENTER);

        // Action sự kiện chuyển trang
        btnHome.addActionListener(e -> cardLayout.show(panelMainContent, "HOME"));
        btnLuong.addActionListener(e -> {
            cardLayout.show(panelMainContent, "LUONG");
            loadLuongCaNhan();
        });
        btnChamCong.addActionListener(e -> {
            cardLayout.show(panelMainContent, "CHAMCONG");
            kiemTraTrangThaiChamCongHomNay();
        });
        btnLichSu.addActionListener(e -> {
            cardLayout.show(panelMainContent, "LICHSU");
            loadLichSuChamCong();
        });
        btnNghiPhep.addActionListener(e -> {
            cardLayout.show(panelMainContent, "NGHIPHEP");
            loadNghiPhepCaNhan();
        });
        btnDangKyTc.addActionListener(e -> {
            cardLayout.show(panelMainContent, "TANGCA");
            loadTangCaCaNhan();
        });

        btnDangXuat.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });
    }

    private JButton createSidebarButton(String text) {
        JButton btn = new JButton(text);
        btn.setMaximumSize(new Dimension(200, 38));
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(51, 65, 85));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void layThongTinNhanVien() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT ma_nv, ho_ten FROM nhan_vien WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, currentNhanVienId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        maNvLogin = rs.getString("ma_nv");
                        hoTenLogin = rs.getString("ho_ten");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (maNvLogin == null) maNvLogin = "";
        if (hoTenLogin == null) hoTenLogin = "";
    }

    // --- PANEL 1: TỔNG QUAN DASHBOARD ---
    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel panelTopWelcome = new JPanel(new BorderLayout());
        panelTopWelcome.setOpaque(false);

        JLabel lblWelcomeCard = new JLabel("Chào mừng bạn trở lại, " + hoTenLogin + "!");
        lblWelcomeCard.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblWelcomeCard.setForeground(new Color(41, 128, 185));
        panelTopWelcome.add(lblWelcomeCard, BorderLayout.WEST);

        JLabel lblClockDash = new JLabel();
        lblClockDash.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblClockDash.setForeground(new Color(100, 116, 139));
        Timer dashTimer = new Timer(1000, e -> {
            SimpleDateFormat sdf = new SimpleDateFormat("EEEE, dd/MM/yyyy - HH:mm:ss", new Locale("vi", "VN"));
            lblClockDash.setText("📅 " + sdf.format(new Date()));
        });
        dashTimer.start();
        panelTopWelcome.add(lblClockDash, BorderLayout.EAST);

        panel.add(panelTopWelcome, BorderLayout.NORTH);

        String[] infoSql = layThongTinChiTietTuSQL();
        String trangThaiAcc = infoSql[0];
        String tenPhongBan = infoSql[1];
        String loaiHopDong = infoSql[2];

        JPanel panelCenterContainer = new JPanel(new BorderLayout(0, 15));
        panelCenterContainer.setOpaque(false);

        JPanel panelCardsGrid = new JPanel(new GridLayout(1, 3, 15, 0));
        panelCardsGrid.setOpaque(false);
        panelCardsGrid.setPreferredSize(new Dimension(0, 130));

        panelCardsGrid.add(createStatCard("Trạng thái tài khoản", trangThaiAcc, new Color(46, 204, 113)));
        panelCardsGrid.add(createStatCard("Phòng ban làm việc", tenPhongBan, new Color(52, 152, 219)));
        panelCardsGrid.add(createStatCard("Hợp đồng lao động", loaiHopDong, new Color(155, 89, 182)));

        panelCenterContainer.add(panelCardsGrid, BorderLayout.NORTH);

        JPanel panelBottomInfo = new JPanel(new GridLayout(1, 2, 15, 0));
        panelBottomInfo.setOpaque(false);

        String[] thongBaoDb = layThongBaoMoiNhatTuSQL();
        JPanel boxNotice = createInfoBox(thongBaoDb[0], thongBaoDb[1], new Color(230, 126, 34));

        JPanel boxQuickGuide = createInfoBox("⚡ Hướng Dẫn & Lối Tắt",
                "<html>- Sử dụng menu bên trái để tra cứu chi tiết Lương, Chấm công.<br>" +
                        "- Đăng ký nghỉ phép trước ít nhất 2 ngày làm việc.<br>" +
                        "- Kiểm tra kỹ thông tin trước khi gửi biểu mẫu.</html>",
                new Color(41, 128, 185));

        panelBottomInfo.add(boxNotice);
        panelBottomInfo.add(boxQuickGuide);

        panelCenterContainer.add(panelBottomInfo, BorderLayout.CENTER);
        panel.add(panelCenterContainer, BorderLayout.CENTER);

        return panel;
    }

    private String[] layThongBaoMoiNhatTuSQL() {
        String tieuDe = "📢 Thông Báo Nội Bộ";
        String noiDung = "<html>- Toàn thể nhân viên thực hiện nghiêm túc việc chấm công Vào/Ra ca hằng ngày.<br>" +
                "- Lịch chi trả lương dự kiến vào ngày 05 hằng tháng.<br>" +
                "- Mọi thắc mắc về bảng lương vui lòng liên hệ bộ phận Nhân sự (HR).</html>";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT tieu_de, noi_dung FROM thong_bao ORDER BY id DESC LIMIT 1");
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                tieuDe = "📢 " + rs.getString("tieu_de");
                noiDung = "<html>" + rs.getString("noi_dung") + "</html>";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new String[]{tieuDe, noiDung};
    }

    private String[] layThongTinChiTietTuSQL() {
        String trangthai = "🟢 Đang hoạt động";
        String phongban = "🏢 Chưa cập nhật";
        String hopdong = "📄 Chưa cập nhật";

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT nv.*, pb.ten_phong_ban, hd.loai_hop_dong AS ten_loai_hd " +
                    "FROM nhan_vien nv " +
                    "LEFT JOIN phong_ban pb ON nv.phong_ban_id = pb.id " +
                    "LEFT JOIN hop_dong hd ON nv.id = hd.nhan_vien_id AND hd.trang_thai = 'Hiệu lực' " +
                    "WHERE nv.id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, currentNhanVienId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String tenPb = rs.getString("ten_phong_ban");
                        if (tenPb != null && !tenPb.isEmpty()) {
                            phongban = "🏢 " + tenPb;
                        }

                        try {
                            String statusDb = rs.getString("trang_thai");
                            if (statusDb != null && !statusDb.isEmpty()) {
                                trangthai = "🟢 " + statusDb;
                            }
                        } catch (Exception ignored) {}

                        try {
                            String hdDb = rs.getString("ten_loai_hd");
                            if (hdDb != null && !hdDb.trim().isEmpty()) {
                                hopdong = "📄 " + hdDb;
                            }
                        } catch (Exception ignored) {}
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new String[]{trangthai, phongban, hopdong};
    }

    private JPanel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 224, 230)),
                BorderFactory.createEmptyBorder(18, 18, 18, 18)
        ));

        JLabel lblT = new JLabel(title);
        lblT.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblT.setForeground(new Color(100, 116, 139));

        JLabel lblV = new JLabel(value);
        lblV.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblV.setForeground(color);

        card.add(lblT);
        card.add(Box.createVerticalStrut(12));
        card.add(lblV);
        return card;
    }

    private JPanel createInfoBox(String title, String contentHtml, Color accentColor) {
        JPanel box = new JPanel(new BorderLayout(0, 10));
        box.setBackground(Color.WHITE);
        box.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 224, 230)),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTitle.setForeground(accentColor);
        box.add(lblTitle, BorderLayout.NORTH);

        JLabel lblContent = new JLabel(contentHtml);
        lblContent.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblContent.setForeground(new Color(51, 65, 85));
        box.add(lblContent, BorderLayout.CENTER);

        return box;
    }

    // --- PANEL 2: TRA CỨU LƯƠNG CÁ NHÂN (Giao diện mới gọn gàng) ---
    private JPanel createLuongPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel lblHeaderTitle = new JLabel("💰 Thông Tin Lương & Thu Nhập Cá Nhân");
        lblHeaderTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblHeaderTitle.setForeground(new Color(41, 128, 185));
        panel.add(lblHeaderTitle, BorderLayout.NORTH);

        String[] cols = {"Khoản Mục Lượng", "Giá Trị / Số Tiền (VNĐ)"};
        modelLuongNv = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(modelLuongNv);
        table.setRowHeight(35);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(41, 128, 185));
        table.getTableHeader().setForeground(Color.BLACK);
        table.setSelectionBackground(new Color(224, 242, 254));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 224, 230)),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        panel.add(scrollPane, BorderLayout.CENTER);

        loadLuongCaNhan();

        return panel;
    }

    private void loadLuongCaNhan() {
        if (modelLuongNv == null) return;
        modelLuongNv.setRowCount(0);

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT luong_co_ban FROM nhan_vien WHERE id = ?";
            double luongCb = 0;
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, currentNhanVienId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        luongCb = rs.getDouble("luong_co_ban");
                    }
                }
            }

            double bhxh = luongCb * 0.08;
            double bhyt = luongCb * 0.015;
            double bhtn = luongCb * 0.01;
            double thucNhan = luongCb - (bhxh + bhyt + bhtn);

            modelLuongNv.addRow(new Object[]{"1. Lương cơ bản", currencyFormat.format(luongCb) + " VNĐ"});
            modelLuongNv.addRow(new Object[]{"2. Phụ cấp công việc", "0 VNĐ"});
            modelLuongNv.addRow(new Object[]{"3. Khấu trừ BHXH (8%)", "- " + currencyFormat.format(bhxh) + " VNĐ"});
            modelLuongNv.addRow(new Object[]{"4. Khấu trừ BHYT (1.5%)", "- " + currencyFormat.format(bhyt) + " VNĐ"});
            modelLuongNv.addRow(new Object[]{"5. Khấu trừ BHTN (1%)", "- " + currencyFormat.format(bhtn) + " VNĐ"});
            modelLuongNv.addRow(new Object[]{"✨ THỰC NHẬN THỰC TẾ", currencyFormat.format(thucNhan) + " VNĐ"});

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // --- PANEL 3: CHẤM CÔNG TRỰC TIẾP (VÀO CA / KẾT THÚC CA) ---
    private JPanel createChamCongPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel panelCard = new JPanel();
        panelCard.setLayout(new BoxLayout(panelCard, BoxLayout.Y_AXIS));
        panelCard.setBackground(Color.WHITE);
        panelCard.setPreferredSize(new Dimension(500, 320));
        panelCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 224, 230)),
                BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));

        JLabel lblTitle = new JLabel("CHẤM CÔNG HÔM NAY");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(new Color(41, 128, 185));
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        lblCurrentTime = new JLabel("Thời gian: --:--:--");
        lblCurrentTime.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblCurrentTime.setForeground(new Color(51, 65, 85));
        lblCurrentTime.setAlignmentX(Component.CENTER_ALIGNMENT);

        Timer timer = new Timer(1000, ev -> {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            lblCurrentTime.setText("🕒 " + sdf.format(new Date()));
        });
        timer.start();

        btnCheckIn = new JButton("Vào Ca (Check-in)");
        styleBigActionButton(btnCheckIn, new Color(40, 167, 69));
        btnCheckIn.addActionListener(e -> handleCheckIn());

        btnCheckOut = new JButton("Kết Thúc Ca (Check-out)");
        styleBigActionButton(btnCheckOut, new Color(220, 53, 69));
        btnCheckOut.addActionListener(e -> handleCheckOut());

        lblStatusChamCong = new JLabel("Trạng thái: Đang kiểm tra...");
        lblStatusChamCong.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        lblStatusChamCong.setForeground(Color.GRAY);
        lblStatusChamCong.setAlignmentX(Component.CENTER_ALIGNMENT);

        panelCard.add(lblTitle);
        panelCard.add(Box.createVerticalStrut(20));
        panelCard.add(lblCurrentTime);
        panelCard.add(Box.createVerticalStrut(25));
        panelCard.add(btnCheckIn);
        panelCard.add(Box.createVerticalStrut(15));
        panelCard.add(btnCheckOut);
        panelCard.add(Box.createVerticalStrut(25));
        panelCard.add(lblStatusChamCong);

        panel.add(panelCard);
        kiemTraTrangThaiChamCongHomNay();

        return panel;
    }

    private void styleBigActionButton(JButton btn, Color bgColor) {
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(bgColor);
        btn.setForeground(Color.black);
        btn.setFocusPainted(false);
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(300, 45));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void kiemTraTrangThaiChamCongHomNay() {
        String today = LocalDate.now().toString();
        String sql = "SELECT trang_thai FROM cham_cong WHERE nhan_vien_id = ? AND DATE(ngay_gio) = ? ORDER BY ngay_gio DESC";

        boolean daVaoCa = false;
        boolean daKetThucCa = false;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, currentNhanVienId);
            ps.setString(2, today);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String tt = rs.getString("trang_thai");
                    if (tt != null && (tt.toLowerCase().contains("vào") || tt.toLowerCase().contains("đúng giờ") || tt.toLowerCase().contains("đi trễ"))) {
                        daVaoCa = true;
                    }
                    if (tt != null && (tt.toLowerCase().contains("kết thúc") || tt.toLowerCase().contains("ra"))) {
                        daKetThucCa = true;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (btnCheckIn != null && btnCheckOut != null && lblStatusChamCong != null) {

            // Nền đệm màu trắng
            lblStatusChamCong.setOpaque(true);
            lblStatusChamCong.setBackground(Color.WHITE);

            // Chữ màu đen
            lblStatusChamCong.setForeground(Color.BLACK);

            // Căn giữa và tạo khoảng đệm
            lblStatusChamCong.setHorizontalAlignment(SwingConstants.CENTER);
            lblStatusChamCong.setBorder(
                    BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(new Color(220, 220, 220)),
                            BorderFactory.createEmptyBorder(8, 15, 8, 15)
                    )
            );

            if (!daVaoCa) {

                btnCheckIn.setEnabled(true);
                btnCheckOut.setEnabled(false);

                lblStatusChamCong.setText(
                        "Trạng thái: Chưa vào ca hôm nay"
                );

            } else if (daVaoCa && !daKetThucCa) {

                btnCheckIn.setEnabled(false);
                btnCheckOut.setEnabled(true);

                lblStatusChamCong.setText(
                        "Trạng thái: Đang trong ca làm việc"
                );

            } else {

                btnCheckIn.setEnabled(false);
                btnCheckOut.setEnabled(false);

                lblStatusChamCong.setText(
                        "Trạng thái: Đã hoàn thành ca hôm nay"
                );
            }
        }
    }

    private void handleCheckIn() {
        String timeNow = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        String trangThai = "Vào ca";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO cham_cong (nhan_vien_id, ngay_gio, trang_thai) VALUES (?, ?, ?)")) {
            ps.setInt(1, currentNhanVienId);
            ps.setString(2, timeNow);
            ps.setString(3, trangThai);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Chấm công VÀO CA thành công lúc: " + timeNow);
            kiemTraTrangThaiChamCongHomNay();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi chấm công vào ca: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleCheckOut() {
        String timeNow = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        String trangThai = "Kết thúc ca";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO cham_cong (nhan_vien_id, ngay_gio, trang_thai) VALUES (?, ?, ?)")) {
            ps.setInt(1, currentNhanVienId);
            ps.setString(2, timeNow);
            ps.setString(3, trangThai);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Chấm công KẾT THÚC CA thành công lúc: " + timeNow);
            kiemTraTrangThaiChamCongHomNay();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi chấm công kết thúc ca: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- PANEL 4: LỊCH SỬ CHẤM CÔNG ---
    private JPanel createLichSuChamCongPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel lblTitle = new JLabel("📋 Lịch Sử Chấm Công Cá Nhân");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTitle.setForeground(new Color(41, 128, 185));
        panel.add(lblTitle, BorderLayout.NORTH);

        String[] cols = {"Ngày Chấm Công", "Giờ Vào", "Giờ Ra", "Trạng Thái"};
        modelChamCongNv = new DefaultTableModel(cols, 0);
        JTable table = new JTable(modelChamCongNv);
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        loadLichSuChamCong();

        return panel;
    }

    private void loadLichSuChamCong() {
        if (modelChamCongNv == null) return;
        modelChamCongNv.setRowCount(0);
        String sql = "SELECT ngay_gio, trang_thai FROM cham_cong WHERE nhan_vien_id = ? ORDER BY ngay_gio ASC";

        Map<String, String[]> mapChamCong = new LinkedHashMap<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, currentNhanVienId);
            try (ResultSet rs = ps.executeQuery()) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

                while (rs.next()) {
                    Timestamp dt = rs.getTimestamp("ngay_gio");
                    String trangThai = rs.getString("trang_thai");
                    if (dt == null) continue;

                    String ngayStr = dateFormat.format(dt);
                    String gioStr = timeFormat.format(dt);

                    mapChamCong.putIfAbsent(ngayStr, new String[]{"--:--:--", "--:--:--", "Đang làm việc"});
                    String[] data = mapChamCong.get(ngayStr);

                    if (trangThai != null) {
                        String ttLower = trangThai.toLowerCase();
                        if (ttLower.contains("vào") || ttLower.contains("đúng giờ") || ttLower.contains("đi trễ")) {
                            data[0] = gioStr;
                            data[2] = trangThai;
                        } else if (ttLower.contains("kết thúc") || ttLower.contains("ra")) {
                            data[1] = gioStr;
                            data[2] = "Hoàn thành ca";
                        }
                    }
                }

                List<String> listNgay = new ArrayList<>(mapChamCong.keySet());
                listNgay.sort((a, b) -> b.compareTo(a));

                for (String ngay : listNgay) {
                    String[] data = mapChamCong.get(ngay);
                    modelChamCongNv.addRow(new Object[]{ngay, data[0], data[1], data[2]});
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // --- PANEL 5: ĐƠN XIN NGHỈ PHÉP ---
    private JPanel createNghiPhepPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel topAction = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topAction.setOpaque(false);
        JButton btnTaoDon = new JButton("Tạo Đơn Nghỉ Phép Mới");
        btnTaoDon.setBackground(new Color(46, 204, 113));
        btnTaoDon.setForeground(Color.black);
        btnTaoDon.setFocusPainted(false);
        topAction.add(btnTaoDon);
        panel.add(topAction, BorderLayout.NORTH);

        String[] cols = {"ID", "Lý Do Nghỉ", "Từ Ngày", "Đến Ngày", "Trạng Thái Phê Duyệt"};
        modelNghiPhep = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable table = new JTable(modelNghiPhep);
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        btnTaoDon.addActionListener(e -> hienThiDialogTaoDonNghiPhep());
        loadNghiPhepCaNhan();

        return panel;
    }

    private void loadNghiPhepCaNhan() {
        if (modelNghiPhep == null) return;
        modelNghiPhep.setRowCount(0);
        String sql = "SELECT id, ly_do, ngay_bat_dau, ngay_ket_thuc, trang_thai FROM nghi_phep WHERE nhan_vien_id = ? ORDER BY id DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, currentNhanVienId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    modelNghiPhep.addRow(new Object[]{
                            rs.getInt("id"),
                            rs.getString("ly_do"),
                            rs.getString("ngay_bat_dau"),
                            rs.getString("ngay_ket_thuc"),
                            rs.getString("trang_thai")
                    });
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hienThiDialogTaoDonNghiPhep() {
        JDialog dialog = new JDialog(this, "Tạo Đơn Xin Nghỉ Phép Mới", true);
        dialog.setSize(420, 320);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new GridLayout(5, 2, 10, 10));
        ((JPanel) dialog.getContentPane()).setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JTextField txtTuNgay = new JTextField(LocalDate.now().toString());
        JTextField txtDenNgay = new JTextField(LocalDate.now().toString());
        JTextField txtLyDo = new JTextField();

        dialog.add(new JLabel("Từ ngày (YYYY-MM-DD):"));
        dialog.add(txtTuNgay);
        dialog.add(new JLabel("Đến ngày (YYYY-MM-DD):"));
        dialog.add(txtDenNgay);
        dialog.add(new JLabel("Lý do nghỉ:"));
        dialog.add(txtLyDo);

        JButton btnGui = new JButton("Gửi Đơn");
        btnGui.setBackground(new Color(46, 204, 113));
        btnGui.setForeground(Color.BLACK);
        btnGui.setFocusPainted(false);

        JButton btnHuy = new JButton("Hủy");
        btnHuy.setBackground(new Color(220, 53, 69));
        btnHuy.setForeground(Color.BLACK);
        btnHuy.setFocusPainted(false);

        dialog.add(btnGui);
        dialog.add(btnHuy);

        btnHuy.addActionListener(e -> dialog.dispose());

        btnGui.addActionListener(e -> {
            String tuNgayStr = txtTuNgay.getText().trim();
            String denNgayStr = txtDenNgay.getText().trim();
            String lyDo = txtLyDo.getText().trim();

            if (tuNgayStr.isEmpty() || denNgayStr.isEmpty() || lyDo.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Vui lòng nhập đầy đủ thông tin!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                LocalDate tuNgay = LocalDate.parse(tuNgayStr);
                LocalDate denNgay = LocalDate.parse(denNgayStr);

                if (denNgay.isBefore(tuNgay)) {
                    JOptionPane.showMessageDialog(dialog, "Đến ngày không được nhỏ hơn Từ ngày!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                long soNgayNghi = ChronoUnit.DAYS.between(tuNgay, denNgay) + 1;

                String sql = "INSERT INTO nghi_phep (nhan_vien_id, ngay_bat_dau, ngay_ket_thuc, so_ngay_nghi, ly_do, trang_thai) VALUES (?, ?, ?, ?, ?, 'Chờ duyệt')";
                try (Connection conn = DatabaseConnection.getConnection();
                     PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setInt(1, currentNhanVienId);
                    ps.setString(2, tuNgayStr);
                    ps.setString(3, denNgayStr);
                    ps.setInt(4, (int) soNgayNghi);
                    ps.setString(5, lyDo);
                    ps.executeUpdate();

                    JOptionPane.showMessageDialog(dialog, "Gửi đơn nghỉ phép thành công! Đang chờ phê duyệt.");
                    dialog.dispose();
                    loadNghiPhepCaNhan();
                }
            } catch (DateTimeParseException ex) {
                JOptionPane.showMessageDialog(dialog, "Định dạng ngày không hợp lệ! Vui lòng nhập YYYY-MM-DD.", "Lỗi định dạng", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(dialog, "Lỗi kết nối cơ sở dữ liệu: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.setVisible(true);
    }

    // --- PANEL 6: ĐĂNG KÝ TĂNG CA ---
    private JPanel createTangCaPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel topAction = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topAction.setOpaque(false);
        JButton btnDangKy = new JButton("Đăng Ký Giờ Tăng Ca");
        btnDangKy.setBackground(new Color(230, 126, 34));
        btnDangKy.setForeground(Color.black);
        btnDangKy.setFocusPainted(false);
        topAction.add(btnDangKy);
        panel.add(topAction, BorderLayout.NORTH);

        String[] cols = {"ID", "Ngày Tăng Ca", "Số Giờ", "Hệ Số", "Trạng Thái"};
        modelTangCaNv = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable table = new JTable(modelTangCaNv);
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        btnDangKy.addActionListener(e -> hienThiDialogDangKyTangCa());
        loadTangCaCaNhan();

        return panel;
    }

    private void loadTangCaCaNhan() {
        if (modelTangCaNv == null) return;
        modelTangCaNv.setRowCount(0);
        String sql = "SELECT id, ngay_tang_ca, so_gio, he_so, trang_thai FROM tang_ca WHERE nhan_vien_id = ? ORDER BY id DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, currentNhanVienId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    modelTangCaNv.addRow(new Object[]{
                            rs.getInt("id"),
                            rs.getDate("ngay_tang_ca"),
                            rs.getDouble("so_gio"),
                            rs.getDouble("he_so"),
                            rs.getString("trang_thai")
                    });
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hienThiDialogDangKyTangCa() {
        JDialog dialog = new JDialog(this, "Đăng Ký Giờ Tăng Ca Mới", true);
        dialog.setSize(420, 300);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new GridLayout(4, 2, 10, 10));
        ((JPanel) dialog.getContentPane()).setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JTextField txtNgay = new JTextField(LocalDate.now().toString());
        JTextField txtSoGio = new JTextField();
        JTextField txtHeSo = new JTextField("1.5");

        dialog.add(new JLabel("Ngày tăng ca (YYYY-MM-DD):"));
        dialog.add(txtNgay);
        dialog.add(new JLabel("Số giờ tăng ca:"));
        dialog.add(txtSoGio);
        dialog.add(new JLabel("Hệ số (VD: 1.5):"));
        dialog.add(txtHeSo);

        JButton btnGui = new JButton("Gửi Đăng Ký");
        btnGui.setBackground(new Color(230, 126, 34));
        btnGui.setForeground(Color.black);
        btnGui.setFocusPainted(false);

        JButton btnHuy = new JButton("Hủy");
        btnHuy.setBackground(new Color(220, 53, 69));
        btnHuy.setForeground(Color.BLACK);
        btnHuy.setFocusPainted(false);

        dialog.add(btnGui);
        dialog.add(btnHuy);

        btnHuy.addActionListener(e -> dialog.dispose());

        btnGui.addActionListener(e -> {
            String ngayStr = txtNgay.getText().trim();
            String soGioStr = txtSoGio.getText().trim();
            String heSoStr = txtHeSo.getText().trim();

            if (ngayStr.isEmpty() || soGioStr.isEmpty() || heSoStr.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Vui lòng nhập đầy đủ thông tin!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                LocalDate ngayTangCa = LocalDate.parse(ngayStr);
                double soGio = Double.parseDouble(soGioStr);
                double heSo = Double.parseDouble(heSoStr);

                String sql = "INSERT INTO tang_ca (nhan_vien_id, ngay_tang_ca, so_gio, he_so, trang_thai) VALUES (?, ?, ?, ?, 'Chờ duyệt')";
                try (Connection conn = DatabaseConnection.getConnection();
                     PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setInt(1, currentNhanVienId);
                    ps.setString(2, ngayStr);
                    ps.setDouble(3, soGio);
                    ps.setDouble(4, heSo);
                    ps.executeUpdate();

                    JOptionPane.showMessageDialog(dialog, "Gửi đăng ký tăng ca thành công! Đang chờ phê duyệt.");
                    dialog.dispose();
                    loadTangCaCaNhan();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Số giờ hoặc hệ số phải là định dạng số hợp lệ!", "Lỗi định dạng", JOptionPane.ERROR_MESSAGE);
            } catch (DateTimeParseException ex) {
                JOptionPane.showMessageDialog(dialog, "Định dạng ngày không hợp lệ! Vui lòng nhập YYYY-MM-DD.", "Lỗi định dạng", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(dialog, "Lỗi kết nối cơ sở dữ liệu: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.setVisible(true);
    }
}