package vn.edu.eaut.model;

public class NghiPhep {
    private int id;
    private int nhanVienId;
    private String maNv;
    private String hoTen;
    private String ngayBatDau;
    private String ngayKetThuc;
    private int soNgayNghi;
    private String lyDo;
    private String trangThai;

    // Các trường bổ sung cho quy trình duyệt
    private String nguoiDuyet;
    private String ngayDuyet;
    private String lyDoTuChoi;

    public NghiPhep() {
    }

    public NghiPhep(int id, int nhanVienId, String ngayBatDau, String ngayKetThuc, int soNgayNghi, String lyDo, String trangThai) {
        this.id = id;
        this.nhanVienId = nhanVienId;
        this.ngayBatDau = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
        this.soNgayNghi = soNgayNghi;
        this.lyDo = lyDo;
        this.trangThai = trangThai;
    }

    public NghiPhep(int id, int nhanVienId, String ngayBatDau, String ngayKetThuc, int soNgayNghi, String lyDo, String trangThai, String nguoiDuyet, String ngayDuyet, String lyDoTuChoi) {
        this.id = id;
        this.nhanVienId = nhanVienId;
        this.ngayBatDau = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
        this.soNgayNghi = soNgayNghi;
        this.lyDo = lyDo;
        this.trangThai = trangThai;
        this.nguoiDuyet = nguoiDuyet;
        this.ngayDuyet = ngayDuyet;
        this.lyDoTuChoi = lyDoTuChoi;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getNhanVienId() { return nhanVienId; }
    public void setNhanVienId(int nhanVienId) { this.nhanVienId = nhanVienId; }

    public String getMaNv() { return maNv; }
    public void setMaNv(String maNv) { this.maNv = maNv; }

    public String getHoTen() { return hoTen; }
    public void setHoTen(String hoTen) { this.hoTen = hoTen; }

    public String getNgayBatDau() { return ngayBatDau; }
    public void setNgayBatDau(String ngayBatDau) { this.ngayBatDau = ngayBatDau; }

    public String getNgayKetThuc() { return ngayKetThuc; }
    public void setNgayKetThuc(String ngayKetThuc) { this.ngayKetThuc = ngayKetThuc; }

    public int getSoNgayNghi() { return soNgayNghi; }
    public void setSoNgayNghi(int soNgayNghi) { this.soNgayNghi = soNgayNghi; }

    public String getLyDo() { return lyDo; }
    public void setLyDo(String lyDo) { this.lyDo = lyDo; }

    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }

    public String getNguoiDuyet() { return nguoiDuyet; }
    public void setNguoiDuyet(String nguoiDuyet) { this.nguoiDuyet = nguoiDuyet; }

    public String getNgayDuyet() { return ngayDuyet; }
    public void setNgayDuyet(String ngayDuyet) { this.ngayDuyet = ngayDuyet; }

    public String getLyDoTuChoi() { return lyDoTuChoi; }
    public void setLyDoTuChoi(String lyDoTuChoi) { this.lyDoTuChoi = lyDoTuChoi; }
}