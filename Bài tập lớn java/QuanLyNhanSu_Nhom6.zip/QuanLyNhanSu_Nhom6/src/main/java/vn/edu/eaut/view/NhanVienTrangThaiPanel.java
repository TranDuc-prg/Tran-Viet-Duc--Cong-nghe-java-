package vn.edu.eaut.view;

import vn.edu.eaut.dao.NhanVienDAO;
import vn.edu.eaut.model.NhanVienTrangThaiDTO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NhanVienTrangThaiPanel extends JPanel {
    private JTable tblTrangThai;
    private DefaultTableModel tableModel;
    private TableRowSorter<DefaultTableModel> rowSorter;
    private JTextField txtSearch;
    private JButton btnReload, btnDetail;
    private NhanVienDAO nhanVienDAO;

    // Thẻ KPI Thống kê
    private JLabel lblTotalValue, lblWorkingValue, lblOnTimeValue, lblLateValue;

    // Biểu đồ
    private PieChartPanel pieChartPanel;
    private BarChartPanel barChartPanel;

    public NhanVienTrangThaiPanel() {
        setLayout(new BorderLayout(12, 12));
        setBackground(UITheme.BG);
        setBorder(new EmptyBorder(14, 14, 14, 14));

        nhanVienDAO = new NhanVienDAO();

        // 1. Header (Tiêu đề + Nút thao tác)
        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.setOpaque(false);

        JLabel lblTitle = new JLabel("QUẢN LÝ TRẠNG THÁI & HỒ SƠ NHÂN SỰ");
        lblTitle.setFont(UITheme.font(Font.BOLD, 18));
        lblTitle.setForeground(UITheme.NAVY);
        topContainer.add(lblTitle, BorderLayout.WEST);

        // Thanh tìm kiếm và nút chức năng phía trên phải
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actionPanel.setOpaque(false);

        JLabel lblSearch = new JLabel("Tìm kiếm:");
        lblSearch.setForeground(Color.BLACK);

        txtSearch = new JTextField(15);
        txtSearch.setFont(UITheme.font(Font.PLAIN, 13));
        txtSearch.setForeground(Color.BLACK);
        txtSearch.setToolTipText("Tìm kiếm theo Mã NV hoặc Tên...");
        txtSearch.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { filterTable(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { filterTable(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filterTable(); }
        });

        btnDetail = new JButton("Xem Chi Tiết");
        styleButton(btnDetail, new Color(59, 130, 246));
        btnDetail.setForeground(Color.BLACK);
        btnDetail.addActionListener(e -> showEmployeeDetail());

        btnReload = new JButton("Làm mới");
        styleButton(btnReload, new Color(16, 185, 129));
        btnReload.setForeground(Color.BLACK);
        btnReload.addActionListener(e -> loadDataToTable());

        actionPanel.add(lblSearch);
        actionPanel.add(txtSearch);
        actionPanel.add(btnDetail);
        actionPanel.add(btnReload);

        topContainer.add(actionPanel, BorderLayout.EAST);

        // 2. Thẻ KPI Thống kê
        JPanel statsPanel = new JPanel(new GridLayout(1, 4, 12, 0));
        statsPanel.setOpaque(false);

        lblTotalValue = new JLabel("0", SwingConstants.CENTER);
        lblWorkingValue = new JLabel("0", SwingConstants.CENTER);
        lblOnTimeValue = new JLabel("0", SwingConstants.CENTER);
        lblLateValue = new JLabel("0", SwingConstants.CENTER);

        statsPanel.add(createStatCard("Tổng Nhân Sự", lblTotalValue, new Color(59, 130, 246)));
        statsPanel.add(createStatCard("Đang Làm Việc", lblWorkingValue, new Color(16, 185, 129)));
        statsPanel.add(createStatCard("Đúng Giờ", lblOnTimeValue, new Color(139, 92, 246)));
        statsPanel.add(createStatCard("Đi Muộn / Khác", lblLateValue, new Color(245, 158, 11)));

        // 3. Khối Biểu Đồ (Tăng chiều cao lên 210 để chứa góc chữ xoay thoải mái)
        JPanel chartsPanel = new JPanel(new GridLayout(1, 2, 12, 0));
        chartsPanel.setOpaque(false);
        chartsPanel.setPreferredSize(new Dimension(0, 210));

        pieChartPanel = new PieChartPanel();
        barChartPanel = new BarChartPanel();

        chartsPanel.add(pieChartPanel);
        chartsPanel.add(barChartPanel);

        // Gom nhóm North
        JPanel northWrapper = new JPanel();
        northWrapper.setLayout(new BoxLayout(northWrapper, BoxLayout.Y_AXIS));
        northWrapper.setOpaque(false);

        northWrapper.add(topContainer);
        northWrapper.add(Box.createVerticalStrut(10));
        northWrapper.add(statsPanel);
        northWrapper.add(Box.createVerticalStrut(10));
        northWrapper.add(chartsPanel);
        northWrapper.add(Box.createVerticalStrut(10));

        add(northWrapper, BorderLayout.NORTH);

        // 4. Bảng Dữ Liệu
        String[] columnNames = {"Mã NV", "Họ và Tên", "Phòng Ban", "Trạng Thái Nhân Sự", "Trạng Thái Làm Việc", "Thời Gian Chấm Công"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblTrangThai = new JTable(tableModel);
        tblTrangThai.setRowHeight(30);
        tblTrangThai.getTableHeader().setFont(UITheme.font(Font.BOLD, 12));
        tblTrangThai.getTableHeader().setBackground(new Color(241, 245, 249));

        rowSorter = new TableRowSorter<>(tableModel);
        tblTrangThai.setRowSorter(rowSorter);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        tblTrangThai.getColumnModel().getColumn(0).setPreferredWidth(70);
        tblTrangThai.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tblTrangThai.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        tblTrangThai.getColumnModel().getColumn(4).setCellRenderer(new StatusCellRenderer());

        tblTrangThai.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    showEmployeeDetail();
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(tblTrangThai);
        scrollPane.setBorder(BorderFactory.createLineBorder(UITheme.BORDER));
        add(scrollPane, BorderLayout.CENTER);

        loadDataToTable();
    }

    private void styleButton(JButton btn, Color bg) {
        btn.setFont(UITheme.font(Font.BOLD, 11));
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private JPanel createStatCard(String title, JLabel valueLabel, Color accentColor) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER, 1),
                new EmptyBorder(8, 12, 8, 12)
        ));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(UITheme.font(Font.PLAIN, 11));
        lblTitle.setForeground(Color.BLACK); // Đảm bảo chữ màu đen

        valueLabel.setFont(UITheme.font(Font.BOLD, 20));
        valueLabel.setForeground(accentColor);

        card.add(lblTitle, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    private void filterTable() {
        String text = txtSearch.getText().trim();
        if (text.length() == 0) {
            rowSorter.setRowFilter(null);
        } else {
            rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
        }
    }

    private void loadDataToTable() {
        tableModel.setRowCount(0);
        List<NhanVienTrangThaiDTO> list = nhanVienDAO.getDanhSachNhanVienTrangThai();

        int total = list.size();
        int working = 0;
        int onTime = 0;
        int late = 0;
        int otherCc = 0;

        Map<String, Integer> deptMap = new HashMap<>();

        for (NhanVienTrangThaiDTO nv : list) {
            String trangThaiNv = nv.getTrangThaiNhanVien() != null ? nv.getTrangThaiNhanVien() : "Đang làm việc";
            String trangThaiCc = nv.getTrangThaiChamCong() != null ? nv.getTrangThaiChamCong() : "Chưa chấm công";
            String phongBan = nv.getTenPhongBan() != null ? nv.getTenPhongBan() : "Chưa phân ban";

            if ("Đang làm việc".equalsIgnoreCase(trangThaiNv)) working++;
            if ("Đúng giờ".equalsIgnoreCase(trangThaiCc)) onTime++;
            else if ("Đi muộn".equalsIgnoreCase(trangThaiCc)) late++;
            else otherCc++;

            deptMap.put(phongBan, deptMap.getOrDefault(phongBan, 0) + 1);

            Object[] row = {
                    nv.getMaNv(),
                    nv.getHoTen(),
                    phongBan,
                    trangThaiNv,
                    trangThaiCc,
                    nv.getThoiGianChamCong() != null ? nv.getThoiGianChamCong() : "---"
            };
            tableModel.addRow(row);
        }

        lblTotalValue.setText(String.valueOf(total));
        lblWorkingValue.setText(String.valueOf(working));
        lblOnTimeValue.setText(String.valueOf(onTime));
        lblLateValue.setText(String.valueOf(late + otherCc));

        pieChartPanel.setData(onTime, late, otherCc);
        barChartPanel.setData(deptMap);
    }

    private void showEmployeeDetail() {
        int selectedRow = tblTrangThai.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một nhân viên trong bảng để xem chi tiết!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int modelRow = tblTrangThai.convertRowIndexToModel(selectedRow);
        String maNv = tableModel.getValueAt(modelRow, 0).toString();
        String hoTen = tableModel.getValueAt(modelRow, 1).toString();
        String phongBan = tableModel.getValueAt(modelRow, 2).toString();
        String trangThaiNv = tableModel.getValueAt(modelRow, 3).toString();
        String trangThaiCc = tableModel.getValueAt(modelRow, 4).toString();

        JDialog detailDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Hồ Sơ Chi Tiết: " + hoTen + " (" + maNv + ")", true);
        detailDialog.setSize(550, 400);
        detailDialog.setLocationRelativeTo(this);
        detailDialog.setLayout(new BorderLayout());

        JPanel infoPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        infoPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        infoPanel.setBackground(Color.WHITE);

        JLabel lbl1 = new JLabel("Mã Nhân Viên:"); lbl1.setForeground(Color.BLACK);
        JLabel val1 = new JLabel(maNv); val1.setForeground(Color.BLACK);
        JLabel lbl2 = new JLabel("Họ và Tên:"); lbl2.setForeground(Color.BLACK);
        JLabel val2 = new JLabel(hoTen); val2.setForeground(Color.BLACK);
        JLabel lbl3 = new JLabel("Phòng Ban:"); lbl3.setForeground(Color.BLACK);
        JLabel val3 = new JLabel(phongBan); val3.setForeground(Color.BLACK);
        JLabel lbl4 = new JLabel("Trạng Thái Nhân Sự:"); lbl4.setForeground(Color.BLACK);
        JLabel val4 = new JLabel(trangThaiNv); val4.setForeground(Color.BLACK);
        JLabel lbl5 = new JLabel("Trạng Thái Làm Việc:"); lbl5.setForeground(Color.BLACK);
        JLabel val5 = new JLabel(trangThaiCc); val5.setForeground(Color.BLACK);
        JLabel lbl6 = new JLabel("Ghi chú hồ sơ:"); lbl6.setForeground(Color.BLACK);
        JLabel val6 = new JLabel("Đã cập nhật thông tin đầy đủ."); val6.setForeground(Color.BLACK);

        infoPanel.add(lbl1); infoPanel.add(val1);
        infoPanel.add(lbl2); infoPanel.add(val2);
        infoPanel.add(lbl3); infoPanel.add(val3);
        infoPanel.add(lbl4); infoPanel.add(val4);
        infoPanel.add(lbl5); infoPanel.add(val5);
        infoPanel.add(lbl6); infoPanel.add(val6);

        detailDialog.add(infoPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnClose = new JButton("Đóng");
        btnClose.addActionListener(e -> detailDialog.dispose());
        bottomPanel.add(btnClose);
        detailDialog.add(bottomPanel, BorderLayout.SOUTH);

        detailDialog.setVisible(true);
    }

    private static class PieChartPanel extends JPanel {
        private int onTime, late, other;
        public PieChartPanel() {
            setBackground(Color.WHITE);
            setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(UITheme.BORDER), "Tỷ Lệ Chấm Công", 0, 0, UITheme.font(Font.BOLD, 12), Color.BLACK));
        }
        public void setData(int onTime, int late, int other) {
            this.onTime = onTime; this.late = late; this.other = other; repaint();
        }
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int total = onTime + late + other;
            if (total == 0) return;
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int size = Math.min(getWidth(), getHeight()) - 50;
            int x = 20, y = (getHeight() - size) / 2 + 5;
            int a1 = (int) Math.round((double) onTime / total * 360);
            int a2 = (int) Math.round((double) late / total * 360);
            int a3 = 360 - a1 - a2;

            g2.setColor(new Color(16, 185, 129)); g2.fillArc(x, y, size, size, 0, a1);
            g2.setColor(new Color(245, 158, 11)); g2.fillArc(x, y, size, size, a1, a2);
            g2.setColor(new Color(59, 130, 246)); g2.fillArc(x, y, size, size, a1 + a2, a3);

            int lx = x + size + 20, ly = y + 20;
            drawLegend(g2, lx, ly, new Color(16, 185, 129), "Đúng giờ (" + onTime + ")");
            drawLegend(g2, lx, ly + 25, new Color(245, 158, 11), "Đi muộn (" + late + ")");
            drawLegend(g2, lx, ly + 50, new Color(59, 130, 246), "Khác (" + other + ")");
        }
        private void drawLegend(Graphics2D g2, int x, int y, Color c, String text) {
            g2.setColor(c); g2.fillRect(x, y, 12, 12);
            g2.setColor(Color.BLACK); // Đảm bảo chữ chú thích màu đen
            g2.setFont(UITheme.font(Font.PLAIN, 11));
            g2.drawString(text, x + 18, y + 10);
        }
    }

    private static class BarChartPanel extends JPanel {
        private Map<String, Integer> deptData = new HashMap<>();
        public BarChartPanel() {
            setBackground(Color.WHITE);
            setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(UITheme.BORDER), "Phân Bổ Phòng Ban", 0, 0, UITheme.font(Font.BOLD, 12), Color.BLACK));
        }
        public void setData(Map<String, Integer> data) { this.deptData = data; repaint(); }
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (deptData == null || deptData.isEmpty()) return;
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int maxVal = 1;
            for (int v : deptData.values()) if (v > maxVal) maxVal = v;

            int pL = 30, pR = 20, pT = 30, pB = 75; // Nới rộng đáy để tên phòng ban không bị cắt
            int cW = getWidth() - pL - pR;
            int cH = getHeight() - pT - pB;

            int size = deptData.size();
            int slotWidth = cW / Math.max(1, size);
            int barW = Math.max(15, slotWidth - 16);

            int index = 0;
            for (Map.Entry<String, Integer> entry : deptData.entrySet()) {
                int val = entry.getValue();
                int h = (int) ((double) val / maxVal * cH);
                int x = pL + index * slotWidth + (slotWidth - barW) / 2;
                int y = getHeight() - pB - h;

                // Vẽ cột
                g2.setColor(new Color(99, 102, 241));
                g2.fillRoundRect(x, y, barW, h, 4, 4);

                // Vẽ số lượng phía trên cột (chữ màu đen)
                g2.setColor(Color.BLACK);
                g2.setFont(UITheme.font(Font.BOLD, 10));
                String valStr = String.valueOf(val);
                int strWidth = g2.getFontMetrics().stringWidth(valStr);
                g2.drawString(valStr, x + (barW - strWidth) / 2, y - 5);

                // Vẽ tên phòng ban nghiêng 35 độ, hiển thị đầy đủ tên và chữ màu đen
                Graphics2D g2d = (Graphics2D) g2.create();
                g2d.setFont(UITheme.font(Font.PLAIN, 10));
                g2d.setColor(Color.BLACK); // Đặt màu chữ đen hoàn toàn

                int textX = x + barW / 2;
                int textY = getHeight() - pB + 10;

                g2d.translate(textX, textY);
                g2d.rotate(Math.toRadians(35));
                g2d.drawString(entry.getKey(), 0, 0);
                g2d.dispose();

                index++;
            }
        }
    }

    private static class StatusCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setHorizontalAlignment(JLabel.CENTER);
            if (!isSelected) {
                String val = value != null ? value.toString() : "";
                if (val.contains("Đúng giờ")) { setBackground(new Color(209, 250, 229)); setForeground(new Color(6, 95, 70)); }
                else if (val.contains("Đi muộn")) { setBackground(new Color(254, 243, 199)); setForeground(new Color(146, 64, 14)); }
                else if (val.contains("Vào ca") || val.contains("Kết thúc ca")) { setBackground(new Color(219, 234, 254)); setForeground(new Color(30, 64, 175)); }
                else { setBackground(Color.WHITE); setForeground(Color.BLACK); }
            }
            return c;
        }
    }
}