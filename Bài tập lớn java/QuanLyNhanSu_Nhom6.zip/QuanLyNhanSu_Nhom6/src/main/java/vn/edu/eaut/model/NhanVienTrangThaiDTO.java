package vn.edu.eaut.model;

public class NhanVienTrangThaiDTO {
    private String maNv;
    private String hoTen;
    private String tenPhongBan;
    private String trangThaiNhanVien;
    private String trangThaiChamCong;
    private String thoiGianChamCong;

    // Getters và Setters
    public String getMaNv() { return maNv; }
    public void setMaNv(String maNv) { this.maNv = maNv; }

    public String getHoTen() { return hoTen; }
    public void setHoTen(String hoTen) { this.hoTen = hoTen; }

    public String getTenPhongBan() { return tenPhongBan; }
    public void setTenPhongBan(String tenPhongBan) { this.tenPhongBan = tenPhongBan; }

    public String getTrangThaiNhanVien() { return trangThaiNhanVien; }
    public void setTrangThaiNhanVien(String trangThaiNhanVien) { this.trangThaiNhanVien = trangThaiNhanVien; }

    public String getTrangThaiChamCong() { return trangThaiChamCong; }
    public void setTrangThaiChamCong(String trangThaiChamCong) { this.trangThaiChamCong = trangThaiChamCong; }

    public String getThoiGianChamCong() { return thoiGianChamCong; }
    public void setThoiGianChamCong(String thoiGianChamCong) { this.thoiGianChamCong = thoiGianChamCong; }
}