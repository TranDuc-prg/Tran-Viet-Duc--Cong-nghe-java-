package vn.edu.eaut.view;

import vn.edu.eaut.connection.DatabaseConnection;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class ChamCongFrame extends JPanel {
    private JTable tableChiTiet, tableTongHop, tableTheoNgay;
    private DefaultTableModel modelChiTiet, modelTongHop, modelTheoNgay;
    private JTextField txtMaNV, txtNgayGio, txtTimKiem;
    private JComboBox<String> cbTrangThai;
    private JComboBox<Integer> cbThang, cbNam;
    private JFormattedTextField txtChonNgay;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi, btnTimKiem, btnThongKe, btnXemNgay, btnInNgay, btnXuatExcel, btnChiTietNV;
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public ChamCongFrame(String role) {
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(10, 10, 10, 10));
        setBackground(new Color(245, 247, 250));

        // --- Tiêu đề & Chọn Tháng/Năm lọc thống kê ---
        JPanel panelNorth = new JPanel(new BorderLayout());
        panelNorth.setOpaque(false);

        JLabel lblHeader = new JLabel("QUẢN LÝ CHẤM CÔNG NÂNG CAO", JLabel.LEFT);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblHeader.setForeground(new Color(41, 128, 185));
        panelNorth.add(lblHeader, BorderLayout.WEST);

        JPanel panelFilter = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panelFilter.setOpaque(false);
        panelFilter.add(createLabel("Tháng:"));
        cbThang = new JComboBox<>();
        for (int i = 1; i <= 12; i++) cbThang.addItem(i);
        cbThang.setSelectedItem(LocalDate.now().getMonthValue());
        panelFilter.add(cbThang);

        panelFilter.add(createLabel("Năm:"));
        cbNam = new JComboBox<>();
        int currentYear = LocalDate.now().getYear();
        for (int i = currentYear - 2; i <= currentYear + 2; i++) cbNam.addItem(i);
        cbNam.setSelectedItem(currentYear);
        panelFilter.add(cbNam);

        btnThongKe = new JButton("Lọc Tổng Hợp");
        styleButton(btnThongKe, new Color(41, 128, 185));
        panelFilter.add(btnThongKe);

        panelNorth.add(panelFilter, BorderLayout.EAST);
        add(panelNorth, BorderLayout.NORTH);

        // --- 1. Form nhập liệu chi tiết bên trái ---
        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setBackground(Color.WHITE);
        panelForm.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(200, 200, 200)),
                        " Thông tin chấm công ",
                        0, 0, new Font("Segoe UI", Font.BOLD, 13), new Color(41, 128, 185)
                ),
                new EmptyBorder(10, 10, 10, 10)
        ));
        panelForm.setPreferredSize(new Dimension(310, 0));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.weightx = 1.0;

        int row = 0;
        gbc.gridy = row++; panelForm.add(createLabel("Mã Nhân Viên:"), gbc);
        txtMaNV = new JTextField(); styleTextField(txtMaNV);
        gbc.gridy = row++; panelForm.add(txtMaNV, gbc);

        gbc.gridy = row++; panelForm.add(createLabel("Thời gian (YYYY-MM-DD HH:MM:SS):"), gbc);
        txtNgayGio = new JTextField(); styleTextField(txtNgayGio);
        gbc.gridy = row++; panelForm.add(txtNgayGio, gbc);

        gbc.gridy = row++; panelForm.add(createLabel("Trạng thái:"), gbc);
        cbTrangThai = new JComboBox<>(new String[]{"Đúng giờ", "Vào ca", "Kết thúc ca", "Ra ca", "Đi trễ", "Về sớm", "Nghỉ phép"});
        styleComboBox(cbTrangThai);
        gbc.gridy = row++; panelForm.add(cbTrangThai, gbc);

        JPanel panelButtons = new JPanel(new GridLayout(2, 2, 8, 8));
        panelButtons.setBackground(Color.WHITE);

        btnThem = new JButton("Thêm mới");
        btnSua = new JButton("Cập nhật");
        btnXoa = new JButton("Xóa bỏ");
        btnLamMoi = new JButton("Làm mới");

        styleButton(btnThem, new Color(46, 204, 113));
        styleButton(btnSua, new Color(230, 126, 34));
        styleButton(btnXoa, new Color(231, 76, 60));
        styleButton(btnLamMoi, new Color(52, 152, 219));

        panelButtons.add(btnThem);
        panelButtons.add(btnSua);
        panelButtons.add(btnXoa);
        panelButtons.add(btnLamMoi);

        gbc.gridy = row++;
        gbc.insets = new Insets(15, 5, 5, 5);
        panelForm.add(panelButtons, gbc);

        gbc.gridy = row++;
        gbc.weighty = 1.0;
        panelForm.add(new JLabel(""), gbc);

        add(panelForm, BorderLayout.WEST);

        // --- 2. Khu vực hiển thị bảng dữ liệu (3 Tab) ---
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 13));

        // --- Tab 1: Chi tiết từng lần ---
        JPanel panelTabChiTiet = new JPanel(new BorderLayout(0, 8));
        panelTabChiTiet.setOpaque(false);
        panelTabChiTiet.setBorder(new EmptyBorder(5, 5, 5, 5));

        JPanel panelSearch = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panelSearch.setOpaque(false);
        panelSearch.add(createLabel("Tìm kiếm Nhân Viên:"));
        txtTimKiem = new JTextField(15);
        styleTextField(txtTimKiem);
        panelSearch.add(txtTimKiem);

        btnTimKiem = new JButton("Tìm");
        styleButton(btnTimKiem, new Color(52, 152, 219));
        btnTimKiem.setPreferredSize(new Dimension(80, 28));
        panelSearch.add(btnTimKiem);
        panelTabChiTiet.add(panelSearch, BorderLayout.NORTH);

        modelChiTiet = new DefaultTableModel(new String[]{"ID", "Mã NV", "Họ Tên", "Thời Gian Chấm Công", "Trạng Thái"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tableChiTiet = new JTable(modelChiTiet);
        styleTable(tableChiTiet);
        panelTabChiTiet.add(new JScrollPane(tableChiTiet), BorderLayout.CENTER);
        tabbedPane.addTab("📋 Chi Tiết Lần Chấm", panelTabChiTiet);

        // --- Tab 2: Tổng hợp theo tháng (Có nút Xem Chi Tiết Từng Nhân Viên) ---
        JPanel panelTabTongHop = new JPanel(new BorderLayout(0, 8));
        panelTabTongHop.setOpaque(false);
        panelTabTongHop.setBorder(new EmptyBorder(5, 5, 5, 5));

        JPanel panelTongHopTop = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panelTongHopTop.setOpaque(false);
        btnChiTietNV = new JButton("👤 Xem Chi Tiết Nhân Viên (Lần chấm, Ngày, Tháng)");
        styleButton(btnChiTietNV, new Color(39, 174, 96));
        panelTongHopTop.add(btnChiTietNV);
        panelTabTongHop.add(panelTongHopTop, BorderLayout.NORTH);

        modelTongHop = new DefaultTableModel(new String[]{
                "Mã NV", "Họ Tên", "Công Chuẩn", "Công Thực Tế", "Đi Trễ", "Về Sớm", "Tăng Ca", "Nghỉ Phép", "Trạng Thái Gần Nhất"
        }, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tableTongHop = new JTable(modelTongHop);
        styleTable(tableTongHop);
        panelTabTongHop.add(new JScrollPane(tableTongHop), BorderLayout.CENTER);
        tabbedPane.addTab("📊 Tổng Hợp Tháng", panelTabTongHop);

        // --- Tab 3: Chấm Công Theo Ngày (In & Xuất Excel) ---
        JPanel panelTabTheoNgay = new JPanel(new BorderLayout(0, 8));
        panelTabTheoNgay.setOpaque(false);
        panelTabTheoNgay.setBorder(new EmptyBorder(5, 5, 5, 5));

        JPanel panelNgayFilter = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panelNgayFilter.setOpaque(false);
        panelNgayFilter.add(createLabel("Chọn ngày (YYYY-MM-DD):"));
        txtChonNgay = new JFormattedTextField(LocalDate.now().toString());
        txtChonNgay.setPreferredSize(new Dimension(120, 28));
        txtChonNgay.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        panelNgayFilter.add(txtChonNgay);

        btnXemNgay = new JButton("Xem Báo Cáo Ngày");
        styleButton(btnXemNgay, new Color(41, 128, 185));
        panelNgayFilter.add(btnXemNgay);

        btnInNgay = new JButton("🖨️ In Báo Cáo");
        styleButton(btnInNgay, new Color(39, 174, 96));
        panelNgayFilter.add(btnInNgay);

        btnXuatExcel = new JButton("📊 Xuất Excel (CSV)");
        styleButton(btnXuatExcel, new Color(230, 126, 34));
        panelNgayFilter.add(btnXuatExcel);

        panelTabTheoNgay.add(panelNgayFilter, BorderLayout.NORTH);

        modelTheoNgay = new DefaultTableModel(new String[]{
                "STT", "Mã NV", "Họ Tên", "Phòng Ban", "Thời Gian Điểm Danh", "Trạng Thái Trong Ngày"
        }, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tableTheoNgay = new JTable(modelTheoNgay);
        styleTable(tableTheoNgay);
        panelTabTheoNgay.add(new JScrollPane(tableTheoNgay), BorderLayout.CENTER);
        tabbedPane.addTab("📅 Chấm Công Theo Ngày", panelTabTheoNgay);

        add(tabbedPane, BorderLayout.CENTER);

        // Tải dữ liệu ban đầu
        loadDataChiTiet("");
        loadDataTongHop("");
        loadDataTheoNgay(LocalDate.now().toString());
        setThoiGianHienTai();

        // Sự kiện click bảng chi tiết lần chấm
        tableChiTiet.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = tableChiTiet.getSelectedRow();
                if (row >= 0) {
                    String idStr = modelChiTiet.getValueAt(row, 0).toString();
                    if (!idStr.startsWith("NP-")) {
                        txtMaNV.setText(modelChiTiet.getValueAt(row, 1).toString());
                        txtNgayGio.setText(modelChiTiet.getValueAt(row, 3).toString());
                        cbTrangThai.setSelectedItem(modelChiTiet.getValueAt(row, 4).toString());
                    }
                }
            }
        });

        // Double click vào bảng tổng hợp tháng để xem chi tiết nhân viên nhanh
        tableTongHop.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    hienThiChiTietNhanVien();
                }
            }
        });

        btnThem.addActionListener(e -> handleAdd());
        btnSua.addActionListener(e -> handleUpdate());
        btnXoa.addActionListener(e -> handleDelete());
        btnLamMoi.addActionListener(e -> {
            clearForm();
            loadDataChiTiet("");
            loadDataTongHop("");
            loadDataTheoNgay(LocalDate.now().toString());
        });
        btnTimKiem.addActionListener(e -> loadDataChiTiet(txtTimKiem.getText().trim()));
        btnThongKe.addActionListener(e -> loadDataTongHop(txtTimKiem.getText().trim()));
        btnXemNgay.addActionListener(e -> loadDataTheoNgay(txtChonNgay.getText().trim()));
        btnInNgay.addActionListener(e -> handlePrint());
        btnXuatExcel.addActionListener(e -> handleExportExcel());
        btnChiTietNV.addActionListener(e -> hienThiChiTietNhanVien());
    }

    private JLabel createLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        return lbl;
    }

    private void styleTextField(JTextField tf) {
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setPreferredSize(new Dimension(0, 28));
    }

    private void styleComboBox(JComboBox<String> cb) {
        cb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cb.setBackground(Color.WHITE);
        cb.setPreferredSize(new Dimension(0, 28));
    }

    private void styleButton(JButton btn, Color bgColor) {
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void styleTable(JTable table) {
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setPreferredSize(new Dimension(0, 32));

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setBackground(new Color(41, 128, 185));
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        headerRenderer.setFont(new Font("Segoe UI", Font.BOLD, 13));

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        for (int i = 0; i < table.getColumnCount(); i++) {
            String name = table.getColumnName(i);
            if (name.contains("ID") || name.contains("Mã") || name.contains("Thời Gian") || name.contains("STT") || name.contains("Chuẩn") || name.contains("Thực Tế") || name.contains("Trễ") || name.contains("Sớm") || name.contains("Ca") || name.contains("Phép") || name.contains("Ngày") || name.contains("Thứ")) {
                table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
            }
        }
    }

    private void setThoiGianHienTai() {
        txtNgayGio.setText(LocalDateTime.now().format(DATE_TIME_FORMATTER));
    }

    private void loadDataChiTiet(String keyword) {
        modelChiTiet.setRowCount(0);
        String sqlChamCong = "SELECT c.id, n.ma_nv, n.ho_ten, c.ngay_gio, c.trang_thai FROM cham_cong c JOIN nhan_vien n ON c.nhan_vien_id = n.id WHERE n.ma_nv LIKE ? OR n.ho_ten LIKE ?";
        String sqlNghiPhep = "SELECT np.id AS np_id, n.ma_nv, n.ho_ten, CONCAT(np.ngay_bat_dau, ' 08:00:00') AS ngay_gio, 'Đã nghỉ phép' AS trang_thai FROM nghi_phep np JOIN nhan_vien n ON np.nhan_vien_id = n.id WHERE np.trang_thai = 'Đã duyệt' AND (n.ma_nv LIKE ? OR n.ho_ten LIKE ?)";

        try (Connection conn = DatabaseConnection.getConnection()) {
            try (PreparedStatement ps = conn.prepareStatement(sqlChamCong)) {
                ps.setString(1, "%" + keyword + "%");
                ps.setString(2, "%" + keyword + "%");
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        modelChiTiet.addRow(new Object[]{rs.getInt("id"), rs.getString("ma_nv"), rs.getString("ho_ten"), rs.getString("ngay_gio"), rs.getString("trang_thai")});
                    }
                }
            }
            try (PreparedStatement psNp = conn.prepareStatement(sqlNghiPhep)) {
                psNp.setString(1, "%" + keyword + "%");
                psNp.setString(2, "%" + keyword + "%");
                try (ResultSet rs = psNp.executeQuery()) {
                    while (rs.next()) {
                        modelChiTiet.addRow(new Object[]{"NP-" + rs.getInt("np_id"), rs.getString("ma_nv"), rs.getString("ho_ten"), rs.getString("ngay_gio"), rs.getString("trang_thai")});
                    }
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void loadDataTongHop(String keyword) {
        modelTongHop.setRowCount(0);
        int thang = (int) cbThang.getSelectedItem();
        int nam = (int) cbNam.getSelectedItem();
        int congChuan = 26;

        String sql = "SELECT id, ma_nv, ho_ten FROM nhan_vien WHERE ma_nv LIKE ? OR ho_ten LIKE ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, "%" + keyword + "%");
            pstmt.setString(2, "%" + keyword + "%");
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    int nvId = rs.getInt("id");
                    int congThucTe = demSoLuongTrangThai(conn, nvId, thang, nam, "Đúng giờ") + demSoLuongTrangThai(conn, nvId, thang, nam, "Vào ca");
                    int diTre = demSoLuongTrangThai(conn, nvId, thang, nam, "Đi trễ");
                    int veSom = demSoLuongTrangThai(conn, nvId, thang, nam, "Về sớm");
                    int nghiPhep = demSoLuongNghiPhep(conn, nvId, thang, nam);
                    double tangCa = tinhTongGioTangCa(conn, nvId, thang, nam);
                    String trangThaiMoi = layTrangThaiMoiNhat(conn, nvId);

                    modelTongHop.addRow(new Object[]{rs.getString("ma_nv"), rs.getString("ho_ten"), congChuan, congThucTe + " ngày", diTre + " lần", veSom + " lần", tangCa + " giờ", nghiPhep + " ngày", trangThaiMoi});
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void loadDataTheoNgay(String ngayStr) {
        modelTheoNgay.setRowCount(0);
        String sql = "SELECT n.ma_nv, n.ho_ten, COALESCE(pb.ten_phong_ban, 'Chưa phân bổ') AS phong_ban, " +
                "COALESCE(c.ngay_gio, CONCAT(?, ' (Chưa chấm công)')) AS thoi_gian, " +
                "COALESCE(c.trang_thai, 'Vắng mặt') AS trang_thai " +
                "FROM nhan_vien n " +
                "LEFT JOIN phong_ban pb ON n.phong_ban_id = pb.id " +
                "LEFT JOIN cham_cong c ON n.id = c.nhan_vien_id AND DATE(c.ngay_gio) = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, ngayStr);
            pstmt.setString(2, ngayStr);
            try (ResultSet rs = pstmt.executeQuery()) {
                int stt = 1;
                while (rs.next()) {
                    modelTheoNgay.addRow(new Object[]{
                            stt++,
                            rs.getString("ma_nv"),
                            rs.getString("ho_ten"),
                            rs.getString("phong_ban"),
                            rs.getString("thoi_gian"),
                            rs.getString("trang_thai")
                    });
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    // --- Tính năng: Xem chi tiết từng nhân viên (Theo lần chấm, theo ngày, theo tháng) ---
    private void hienThiChiTietNhanVien() {
        int row = tableTongHop.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên trong bảng Tổng Hợp Tháng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String maNV = modelTongHop.getValueAt(row, 0).toString();
        String hoTen = modelTongHop.getValueAt(row, 1).toString();
        int thang = (int) cbThang.getSelectedItem();
        int nam = (int) cbNam.getSelectedItem();

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Chi Tiết Nhân Viên: " + hoTen + " (" + maNV + ") - Tháng " + thang + "/" + nam, true);
        dialog.setSize(850, 500);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.getRootPane().setBorder(new EmptyBorder(10, 10, 10, 10));

        JTabbedPane subTab = new JTabbedPane();
        subTab.setFont(new Font("Segoe UI", Font.BOLD, 12));

        // 1. Tab Chi tiết theo từng lần chấm trong tháng
        DefaultTableModel mLanCham = new DefaultTableModel(new String[]{"ID", "Thời Gian Chấm Công", "Trạng Thái"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tLanCham = new JTable(mLanCham);
        styleTable(tLanCham);

        // 2. Tab Chi tiết theo từng ngày trong tháng (Liệt kê từ ngày 1 đến hết tháng)
        DefaultTableModel mTheoNgayNV = new DefaultTableModel(new String[]{"Ngày", "Thứ", "Thời Gian Điểm Danh", "Trạng Thái Trong Ngày"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tTheoNgayNV = new JTable(mTheoNgayNV);
        styleTable(tTheoNgayNV);

        // 3. Tab Nghỉ phép & Tăng ca
        DefaultTableModel mNghiPhep = new DefaultTableModel(new String[]{"Từ Ngày", "Đến Ngày", "Lý Do", "Trạng Thái"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tNghiPhep = new JTable(mNghiPhep);
        styleTable(tNghiPhep);

        try (Connection conn = DatabaseConnection.getConnection()) {
            int nvId = -1;
            try (PreparedStatement ps = conn.prepareStatement("SELECT id FROM nhan_vien WHERE ma_nv = ?")) {
                ps.setString(1, maNV);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) nvId = rs.getInt("id");
                }
            }

            if (nvId != -1) {
                // Load dữ liệu theo từng lần chấm
                String sqlCC = "SELECT id, ngay_gio, trang_thai FROM cham_cong WHERE nhan_vien_id = ? AND MONTH(ngay_gio) = ? AND YEAR(ngay_gio) = ? ORDER BY ngay_gio DESC";
                try (PreparedStatement ps = conn.prepareStatement(sqlCC)) {
                    ps.setInt(1, nvId); ps.setInt(2, thang); ps.setInt(3, nam);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            mLanCham.addRow(new Object[]{rs.getInt("id"), rs.getString("ngay_gio"), rs.getString("trang_thai")});
                        }
                    }
                }

                // Load dữ liệu theo từng ngày trong tháng
                LocalDate firstDay = LocalDate.of(nam, thang, 1);
                LocalDate lastDay = firstDay.withDayOfMonth(firstDay.lengthOfMonth());

                String sqlDayCheck = "SELECT ngay_gio, trang_thai FROM cham_cong WHERE nhan_vien_id = ? AND DATE(ngay_gio) = ?";
                String sqlLeaveCheck = "SELECT trang_thai FROM nghi_phep WHERE nhan_vien_id = ? AND ? BETWEEN ngay_bat_dau AND ngay_ket_thuc AND trang_thai = 'Đã duyệt'";

                for (LocalDate date = firstDay; !date.isAfter(lastDay); date = date.plusDays(1)) {
                    String dateStr = date.toString();
                    String thuStr = date.getDayOfWeek().toString();
                    String thoiGianInfo = "Chưa chấm công";
                    String trangThaiInfo = "Vắng mặt";

                    try (PreparedStatement ps = conn.prepareStatement(sqlDayCheck)) {
                        ps.setInt(1, nvId);
                        ps.setString(2, dateStr);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (rs.next()) {
                                thoiGianInfo = rs.getString("ngay_gio");
                                trangThaiInfo = rs.getString("trang_thai");
                            }
                        }
                    }

                    if (trangThaiInfo.equals("Vắng mặt")) {
                        try (PreparedStatement ps = conn.prepareStatement(sqlLeaveCheck)) {
                            ps.setInt(1, nvId);
                            ps.setString(2, dateStr);
                            try (ResultSet rs = ps.executeQuery()) {
                                if (rs.next()) {
                                    trangThaiInfo = "Nghỉ phép (" + rs.getString("trang_thai") + ")";
                                    thoiGianInfo = "N/A";
                                }
                            }
                        }
                    }

                    mTheoNgayNV.addRow(new Object[]{dateStr, thuStr, thoiGianInfo, trangThaiInfo});
                }

                // Load dữ liệu nghỉ phép
                String sqlNP = "SELECT ngay_bat_dau, ngay_ket_thuc, ly_do, trang_thai FROM nghi_phep WHERE nhan_vien_id = ? AND (MONTH(ngay_bat_dau) = ? OR MONTH(ngay_ket_thuc) = ?)";
                try (PreparedStatement ps = conn.prepareStatement(sqlNP)) {
                    ps.setInt(1, nvId); ps.setInt(2, thang); ps.setInt(3, thang);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            mNghiPhep.addRow(new Object[]{rs.getDate("ngay_bat_dau"), rs.getDate("ngay_ket_thuc"), rs.getString("ly_do"), rs.getString("trang_thai")});
                        }
                    }
                }
            }
        } catch (Exception e) { e.printStackTrace(); }

        subTab.addTab("⚡ Theo Từng Lần Chấm", new JScrollPane(tLanCham));
        subTab.addTab("📅 Theo Từng Ngày Trong Tháng", new JScrollPane(tTheoNgayNV));
        subTab.addTab("🏖️ Nghỉ Phép & Thông Tin", new JScrollPane(tNghiPhep));

        dialog.add(subTab, BorderLayout.CENTER);

        JButton btnClose = new JButton("Đóng");
        styleButton(btnClose, new Color(127, 140, 141));
        btnClose.addActionListener(e -> dialog.dispose());
        JPanel panelBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBottom.setOpaque(false);
        panelBottom.add(btnClose);
        dialog.add(panelBottom, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }

    private int demSoLuongTrangThai(Connection conn, int nvId, int thang, int nam, String trangThai) {
        String sql = "SELECT COUNT(*) FROM cham_cong WHERE nhan_vien_id = ? AND MONTH(ngay_gio) = ? AND YEAR(ngay_gio) = ? AND trang_thai = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, nvId); ps.setInt(2, thang); ps.setInt(3, nam); ps.setString(4, trangThai);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) return rs.getInt(1); }
        } catch (SQLException e) {}
        return 0;
    }

    private int demSoLuongNghiPhep(Connection conn, int nvId, int thang, int nam) {
        String sql = "SELECT COUNT(*) FROM nghi_phep WHERE nhan_vien_id = ? AND trang_thai = 'Đã duyệt' AND (MONTH(ngay_bat_dau) = ? OR MONTH(ngay_ket_thuc) = ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, nvId); ps.setInt(2, thang); ps.setInt(3, thang);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) return rs.getInt(1); }
        } catch (SQLException e) {}
        return 0;
    }

    private double tinhTongGioTangCa(Connection conn, int nvId, int thang, int nam) {
        String sql = "SELECT COALESCE(SUM(so_gio), 0) FROM tang_ca WHERE nhan_vien_id = ? AND trang_thai = 'Đã duyệt' AND MONTH(ngay) = ? AND YEAR(ngay) = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, nvId); ps.setInt(2, thang); ps.setInt(3, nam);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) return rs.getDouble(1); }
        } catch (SQLException e) {}
        return 0.0;
    }

    private String layTrangThaiMoiNhat(Connection conn, int nvId) {
        String sql = "SELECT trang_thai FROM cham_cong WHERE nhan_vien_id = ? ORDER BY ngay_gio DESC LIMIT 1";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, nvId);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) return rs.getString(1); }
        } catch (SQLException e) {}
        return "Chưa có dữ liệu";
    }

    private void handleAdd() {
        String maNV = txtMaNV.getText().trim();
        String ngayGioStr = txtNgayGio.getText().trim();
        String trangThai = cbTrangThai.getSelectedItem().toString();

        if (maNV.isEmpty() || ngayGioStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập Mã NV và Thời gian!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            LocalDateTime.parse(ngayGioStr, DATE_TIME_FORMATTER);
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Định dạng thời gian không hợp lệ! Dạng chuẩn: YYYY-MM-DD HH:MM:SS", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {
            int nhanVienId = -1;
            try (PreparedStatement ps = conn.prepareStatement("SELECT id FROM nhan_vien WHERE ma_nv = ?")) {
                ps.setString(1, maNV);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) nhanVienId = rs.getInt("id");
                    else { JOptionPane.showMessageDialog(this, "Mã nhân viên không tồn tại!", "Lỗi", JOptionPane.ERROR_MESSAGE); return; }
                }
            }

            try (PreparedStatement pstmt = conn.prepareStatement("INSERT INTO cham_cong (nhan_vien_id, ngay_gio, trang_thai) VALUES (?, ?, ?)")) {
                pstmt.setInt(1, nhanVienId);
                pstmt.setString(2, ngayGioStr);
                pstmt.setString(3, trangThai);
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Thêm chấm công thành công!");
                loadDataChiTiet("");
                loadDataTongHop("");
                loadDataTheoNgay(txtChonNgay.getText().trim());
                clearForm();
            }
        } catch (Exception ex) { ex.printStackTrace(); }
    }

    private void handleUpdate() {
        int row = tableChiTiet.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Chọn bản ghi cần sửa trên tab 'Chi Tiết'!", "Cảnh báo", JOptionPane.WARNING_MESSAGE); return; }
        String idStr = modelChiTiet.getValueAt(row, 0).toString();
        if (idStr.startsWith("NP-")) { JOptionPane.showMessageDialog(this, "Không thể sửa lịch nghỉ phép!", "Cảnh báo", JOptionPane.WARNING_MESSAGE); return; }

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE cham_cong SET ngay_gio = ?, trang_thai = ? WHERE id = ?")) {
            pstmt.setString(1, txtNgayGio.getText().trim());
            pstmt.setString(2, cbTrangThai.getSelectedItem().toString());
            pstmt.setInt(3, Integer.parseInt(idStr));
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Cập nhật thành công!");
            loadDataChiTiet("");
            loadDataTongHop("");
            loadDataTheoNgay(txtChonNgay.getText().trim());
            clearForm();
        } catch (Exception ex) { ex.printStackTrace(); }
    }

    private void handleDelete() {
        int row = tableChiTiet.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Chọn bản ghi cần xóa trên tab 'Chi Tiết'!", "Cảnh báo", JOptionPane.WARNING_MESSAGE); return; }
        String idStr = modelChiTiet.getValueAt(row, 0).toString();
        if (idStr.startsWith("NP-")) { JOptionPane.showMessageDialog(this, "Không thể xóa lịch nghỉ phép!", "Cảnh báo", JOptionPane.WARNING_MESSAGE); return; }

        if (JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa?", "Xác nhận", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement("DELETE FROM cham_cong WHERE id = ?")) {
                pstmt.setInt(1, Integer.parseInt(idStr));
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Xóa thành công!");
                loadDataChiTiet("");
                loadDataTongHop("");
                loadDataTheoNgay(txtChonNgay.getText().trim());
                clearForm();
            } catch (Exception ex) { ex.printStackTrace(); }
        }
    }

    private void handlePrint() {
        try {
            boolean complete = tableTheoNgay.print(JTable.PrintMode.FIT_WIDTH,
                    new java.text.MessageFormat("BÁO CÁO CHẤM CÔNG NGÀY: " + txtChonNgay.getText().trim()),
                    new java.text.MessageFormat("Trang - {0}"));
            if (complete) {
                JOptionPane.showMessageDialog(this, "In báo cáo thành công!");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi in: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleExportExcel() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Lưu file Excel (CSV)");
        fileChooser.setSelectedFile(new File("ChamCong_" + txtChonNgay.getText().trim() + ".csv"));
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (FileWriter fw = new FileWriter(file, java.nio.charset.StandardCharsets.UTF_8)) {
                for (int i = 0; i < modelTheoNgay.getColumnCount(); i++) {
                    fw.write("\"" + modelTheoNgay.getColumnName(i) + "\"" + (i == modelTheoNgay.getColumnCount() - 1 ? "" : ","));
                }
                fw.write("\n");
                for (int r = 0; r < modelTheoNgay.getRowCount(); r++) {
                    for (int c = 0; c < modelTheoNgay.getColumnCount(); c++) {
                        Object val = modelTheoNgay.getValueAt(r, c);
                        fw.write("\"" + (val != null ? val.toString() : "") + "\"" + (c == modelTheoNgay.getColumnCount() - 1 ? "" : ","));
                    }
                    fw.write("\n");
                }
                JOptionPane.showMessageDialog(this, "Xuất file thành công tới:\n" + file.getAbsolutePath());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Lỗi xuất file: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void clearForm() {
        txtMaNV.setText("");
        setThoiGianHienTai();
        cbTrangThai.setSelectedIndex(0);
        txtTimKiem.setText("");
        tableChiTiet.clearSelection();
    }
}