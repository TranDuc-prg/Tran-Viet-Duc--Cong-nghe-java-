package vn.edu.eaut.view;

import vn.edu.eaut.connection.DatabaseConnection;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;

public class ChucVuFrame extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField txtMaChucVu, txtTenChucVu, txtPhuCap, txtMoTa;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi;
    private DecimalFormat currencyFormat = new DecimalFormat("#,###");

    public ChucVuFrame() {
        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(new Color(245, 247, 250));

        // Tiêu đề
        JLabel lblHeader = new JLabel("QUẢN LÝ THÔNG TIN CHỨC VỤ", JLabel.CENTER);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblHeader.setForeground(new Color(41, 128, 185));
        lblHeader.setBorder(new EmptyBorder(0, 0, 5, 0));
        add(lblHeader, BorderLayout.NORTH);

        // --- 1. Form nhập liệu bên trái (350px) ---
        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setBackground(Color.WHITE);
        panelForm.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(200, 200, 200)),
                        " Thông tin chức vụ ",
                        0, 0, new Font("Segoe UI", Font.BOLD, 13), new Color(41, 128, 185)
                ),
                new EmptyBorder(10, 10, 10, 10)
        ));
        panelForm.setPreferredSize(new Dimension(350, 0));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 8, 10, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        panelForm.add(createLabel("Mã Chức Vụ:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtMaChucVu = new JTextField(); styleTextField(txtMaChucVu);
        panelForm.add(txtMaChucVu, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        panelForm.add(createLabel("Tên Chức Vụ:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtTenChucVu = new JTextField(); styleTextField(txtTenChucVu);
        panelForm.add(txtTenChucVu, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0;
        panelForm.add(createLabel("Mức Phụ Cấp (VNĐ):"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtPhuCap = new JTextField(); styleTextField(txtPhuCap);
        panelForm.add(txtPhuCap, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0;
        panelForm.add(createLabel("Mô Tả:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtMoTa = new JTextField(); styleTextField(txtMoTa);
        panelForm.add(txtMoTa, gbc);

        // Panel chứa 4 nút bấm chuẩn màu
        JPanel panelButtons = new JPanel(new GridLayout(2, 2, 10, 10));
        panelButtons.setBackground(Color.WHITE);

        btnThem = new JButton("Thêm mới");
        btnSua = new JButton("Cập nhật");
        btnXoa = new JButton("Xóa bỏ");
        btnLamMoi = new JButton("Làm mới");

        styleButton(btnThem, new Color(46, 204, 113));
        styleButton(btnSua, new Color(230, 126, 34));
        styleButton(btnXoa, new Color(231, 76, 60));
        styleButton(btnLamMoi, new Color(52, 152, 219));

        panelButtons.add(btnThem);
        panelButtons.add(btnSua);
        panelButtons.add(btnXoa);
        panelButtons.add(btnLamMoi);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 8, 8, 8);
        panelForm.add(panelButtons, gbc);

        // Dồn bố cục lên phía trên
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2; gbc.weighty = 1.0;
        panelForm.add(new JLabel(""), gbc);

        add(panelForm, BorderLayout.WEST);

        // --- 2. Bảng hiển thị bên phải ---
        tableModel = new DefaultTableModel(new String[]{"ID", "Mã Chức Vụ", "Tên Chức Vụ", "Mức Phụ Cấp", "Mô Tả"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        // Cấu hình Header chữ trắng nền xanh nổi bật
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setPreferredSize(new Dimension(0, 30));

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setBackground(new Color(41, 128, 185));
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        headerRenderer.setFont(new Font("Segoe UI", Font.BOLD, 13));

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }

        // Định dạng căn lề các cột
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);

        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(1).setPreferredWidth(90);
        table.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(3).setCellRenderer(rightRenderer); // Phụ cấp căn phải

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                " Danh sách chức vụ hệ thống ",
                0, 0, new Font("Segoe UI", Font.BOLD, 13), new Color(41, 128, 185)
        ));
        add(scrollPane, BorderLayout.CENTER);

        loadData();

        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    txtMaChucVu.setText(tableModel.getValueAt(row, 1).toString());
                    txtTenChucVu.setText(tableModel.getValueAt(row, 2).toString());

                    String rawPhuCap = tableModel.getValueAt(row, 3).toString().replace(" VNĐ", "").replace(",", "").trim();
                    txtPhuCap.setText(rawPhuCap);
                    txtMoTa.setText(tableModel.getValueAt(row, 4) != null ? tableModel.getValueAt(row, 4).toString() : "");
                    txtMaChucVu.setEditable(false);
                }
            }
        });

        btnThem.addActionListener(e -> handleAdd());
        btnSua.addActionListener(e -> handleUpdate());
        btnXoa.addActionListener(e -> handleDelete());
        btnLamMoi.addActionListener(e -> clearForm());
    }

    private JLabel createLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        return lbl;
    }

    private void styleTextField(JTextField tf) {
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setPreferredSize(new Dimension(0, 28));
    }

    private void styleButton(JButton btn, Color bgColor) {
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    public void loadData() {
        tableModel.setRowCount(0);
        String sql = "SELECT * FROM chuc_vu";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                double phuCap = rs.getDouble("muc_phu_cap");
                Object[] row = {
                        rs.getInt("id"),
                        rs.getString("ma_chuc_vu"),
                        rs.getString("ten_chuc_vu"),
                        currencyFormat.format(phuCap) + " VNĐ",
                        rs.getString("mo_ta")
                };
                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void handleAdd() {
        String ma = txtMaChucVu.getText().trim();
        String ten = txtTenChucVu.getText().trim();
        String phuCapStr = txtPhuCap.getText().trim();

        if (ma.isEmpty() || ten.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập Mã và Tên chức vụ!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO chuc_vu (ma_chuc_vu, ten_chuc_vu, muc_phu_cap, mo_ta) VALUES (?, ?, ?, ?)")) {
            pstmt.setString(1, ma);
            pstmt.setString(2, ten);
            pstmt.setDouble(3, phuCapStr.isEmpty() ? 0 : Double.parseDouble(phuCapStr));
            pstmt.setString(4, txtMoTa.getText().trim());
            pstmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Thêm chức vụ thành công!");
            loadData();
            clearForm();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi thêm dữ liệu! Kiểm tra xem mã chức vụ có bị trùng không.", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleUpdate() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn chức vụ cần sửa trên bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = Integer.parseInt(tableModel.getValueAt(row, 0).toString());

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE chuc_vu SET ten_chuc_vu = ?, muc_phu_cap = ?, mo_ta = ? WHERE id = ?")) {
            pstmt.setString(1, txtTenChucVu.getText().trim());
            pstmt.setDouble(2, txtPhuCap.getText().trim().isEmpty() ? 0 : Double.parseDouble(txtPhuCap.getText().trim()));
            pstmt.setString(3, txtMoTa.getText().trim());
            pstmt.setInt(4, id);
            pstmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Cập nhật chức vụ thành công!");
            loadData();
            clearForm();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi cập nhật dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleDelete() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn chức vụ cần xóa trên bảng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = Integer.parseInt(tableModel.getValueAt(row, 0).toString());
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa chức vụ này?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement("DELETE FROM chuc_vu WHERE id = ?")) {
                pstmt.setInt(1, id);
                pstmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Xóa chức vụ thành công!");
                loadData();
                clearForm();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private void clearForm() {
        txtMaChucVu.setText("");
        txtTenChucVu.setText("");
        txtPhuCap.setText("");
        txtMoTa.setText("");
        txtMaChucVu.setEditable(true);
        table.clearSelection();
    }
}