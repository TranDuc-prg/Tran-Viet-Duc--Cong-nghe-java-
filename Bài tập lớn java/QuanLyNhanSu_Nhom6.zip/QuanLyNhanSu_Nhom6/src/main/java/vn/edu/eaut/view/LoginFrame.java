        package vn.edu.eaut.view;

import vn.edu.eaut.model.UserSession;
import vn.edu.eaut.dao.NhanVienDAO;
import vn.edu.eaut.service.NhanVienService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.prefs.Preferences;

public class LoginFrame extends JFrame {



    private static final Color MINT = new Color(16, 185, 129);
    private static final Color MINT_DARK = new Color(5, 150, 105);
    private static final Color MINT_LIGHT = new Color(236, 253, 245);

    private static final Color NAVY = new Color(15, 23, 42);
    private static final Color NAVY_CARD = new Color(30, 41, 59);

    private static final Color BACKGROUND = new Color(241, 245, 249);
    private static final Color CARD = Color.WHITE;

    private static final Color TEXT = new Color(15, 23, 42);
    private static final Color TEXT_LIGHT = new Color(100, 116, 139);

    private static final Color BORDER = new Color(226, 232, 240);

    // ==============================
    // COMPONENTS
    // ==============================

    private JTextField txtUsername;
    private JPasswordField txtPassword;

    private JButton btnLogin;
    private JButton btnRegister;

    private JCheckBox chkShowPassword;
    private JCheckBox chkRememberMe;

    private final Preferences prefs =
            Preferences.userNodeForPackage(LoginFrame.class);



    public LoginFrame() {

        setTitle("Đăng nhập | Hệ thống quản lý nhân sự");
        setSize(980, 580);
        setMinimumSize(new Dimension(900, 540));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BACKGROUND);
        setContentPane(root);

        root.add(createLeftPanel(), BorderLayout.WEST);
        root.add(createRightPanel(), BorderLayout.CENTER);

        getRootPane().setDefaultButton(btnLogin);


        btnLogin.addActionListener(e -> handleLogin());



        btnRegister.addActionListener(e -> {
            new RegisterFrame().setVisible(true);
            dispose();
        });


        chkShowPassword.addActionListener(e -> {

            if (chkShowPassword.isSelected()) {
                txtPassword.setEchoChar((char) 0);
            } else {
                txtPassword.setEchoChar('•');
            }
        });

        loadSavedCredentials();

        SwingUtilities.invokeLater(() -> {

            if (txtUsername.getText() != null
                    && !txtUsername.getText().trim().isEmpty()) {

                txtPassword.requestFocusInWindow();

            } else {

                txtUsername.requestFocusInWindow();
            }
        });
    }



    private JPanel createLeftPanel() {

        JPanel panel = new JPanel();

        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(NAVY);
        panel.setBorder(new EmptyBorder(40, 40, 35, 35));
        panel.setPreferredSize(new Dimension(380, 580));

        // LOGO
        JPanel logoPanel = new JPanel(new GridBagLayout());

        logoPanel.setBackground(NAVY_CARD);
        logoPanel.setPreferredSize(new Dimension(56, 56));
        logoPanel.setMaximumSize(new Dimension(56, 56));
        logoPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        logoPanel.setBorder(
                new LineBorder(
                        new Color(51, 65, 85),
                        1,
                        true
                )
        );

        JLabel logo = new JLabel("EAUT");

        logo.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        16
                )
        );

        logo.setForeground(MINT);

        logoPanel.add(logo);

        panel.add(logoPanel);

        panel.add(Box.createVerticalStrut(25));

        // TITLE
        JLabel hello =
                new JLabel("HỆ THỐNG QUẢN LÝ NHÂN SỰ");

        hello.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        11
                )
        );

        hello.setForeground(
                new Color(110, 231, 183)
        );

        hello.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(hello);

        panel.add(Box.createVerticalStrut(8));

        JLabel title =
                new JLabel(
                        "<html>"
                                + "Chào mừng bạn<br>"
                                + "quay trở lại!"
                                + "</html>"
                );

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        24
                )
        );

        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(title);

        panel.add(Box.createVerticalStrut(12));

        JLabel description =
                new JLabel(
                        "<html>"
                                + "Nền tảng quản trị nhân sự tập trung,<br>"
                                + "chính xác và bảo mật hàng đầu."
                                + "</html>"
                );

        description.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        12
                )
        );

        description.setForeground(
                new Color(148, 163, 184)
        );

        description.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(description);

        panel.add(Box.createVerticalStrut(25));

        panel.add(
                createFeature(
                        "01",
                        "Quản lý thông tin nhân sự"
                )
        );

        panel.add(Box.createVerticalStrut(8));

        panel.add(
                createFeature(
                        "02",
                        "Phòng ban & cơ cấu tổ chức"
                )
        );

        panel.add(Box.createVerticalStrut(8));

        panel.add(
                createFeature(
                        "03",
                        "Hợp đồng & chấm công tự động"
                )
        );

        panel.add(Box.createVerticalStrut(8));

        panel.add(
                createFeature(
                        "04",
                        "Tính lương & bảng kê chi tiết"
                )
        );

        panel.add(Box.createVerticalGlue());

        JLabel footer =
                new JLabel(
                        "© 2026 EAUT • HRM System"
                );

        footer.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        10
                )
        );

        footer.setForeground(
                new Color(100, 116, 139)
        );

        footer.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(footer);

        return panel;
    }

    // =========================================================
    // FEATURE
    // =========================================================

    private JPanel createFeature(
            String number,
            String text
    ) {

        JPanel panel =
                new JPanel(
                        new BorderLayout(10, 0)
                );

        panel.setOpaque(false);
        panel.setMaximumSize(
                new Dimension(305, 28)
        );

        panel.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        JLabel numberLabel =
                new JLabel(
                        number,
                        SwingConstants.CENTER
                );

        numberLabel.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        10
                )
        );

        numberLabel.setForeground(MINT);

        numberLabel.setBackground(
                new Color(30, 41, 59)
        );

        numberLabel.setOpaque(true);

        numberLabel.setBorder(
                new LineBorder(
                        new Color(51, 65, 85),
                        1,
                        true
                )
        );

        numberLabel.setPreferredSize(
                new Dimension(26, 24)
        );

        JLabel textLabel =
                new JLabel(text);

        textLabel.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        11
                )
        );

        textLabel.setForeground(
                new Color(203, 213, 225)
        );

        panel.add(
                numberLabel,
                BorderLayout.WEST
        );

        panel.add(
                textLabel,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =========================================================
    // RIGHT PANEL
    // =========================================================

    private JPanel createRightPanel() {

        JPanel background =
                new JPanel(
                        new GridBagLayout()
                );

        background.setBackground(
                BACKGROUND
        );

        background.setBorder(
                new EmptyBorder(
                        20,
                        30,
                        20,
                        30
                )
        );

        CleanCardPanel card =
                new CleanCardPanel(
                        CARD,
                        16,
                        new Color(203, 213, 225)
                );

        card.setLayout(
                new BoxLayout(
                        card,
                        BoxLayout.Y_AXIS
                )
        );

        card.setBorder(
                new EmptyBorder(
                        30,
                        35,
                        25,
                        35
                )
        );

        card.setPreferredSize(
                new Dimension(420, 495)
        );

        JLabel title =
                new JLabel(
                        "Đăng nhập hệ thống"
                );

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        22
                )
        );

        title.setForeground(TEXT);
        title.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        card.add(title);

        card.add(
                Box.createVerticalStrut(4)
        );

        JLabel subtitle =
                new JLabel(
                        "Nhập thông tin tài khoản của bạn để tiếp tục"
                );

        subtitle.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        12
                )
        );

        subtitle.setForeground(
                TEXT_LIGHT
        );

        subtitle.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        card.add(subtitle);

        card.add(
                Box.createVerticalStrut(18)
        );

        // USERNAME

        card.add(
                createLabel("TÀI KHOẢN")
        );

        card.add(
                Box.createVerticalStrut(4)
        );

        txtUsername =
                createTextField();

        card.add(txtUsername);

        // PASSWORD

        card.add(
                Box.createVerticalStrut(12)
        );

        card.add(
                createLabel("MẬT KHẨU")
        );

        card.add(
                Box.createVerticalStrut(4)
        );

        txtPassword =
                createPasswordField();

        card.add(txtPassword);

        card.add(
                Box.createVerticalStrut(8)
        );

        // OPTIONS

        JPanel optionsPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.LEFT,
                                0,
                                0
                        )
                );

        optionsPanel.setBackground(
                Color.WHITE
        );

        optionsPanel.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        optionsPanel.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        22
                )
        );

        chkShowPassword =
                new JCheckBox(
                        "Hiện mật khẩu"
                );

        chkShowPassword.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        11
                )
        );

        chkShowPassword.setForeground(
                TEXT_LIGHT
        );

        chkShowPassword.setBackground(
                Color.WHITE
        );

        chkShowPassword.setFocusPainted(false);

        chkRememberMe =
                new JCheckBox(
                        "Nhớ tài khoản"
                );

        chkRememberMe.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        11
                )
        );

        chkRememberMe.setForeground(
                TEXT_LIGHT
        );

        chkRememberMe.setBackground(
                Color.WHITE
        );

        chkRememberMe.setFocusPainted(false);

        chkRememberMe.setBorder(
                BorderFactory.createEmptyBorder(
                        0,
                        15,
                        0,
                        0
                )
        );

        optionsPanel.add(
                chkShowPassword
        );

        optionsPanel.add(
                chkRememberMe
        );

        card.add(optionsPanel);

        card.add(
                Box.createVerticalStrut(16)
        );

        // LOGIN BUTTON

        btnLogin =
                createPrimaryButton(
                        "ĐĂNG NHẬP"
                );

        card.add(btnLogin);

        card.add(
                Box.createVerticalStrut(8)
        );

        // REGISTER BUTTON

        btnRegister =
                createSecondaryButton(
                        "TẠO TÀI KHOẢN MỚI"
                );

        card.add(btnRegister);

        card.add(
                Box.createVerticalGlue()
        );

        background.add(card);

        return background;
    }

    // =========================================================
    // LABEL
    // =========================================================

    private JLabel createLabel(
            String text
    ) {

        JLabel label =
                new JLabel(text);

        label.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        10
                )
        );

        label.setForeground(
                new Color(71, 85, 105)
        );

        label.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        return label;
    }

    // =========================================================
    // TEXT FIELD
    // =========================================================

    private JTextField createTextField() {

        JTextField field =
                new JTextField();

        field.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        13
                )
        );

        field.setForeground(TEXT);

        field.setBackground(
                new Color(248, 250, 252)
        );

        field.setCaretColor(
                MINT_DARK
        );

        field.setBorder(
                new LineBorder(
                        BORDER,
                        1,
                        true
                )
        );

        field.setPreferredSize(
                new Dimension(350, 38)
        );

        field.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        38
                )
        );

        field.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        addFocusEffect(field);

        return field;
    }

    // =========================================================
    // PASSWORD FIELD
    // =========================================================

    private JPasswordField createPasswordField() {

        JPasswordField field =
                new JPasswordField();

        field.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        13
                )
        );

        field.setForeground(TEXT);

        field.setBackground(
                new Color(248, 250, 252)
        );

        field.setCaretColor(
                MINT_DARK
        );

        field.setEchoChar('•');

        field.setBorder(
                new LineBorder(
                        BORDER,
                        1,
                        true
                )
        );

        field.setPreferredSize(
                new Dimension(350, 38)
        );

        field.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        38
                )
        );

        field.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        addFocusEffect(field);

        return field;
    }

    // =========================================================
    // FOCUS EFFECT
    // =========================================================

    private void addFocusEffect(
            JComponent component
    ) {

        component.addFocusListener(
                new FocusAdapter() {

                    @Override
                    public void focusGained(
                            FocusEvent e
                    ) {

                        component.setBorder(
                                new LineBorder(
                                        MINT,
                                        2,
                                        true
                                )
                        );

                        component.setBackground(
                                Color.WHITE
                        );
                    }

                    @Override
                    public void focusLost(
                            FocusEvent e
                    ) {

                        component.setBorder(
                                new LineBorder(
                                        BORDER,
                                        1,
                                        true
                                )
                        );

                        component.setBackground(
                                new Color(
                                        248,
                                        250,
                                        252
                                )
                        );
                    }
                }
        );
    }

    // =========================================================
    // PRIMARY BUTTON
    // =========================================================

    private JButton createPrimaryButton(
            String text
    ) {

        JButton button =
                new JButton(text);

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                MINT_DARK
        );

        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);

        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        button.setPreferredSize(
                new Dimension(350, 38)
        );

        button.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        38
                )
        );

        button.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        button.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    @Override
                    public void mouseEntered(
                            java.awt.event.MouseEvent e
                    ) {

                        button.setBackground(MINT);
                    }

                    @Override
                    public void mouseExited(
                            java.awt.event.MouseEvent e
                    ) {

                        button.setBackground(
                                MINT_DARK
                        );
                    }
                }
        );

        return button;
    }

    // =========================================================
    // SECONDARY BUTTON
    // =========================================================

    private JButton createSecondaryButton(
            String text
    ) {

        JButton button =
                new JButton(text);

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        11
                )
        );

        button.setForeground(
                MINT_DARK
        );

        button.setBackground(
                Color.WHITE
        );

        button.setFocusPainted(false);
        button.setOpaque(true);

        button.setBorder(
                new LineBorder(
                        new Color(
                                209,
                                250,
                                229
                        ),
                        1,
                        true
                )
        );

        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        button.setPreferredSize(
                new Dimension(350, 36)
        );

        button.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        36
                )
        );

        button.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        button.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    @Override
                    public void mouseEntered(
                            java.awt.event.MouseEvent e
                    ) {

                        button.setBackground(
                                MINT_LIGHT
                        );
                    }

                    @Override
                    public void mouseExited(
                            java.awt.event.MouseEvent e
                    ) {

                        button.setBackground(
                                Color.WHITE
                        );
                    }
                }
        );

        return button;
    }

    // =========================================================
    // REMEMBER LOGIN
    // =========================================================

    private void loadSavedCredentials() {

        boolean remember =
                prefs.getBoolean(
                        "REMEMBER_ME",
                        false
                );

        if (remember) {

            String savedUser =
                    prefs.get(
                            "PREF_USERNAME",
                            ""
                    );

            String savedPass =
                    prefs.get(
                            "PREF_PASSWORD",
                            ""
                    );

            txtUsername.setText(
                    savedUser
            );

            txtPassword.setText(
                    savedPass
            );

            chkRememberMe.setSelected(
                    true
            );
        }
    }

    private void handleRememberMe(
            String username,
            String password
    ) {

        if (chkRememberMe.isSelected()) {

            prefs.putBoolean(
                    "REMEMBER_ME",
                    true
            );

            prefs.put(
                    "PREF_USERNAME",
                    username
            );

            prefs.put(
                    "PREF_PASSWORD",
                    password
            );

        } else {

            prefs.remove(
                    "REMEMBER_ME"
            );

            prefs.remove(
                    "PREF_USERNAME"
            );

            prefs.remove(
                    "PREF_PASSWORD"
            );
        }
    }

    // =========================================================
    // HANDLE LOGIN
    // =========================================================

    private void handleLogin() {

        String username =
                txtUsername.getText().trim();

        String password =
                new String(
                        txtPassword.getPassword()
                ).trim();

        // KIỂM TRA TRỐNG

        if (username.isEmpty()
                || password.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng nhập đầy đủ "
                            + "tài khoản và mật khẩu!",
                    "Thiếu thông tin",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        try {

            NhanVienService nhanVienService =
                    new NhanVienService();

            String role =
                    nhanVienService.login(
                            username,
                            password
                    );

            // =================================================
            // ĐĂNG NHẬP THÀNH CÔNG
            // =================================================

            if (role != null) {

                role =
                        role.trim()
                                .toUpperCase();

                // =============================================
                // CHUẨN HÓA ROLE CŨ
                // =============================================

                switch (role) {

                    case "HR":
                    case "NHANSU":
                    case "MANAGER":
                    case "QUẢN LÝ":
                    case "QUAN_LY":

                        role = "QUAN_LY";

                        break;

                    case "USER":
                    case "EMPLOYEE":
                    case "NHANVIEN":
                    case "NHÂN VIÊN":
                    case "NHAN_VIEN":

                        role = "NHAN_VIEN";

                        break;

                    case "ADMIN":

                        role = "ADMIN";

                        break;

                    case "KETOAN":

                        role = "KETOAN";

                        break;

                    default:

                        JOptionPane.showMessageDialog(
                                this,
                                "Vai trò tài khoản "
                                        + "không hợp lệ: "
                                        + role,
                                "Lỗi phân quyền",
                                JOptionPane.ERROR_MESSAGE
                        );

                        return;
                }

                // =============================================
                // LƯU SESSION
                // =============================================

                UserSession.login(
                        username,
                        username,
                        role
                );

                handleRememberMe(
                        username,
                        password
                );

                // =============================================
                // AUDIT LOG
                // =============================================

                try {

                    vn.edu.eaut.dao.AuditLogDAO.log(
                            username,
                            "LOGIN",
                            "TaiKhoan",
                            "Đăng nhập hệ thống "
                                    + "thành công với quyền "
                                    + role
                    );

                } catch (Exception logEx) {

                    logEx.printStackTrace();
                }

                // =============================================
                // HIỂN THỊ THÔNG BÁO
                // =============================================

                JOptionPane.showMessageDialog(
                        this,
                        "Đăng nhập thành công!\n\n"
                                + "Tài khoản: "
                                + username
                                + "\nQuyền: "
                                + getRoleDisplayName(role),
                        "Chào mừng bạn!",
                        JOptionPane.INFORMATION_MESSAGE
                );

                // =============================================
                // PHÂN QUYỀN
                // =============================================

                switch (role) {

                    // -----------------------------------------
                    // ADMIN
                    // -----------------------------------------

                    case "ADMIN":

                        new AdminMainFrame()
                                .setVisible(true);

                        break;

                    // -----------------------------------------
                    // QUẢN LÝ
                    // -----------------------------------------

                    case "QUAN_LY":

                        new NhanSuMainFrame()
                                .setVisible(true);

                        break;

                    // -----------------------------------------
                    // KẾ TOÁN
                    // -----------------------------------------

                    case "KETOAN":

                        new KeToanMainFrame()
                                .setVisible(true);

                        break;


                    case "NHAN_VIEN":

                        // Không được dùng ID cố định = 1.
                        // Phải lấy đúng ID nhân viên theo tài khoản đang đăng nhập.
                        int nhanVienId = new NhanVienDAO().getNhanVienIdByUsername(username);

                        if (nhanVienId <= 0) {
                            JOptionPane.showMessageDialog(
                                    this,
                                    "Tài khoản này chưa được liên kết với nhân viên.\n\n" +
                                            "Hãy đặt Tên đăng nhập trùng với Mã nhân viên (ví dụ: NV001),\n" +
                                            "hoặc cập nhật thông tin email/số điện thoại của nhân viên.",
                                    "Không tìm thấy nhân viên",
                                    JOptionPane.WARNING_MESSAGE
                            );
                            UserSession.logout();
                            return;
                        }

                        new NhanVienPortalFrame(nhanVienId).setVisible(true);

                        break;

                    default:

                        JOptionPane.showMessageDialog(
                                this,
                                "Không xác định được "
                                        + "quyền truy cập!",
                                "Lỗi phân quyền",
                                JOptionPane.ERROR_MESSAGE
                        );

                        UserSession.logout();

                        return;
                }

                dispose();

            } else {

                // =================================================
                // ĐĂNG NHẬP THẤT BẠI
                // =================================================

                try {

                    vn.edu.eaut.dao.AuditLogDAO.log(
                            username,
                            "LOGIN_FAILED",
                            "TaiKhoan",
                            "Đăng nhập thất bại "
                                    + "(Sai tài khoản hoặc mật khẩu)"
                    );

                } catch (Exception ignored) {
                }

                JOptionPane.showMessageDialog(
                        this,
                        "Tài khoản hoặc mật khẩu không đúng.\n"
                                + "Hoặc tài khoản hiện không hoạt động.",
                        "Đăng nhập thất bại",
                        JOptionPane.ERROR_MESSAGE
                );

                txtPassword.setText("");

                txtPassword.requestFocus();
            }

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Thiếu thông tin",
                    JOptionPane.WARNING_MESSAGE
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Không thể kết nối đến hệ thống.\n\n"
                            + "Chi tiết:\n"
                            + ex.getMessage(),
                    "Lỗi hệ thống",
                    JOptionPane.ERROR_MESSAGE
            );

            ex.printStackTrace();
        }
    }

    // =========================================================
    // ROLE DISPLAY NAME
    // =========================================================

    private String getRoleDisplayName(
            String role
    ) {

        switch (role) {

            case "ADMIN":

                return "ADMIN - Quản trị viên";

            case "QUAN_LY":

                return "QUẢN LÝ - Quản lý nhân sự";

            case "KETOAN":

                return "KẾ TOÁN - Phòng kế toán";

            case "NHAN_VIEN":

                return "NHÂN VIÊN";

            default:

                return role;
        }
    }

    // =========================================================
    // CLEAN CARD PANEL
    // =========================================================

    private static class CleanCardPanel
            extends JPanel {

        private final Color backgroundColor;
        private final int radius;
        private final Color borderColor;

        public CleanCardPanel(
                Color backgroundColor,
                int radius,
                Color borderColor
        ) {

            this.backgroundColor =
                    backgroundColor;

            this.radius = radius;

            this.borderColor =
                    borderColor;

            setOpaque(false);
        }

        @Override
        protected void paintComponent(
                Graphics g
        ) {

            Graphics2D g2 =
                    (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setColor(
                    backgroundColor
            );

            g2.fill(
                    new RoundRectangle2D.Double(
                            0,
                            0,
                            getWidth() - 1,
                            getHeight() - 1,
                            radius,
                            radius
                    )
            );

            g2.setColor(
                    borderColor
            );

            g2.draw(
                    new RoundRectangle2D.Double(
                            0,
                            0,
                            getWidth() - 1,
                            getHeight() - 1,
                            radius,
                            radius
                    )
            );

            g2.dispose();

            super.paintComponent(g);
        }
    }

    // =========================================================
    // MAIN
    // =========================================================

    public static void main(
            String[] args
    ) {

        try {

            UIManager.setLookAndFeel(
                    UIManager
                            .getSystemLookAndFeelClassName()
            );

        } catch (Exception ignored) {
        }

        SwingUtilities.invokeLater(
                () -> {

                    LoginFrame frame =
                            new LoginFrame();

                    frame.setVisible(true);
                }
        );
    }
}
