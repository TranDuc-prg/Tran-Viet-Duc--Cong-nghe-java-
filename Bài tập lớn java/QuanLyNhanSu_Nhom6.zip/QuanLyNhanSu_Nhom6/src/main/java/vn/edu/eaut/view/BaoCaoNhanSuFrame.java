package vn.edu.eaut.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.text.SimpleDateFormat;
import java.util.Date;

import vn.edu.eaut.dao.BaoCaoDAO;
import vn.edu.eaut.model.NhanVienBaoCaoDTO;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * BÁO CÁO NHÂN SỰ
 *
 * Giao diện báo cáo tổng hợp (Đồng bộ dữ liệu động 100%):
 * - KPI tổng quan
 * - Cơ cấu giới tính
 * - Tình trạng nhân sự
 * - Thống kê theo phòng ban
 * - Phân bố độ tuổi
 * - Tuyển dụng theo tháng
 * - Danh sách nhân viên
 */
public class BaoCaoNhanSuFrame extends JPanel {

    // =========================================================
    // MÀU GIAO DIỆN
    // =========================================================

    private static final Color BG = new Color(244, 247, 250);
    private static final Color WHITE = Color.WHITE;
    private static final Color NAVY = new Color(22, 35, 58);
    private static final Color GREEN = new Color(16, 185, 129);
    private static final Color BLUE = new Color(59, 130, 246);
    private static final Color ORANGE = new Color(245, 158, 11);
    private static final Color RED = new Color(239, 68, 68);
    private static final Color PURPLE = new Color(139, 92, 246);
    private static final Color TEXT = new Color(30, 41, 59);
    private static final Color MUTED = new Color(100, 116, 139);
    private static final Color BORDER = new Color(226, 232, 240);
    private static final Color LIGHT_GREEN = new Color(236, 253, 245);
    private static final Color LIGHT_BLUE = new Color(239, 246, 255);
    private static final Color LIGHT_ORANGE = new Color(255, 251, 235);
    private static final Color LIGHT_RED = new Color(254, 242, 242);

    // =========================================================
    // COMPONENTS
    // =========================================================

    private JLabel lblTong;
    private JLabel lblDangLam;
    private JLabel lblThuViec;
    private JLabel lblNghiViec;

    private JTextField txtSearch;
    private JComboBox<String> cbPhongBan;
    private JComboBox<String> cbTrangThai;

    private JTable table;
    private DefaultTableModel tableModel;

    private DefaultTableModel deptTableModel; // Model bảng phòng ban để cập nhật động
    private List<Employee> employees;

    // Các panel chứa biểu đồ để gọi repaint() khi làm mới
    private GenderChart genderChart;
    private StatusChart statusChart;
    private AgeChart ageChart;
    private RecruitmentChart recruitmentChart;

    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public BaoCaoNhanSuFrame() {
        setLayout(new BorderLayout());
        setBackground(BG);

        employees = loadEmployeesFromDatabase();

        add(createHeader(), BorderLayout.NORTH);
        add(createMainContent(), BorderLayout.CENTER);
    }

    // =========================================================
    // HEADER
    // =========================================================

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(WHITE);
        header.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER),
                        new EmptyBorder(18, 24, 18, 24)
                )
        );

        // LEFT
        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel title = new JLabel("BÁO CÁO NHÂN SỰ");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(NAVY);

        JLabel subtitle = new JLabel("Tổng hợp, phân tích và theo dõi tình hình nhân sự");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(MUTED);

        left.add(title);
        left.add(Box.createVerticalStrut(5));
        left.add(subtitle);

        // RIGHT
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);

        JButton btnRefresh = createButton("↻  Làm mới", GREEN);
        JButton btnExport = createButton("↓  Xuất báo cáo", BLUE);
        JButton btnPrint = createButton("▣  In báo cáo", NAVY);

        btnRefresh.addActionListener(e -> refreshReport());
        btnExport.addActionListener(e -> exportCSV());
        btnPrint.addActionListener(e -> printReport());

        right.add(btnRefresh);
        right.add(btnExport);
        right.add(btnPrint);

        header.add(left, BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);

        return header;
    }

    // =========================================================
    // MAIN CONTENT
    // =========================================================

    private JPanel createMainContent() {
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(BG);
        main.setBorder(new EmptyBorder(18, 24, 18, 24));

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

        // Bộ lọc
        JPanel filterPanel = createFilterPanel();
        filterPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(filterPanel);

        content.add(Box.createVerticalStrut(15));

        // KPI
        JPanel kpiPanel = createKpiPanel();
        kpiPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(kpiPanel);

        content.add(Box.createVerticalStrut(15));

        // Hàng biểu đồ 1
        JPanel charts = new JPanel(new GridLayout(1, 2, 15, 0));
        charts.setOpaque(false);
        charts.setAlignmentX(Component.LEFT_ALIGNMENT);
        charts.setMaximumSize(new Dimension(Integer.MAX_VALUE, 260));

        charts.add(createGenderPanel());
        charts.add(createStatusPanel());

        content.add(charts);

        content.add(Box.createVerticalStrut(15));

        // Phòng ban
        JPanel deptPanel = createDepartmentPanel();
        deptPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(deptPanel);

        content.add(Box.createVerticalStrut(15));

        // Hàng biểu đồ 2 (Độ tuổi + tuyển dụng)
        JPanel analysis = new JPanel(new GridLayout(1, 2, 15, 0));
        analysis.setOpaque(false);
        analysis.setAlignmentX(Component.LEFT_ALIGNMENT);
        analysis.setMaximumSize(new Dimension(Integer.MAX_VALUE, 260));

        analysis.add(createAgePanel());
        analysis.add(createRecruitmentPanel());

        content.add(analysis);

        content.add(Box.createVerticalStrut(15));

        // Danh sách
        JPanel empPanel = createEmployeePanel();
        empPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(empPanel);

        JScrollPane scroll = new JScrollPane(
                content,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
        );
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);

        main.add(scroll, BorderLayout.CENTER);

        return main;
    }

    // =========================================================
    // FILTER
    // =========================================================

    private JPanel createFilterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        panel.setBackground(WHITE);
        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER),
                        new EmptyBorder(4, 10, 4, 10)
                )
        );

        JLabel filter = new JLabel("Bộ lọc:");
        filter.setFont(new Font("Segoe UI", Font.BOLD, 13));
        filter.setForeground(TEXT);

        cbPhongBan = new JComboBox<>();
        cbPhongBan.addItem("Tất cả phòng ban");
        loadPhongBanFilter();

        cbTrangThai = new JComboBox<>(new String[]{
                "Tất cả trạng thái",
                "Đang làm việc",
                "Thử việc",
                "Nghỉ việc"
        });

        txtSearch = new JTextField();
        txtSearch.setPreferredSize(new Dimension(220, 32));
        txtSearch.putClientProperty("JTextField.placeholderText", "Tìm mã NV / họ tên...");

        JButton btnSearch = createButton("Tìm kiếm", BLUE);

        cbPhongBan.addActionListener(e -> applyFilter());
        cbTrangThai.addActionListener(e -> applyFilter());
        txtSearch.addActionListener(e -> applyFilter());
        btnSearch.addActionListener(e -> applyFilter());

        panel.add(filter);
        panel.add(createSmallLabel("Phòng ban"));
        panel.add(cbPhongBan);
        panel.add(createSmallLabel("Trạng thái"));
        panel.add(cbTrangThai);
        panel.add(txtSearch);
        panel.add(btnSearch);

        return panel;
    }

    // =========================================================
    // KPI
    // =========================================================

    private JPanel createKpiPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 4, 15, 0));
        panel.setOpaque(false);

        lblTong = new JLabel("0");
        lblDangLam = new JLabel("0");
        lblThuViec = new JLabel("0");
        lblNghiViec = new JLabel("0");

        panel.add(createKpiCard("TỔNG NHÂN VIÊN", lblTong, "👥", GREEN, LIGHT_GREEN));
        panel.add(createKpiCard("ĐANG LÀM VIỆC", lblDangLam, "✓", BLUE, LIGHT_BLUE));
        panel.add(createKpiCard("ĐANG THỬ VIỆC", lblThuViec, "◷", ORANGE, LIGHT_ORANGE));
        panel.add(createKpiCard("NGHỈ VIỆC", lblNghiViec, "×", RED, LIGHT_RED));

        updateKpi(employees);

        return panel;
    }

    private JPanel createKpiCard(String title, JLabel value, String icon, Color color, Color background) {
        JPanel card = new JPanel(new BorderLayout(12, 0));
        card.setBackground(WHITE);
        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER),
                        new EmptyBorder(16, 18, 16, 18)
                )
        );

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        iconLabel.setFont(new Font("Segoe UI Symbol", Font.BOLD, 22));
        iconLabel.setForeground(color);

        JPanel iconBox = new JPanel(new BorderLayout());
        iconBox.setBackground(background);
        iconBox.setPreferredSize(new Dimension(50, 50));
        iconBox.add(iconLabel, BorderLayout.CENTER);

        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 10));
        titleLabel.setForeground(MUTED);

        value.setFont(new Font("Segoe UI", Font.BOLD, 28));
        value.setForeground(color);

        info.add(titleLabel);
        info.add(Box.createVerticalStrut(3));
        info.add(value);

        card.add(iconBox, BorderLayout.WEST);
        card.add(info, BorderLayout.CENTER);

        return card;
    }

    // =========================================================
    // GENDER
    // =========================================================

    private JPanel createGenderPanel() {
        JPanel panel = createWhitePanel("Cơ cấu giới tính");
        genderChart = new GenderChart();
        panel.add(genderChart, BorderLayout.CENTER);
        return panel;
    }

    // =========================================================
    // STATUS
    // =========================================================

    private JPanel createStatusPanel() {
        JPanel panel = createWhitePanel("Tình trạng nhân sự");
        statusChart = new StatusChart();
        panel.add(statusChart, BorderLayout.CENTER);
        return panel;
    }

    // =========================================================
    // DEPARTMENT (Động hoàn toàn theo danh sách nhân viên)
    // =========================================================

    private JPanel createDepartmentPanel() {
        JPanel panel = createWhitePanel("Thống kê nhân sự theo phòng ban");

        String[] columns = {
                "STT", "Phòng ban", "Số nhân viên", "Đang làm", "Thử việc", "Nghỉ việc", "Tỷ lệ"
        };

        deptTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        updateDepartmentTable(employees);

        JTable deptTable = new JTable(deptTableModel);
        styleTable(deptTable);

        JScrollPane scroll = new JScrollPane(deptTable);
        scroll.setBorder(null);
        scroll.setPreferredSize(new Dimension(0, 150));

        panel.add(scroll, BorderLayout.CENTER);

        return panel;
    }

    private void updateDepartmentTable(List<Employee> dataList) {
        if (deptTableModel == null) return;
        deptTableModel.setRowCount(0);

        // Gom nhóm theo phòng ban thực tế từ database
        Map<String, int[]> deptStats = new java.util.TreeMap<>(); // [total, dangLam, thuViec, nghiViec]

        for (Employee e : dataList) {
            String dept = safeText(e.phongBan, "Chưa cập nhật");
            int[] stats = deptStats.computeIfAbsent(dept, k -> new int[]{0, 0, 0, 0});
            stats[0]++; // Tổng
            if ("Đang làm việc".equals(e.trangThai)) stats[1]++;
            else if ("Thử việc".equals(e.trangThai)) stats[2]++;
            else if ("Nghỉ việc".equals(e.trangThai)) stats[3]++;
        }

        int stt = 1;
        int totalEmployees = dataList.size();

        for (Map.Entry<String, int[]> entry : deptStats.entrySet()) {
            String deptName = entry.getKey();
            int[] stats = entry.getValue();
            int total = stats[0];

            double ratio = totalEmployees > 0 ? (total * 100.0 / totalEmployees) : 0;
            String ratioStr = String.format("%.1f%%", ratio);

            deptTableModel.addRow(new Object[]{
                    stt++,
                    deptName,
                    String.valueOf(total),
                    String.valueOf(stats[1]),
                    String.valueOf(stats[2]),
                    String.valueOf(stats[3]),
                    ratioStr
            });
        }
    }

    // =========================================================
    // AGE
    // =========================================================

    private JPanel createAgePanel() {
        JPanel panel = createWhitePanel("Phân bố nhân sự theo độ tuổi");
        ageChart = new AgeChart();
        panel.add(ageChart, BorderLayout.CENTER);
        return panel;
    }

    // =========================================================
    // RECRUITMENT
    // =========================================================

    private JPanel createRecruitmentPanel() {
        JPanel panel = createWhitePanel("Tình hình tuyển dụng theo tháng");
        recruitmentChart = new RecruitmentChart();
        panel.add(recruitmentChart, BorderLayout.CENTER);
        return panel;
    }

    // =========================================================
    // EMPLOYEE TABLE
    // =========================================================

    private JPanel createEmployeePanel() {
        JPanel panel = createWhitePanel("Danh sách nhân viên");

        String[] columns = {
                "STT", "Mã NV", "Họ và tên", "Giới tính", "Ngày sinh", "Phòng ban", "Chức vụ", "Ngày vào làm", "Trạng thái"
        };

        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        styleTable(table);

        loadEmployeeTable(employees);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setPreferredSize(new Dimension(1000, 260));

        panel.add(scroll, BorderLayout.CENTER);

        return panel;
    }

    // =========================================================
    // LOAD TABLE
    // =========================================================

    private void loadEmployeeTable(List<Employee> data) {
        if (tableModel == null) return;
        tableModel.setRowCount(0);
        int stt = 1;
        for (Employee e : data) {
            tableModel.addRow(new Object[]{
                    stt++,
                    e.maNV,
                    e.hoTen,
                    e.gioiTinh,
                    e.ngaySinh,
                    e.phongBan,
                    e.chucVu,
                    e.ngayVaoLam,
                    e.trangThai
            });
        }
    }

    // =========================================================
    // FILTER LOGIC
    // =========================================================

    private void applyFilter() {
        String keyword = txtSearch.getText().trim().toLowerCase();
        String phongBan = String.valueOf(cbPhongBan.getSelectedItem());
        String trangThai = String.valueOf(cbTrangThai.getSelectedItem());

        List<Employee> result = new ArrayList<>();

        for (Employee e : employees) {
            boolean matchKeyword = keyword.isEmpty()
                    || e.maNV.toLowerCase().contains(keyword)
                    || e.hoTen.toLowerCase().contains(keyword);

            boolean matchPhong = phongBan.equals("Tất cả phòng ban") || e.phongBan.equals(phongBan);
            boolean matchStatus = trangThai.equals("Tất cả trạng thái") || e.trangThai.equals(trangThai);

            if (matchKeyword && matchPhong && matchStatus) {
                result.add(e);
            }
        }

        loadEmployeeTable(result);
    }

    // =========================================================
    // KPI LOGIC
    // =========================================================

    private void updateKpi(List<Employee> dataList) {
        int tong = dataList.size();
        int dangLam = 0;
        int thuViec = 0;
        int nghiViec = 0;

        for (Employee e : dataList) {
            if ("Đang làm việc".equals(e.trangThai)) {
                dangLam++;
            } else if ("Thử việc".equals(e.trangThai)) {
                thuViec++;
            } else if ("Nghỉ việc".equals(e.trangThai)) {
                nghiViec++;
            }
        }

        if (lblTong != null) lblTong.setText(String.valueOf(tong));
        if (lblDangLam != null) lblDangLam.setText(String.valueOf(dangLam));
        if (lblThuViec != null) lblThuViec.setText(String.valueOf(thuViec));
        if (lblNghiViec != null) lblNghiViec.setText(String.valueOf(nghiViec));
    }

    // =========================================================
    // REFRESH
    // =========================================================

    private void refreshReport() {
        employees = loadEmployeesFromDatabase();
        loadPhongBanFilter();

        if (txtSearch != null) txtSearch.setText("");
        if (cbPhongBan != null) cbPhongBan.setSelectedIndex(0);
        if (cbTrangThai != null) cbTrangThai.setSelectedIndex(0);

        updateKpi(employees);
        updateDepartmentTable(employees);
        loadEmployeeTable(employees);

        if (genderChart != null) genderChart.repaint();
        if (statusChart != null) statusChart.repaint();
        if (ageChart != null) ageChart.repaint();
        if (recruitmentChart != null) recruitmentChart.repaint();

        JOptionPane.showMessageDialog(
                this,
                "Đã làm mới dữ liệu từ cơ sở dữ liệu.",
                "Thông báo",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    // =========================================================
    // EXPORT
    // =========================================================

    private void exportCSV() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Xuất báo cáo nhân sự");
        chooser.setSelectedFile(new java.io.File("bao_cao_nhan_su.csv"));

        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        try {
            java.io.File file = chooser.getSelectedFile();
            try (java.io.PrintWriter writer = new java.io.PrintWriter(
                    new java.io.OutputStreamWriter(
                            new java.io.FileOutputStream(file),
                            java.nio.charset.StandardCharsets.UTF_8
                    )
            )) {
                writer.write('\uFEFF');

                for (int c = 0; c < table.getColumnCount(); c++) {
                    writer.print(csv(table.getColumnName(c)));
                    if (c < table.getColumnCount() - 1) writer.print(",");
                }
                writer.println();

                for (int r = 0; r < table.getRowCount(); r++) {
                    for (int c = 0; c < table.getColumnCount(); c++) {
                        Object value = table.getValueAt(r, c);
                        writer.print(csv(value == null ? "" : value.toString()));
                        if (c < table.getColumnCount() - 1) writer.print(",");
                    }
                    writer.println();
                }
            }

            JOptionPane.showMessageDialog(this, "Xuất báo cáo thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Không thể xuất báo cáo:\n" + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String csv(String value) {
        if (value == null) return "";
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    // =========================================================
    // PRINT
    // =========================================================

    private void printReport() {
        try {
            boolean complete = table.print();
            if (complete) {
                JOptionPane.showMessageDialog(this, "Đã gửi báo cáo tới máy in.", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Không thể in báo cáo:\n" + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    // =========================================================
    // WHITE PANEL
    // =========================================================

    private JPanel createWhitePanel(String title) {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(WHITE);
        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER),
                        new EmptyBorder(15, 15, 15, 15)
                )
        );

        JLabel label = new JLabel(title);
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        label.setForeground(NAVY);

        panel.add(label, BorderLayout.NORTH);

        return panel;
    }

    // =========================================================
    // BUTTON & UTILITY
    // =========================================================

    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 11));
        button.setForeground(color);
        button.setBackground(WHITE);
        button.setFocusPainted(false);
        button.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(color),
                        new EmptyBorder(7, 14, 7, 14)
                )
        );
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private JLabel createSmallLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        label.setForeground(MUTED);
        return label;
    }

    // =========================================================
    // TABLE STYLE
    // =========================================================

    private void styleTable(JTable table) {
        table.setRowHeight(34);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setForeground(TEXT);
        table.setGridColor(BORDER);
        table.setSelectionBackground(new Color(236, 253, 245));
        table.setSelectionForeground(TEXT);

        table.getTableHeader().setOpaque(false);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        table.getTableHeader().setBackground(NAVY);
        table.getTableHeader().setForeground(WHITE);
        table.getTableHeader().setPreferredSize(new Dimension(0, 38));

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setBackground(NAVY);
        headerRenderer.setForeground(WHITE);
        headerRenderer.setFont(new Font("Segoe UI", Font.BOLD, 12));
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);

        for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }
    }

    // =========================================================
    // LOAD DỮ LIỆU NHÂN SỰ TỪ DATABASE
    // =========================================================

    private List<Employee> loadEmployeesFromDatabase() {
        List<Employee> list = new ArrayList<>();

        try {
            BaoCaoDAO baoCaoDAO = new BaoCaoDAO();
            List<NhanVienBaoCaoDTO> data = baoCaoDAO.getDanhSachBaoCaoNhanSu();

            if (data == null) {
                return list;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

            for (NhanVienBaoCaoDTO nv : data) {
                if (nv == null) {
                    continue;
                }

                String ngaySinh = formatDate(nv.getNgaySinh(), sdf);
                String ngayVaoLam = formatDate(nv.getNgayVaoLam(), sdf);

                String maNV = safeText(nv.getMaNV(), "");
                String hoTen = safeText(nv.getHoTen(), "Chưa cập nhật");
                String gioiTinh = safeText(nv.getGioiTinh(), "Chưa cập nhật");
                String phongBan = safeText(nv.getPhongBan(), "Chưa cập nhật");
                String chucVu = safeText(nv.getChucVu(), "Chưa cập nhật");
                String trangThai = safeText(nv.getTrangThai(), "Đang làm việc");

                list.add(new Employee(
                        maNV,
                        hoTen,
                        gioiTinh,
                        ngaySinh,
                        phongBan,
                        chucVu,
                        ngayVaoLam,
                        trangThai
                ));
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Không thể tải dữ liệu nhân sự từ database:\n" + ex.getMessage(),
                    "Lỗi dữ liệu",
                    JOptionPane.ERROR_MESSAGE
            );
        }

        return list;
    }

    private String formatDate(Date date, SimpleDateFormat sdf) {
        return date == null ? "" : sdf.format(date);
    }

    private String safeText(String value, String defaultValue) {
        if (value == null || value.trim().isEmpty()) {
            return defaultValue;
        }
        return value.trim();
    }

    /**
     * Nạp danh sách phòng ban thật từ danh sách nhân viên đã đọc từ database.
     */
    private void loadPhongBanFilter() {
        if (cbPhongBan == null) {
            return;
        }

        String selected = String.valueOf(cbPhongBan.getSelectedItem());

        cbPhongBan.removeAllItems();
        cbPhongBan.addItem("Tất cả phòng ban");

        java.util.Set<String> departments = new java.util.TreeSet<>(
                String.CASE_INSENSITIVE_ORDER
        );

        if (employees != null) {
            for (Employee e : employees) {
                if (e != null && e.phongBan != null && !e.phongBan.trim().isEmpty()) {
                    departments.add(e.phongBan.trim());
                }
            }
        }

        for (String department : departments) {
            cbPhongBan.addItem(department);
        }

        if (selected != null && !selected.equals("null")) {
            cbPhongBan.setSelectedItem(selected);
        }

        if (cbPhongBan.getSelectedIndex() < 0) {
            cbPhongBan.setSelectedIndex(0);
        }
    }

    private static class Employee {
        String maNV, hoTen, gioiTinh, ngaySinh, phongBan, chucVu, ngayVaoLam, trangThai;

        Employee(String maNV, String hoTen, String gioiTinh, String ngaySinh, String phongBan, String chucVu, String ngayVaoLam, String trangThai) {
            this.maNV = maNV == null ? "" : maNV;
            this.hoTen = hoTen == null ? "" : hoTen;
            this.gioiTinh = gioiTinh == null ? "" : gioiTinh;
            this.ngaySinh = ngaySinh == null ? "" : ngaySinh;
            this.phongBan = phongBan == null ? "" : phongBan;
            this.chucVu = chucVu == null ? "" : chucVu;
            this.ngayVaoLam = ngayVaoLam == null ? "" : ngayVaoLam;
            this.trangThai = trangThai == null ? "" : trangThai;
        }
    }

    // =========================================================
    // GENDER CHART (Động theo danh sách nhân viên)
    // =========================================================

    private class GenderChart extends JPanel {
        @Override
        public Dimension getPreferredSize() {
            return new Dimension(380, 190);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int nam = 0;
            int nu = 0;
            for (Employee e : employees) {
                if ("Nam".equalsIgnoreCase(e.gioiTinh)) nam++;
                else if ("Nữ".equalsIgnoreCase(e.gioiTinh)) nu++;
            }
            int total = nam + nu;
            int size = 140;
            int x = 30;
            int y = 20;

            double namAngle = total > 0 ? (nam * 360.0 / total) : 0;

            g2.setColor(BLUE);
            g2.fillArc(x, y, size, size, 0, (int) namAngle);

            g2.setColor(PURPLE);
            g2.fillArc(x, y, size, size, (int) namAngle, 360 - (int) namAngle);

            g2.setColor(WHITE);
            g2.fill(new Ellipse2D.Double(x + 38, y + 38, 64, 64));

            g2.setFont(new Font("Segoe UI", Font.BOLD, 18));
            g2.setColor(NAVY);
            g2.drawString(String.valueOf(total), x + 58, y + 76);

            drawLegend(g2, 200, 50, BLUE, "Nam", nam + " người");
            drawLegend(g2, 200, 95, PURPLE, "Nữ", nu + " người");

            g2.dispose();
        }

        private void drawLegend(Graphics2D g2, int x, int y, Color color, String title, String value) {
            g2.setColor(color);
            g2.fillRect(x, y - 10, 12, 12);
            g2.setColor(TEXT);
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            g2.drawString(title, x + 20, y);
            g2.setColor(MUTED);
            g2.drawString(value, x + 20, y + 17);
        }
    }

    // =========================================================
    // STATUS CHART (Động hoàn toàn theo danh sách nhân viên)
    // =========================================================

    private class StatusChart extends JPanel {
        @Override
        public Dimension getPreferredSize() {
            return new Dimension(380, 190);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int dangLam = 0;
            int thuViec = 0;
            int nghiViec = 0;

            for (Employee e : employees) {
                if ("Đang làm việc".equals(e.trangThai)) {
                    dangLam++;
                } else if ("Thử việc".equals(e.trangThai)) {
                    thuViec++;
                } else if ("Nghỉ việc".equals(e.trangThai)) {
                    nghiViec++;
                }
            }

            int[] values = {dangLam, thuViec, nghiViec};
            String[] names = {"Đang làm việc", "Thử việc", "Nghỉ việc"};
            Color[] colors = {GREEN, ORANGE, RED};
            int max = Math.max(1, Math.max(dangLam, Math.max(thuViec, nghiViec)));

            for (int i = 0; i < 3; i++) {
                int y = 20 + i * 48;

                g2.setColor(new Color(241, 245, 249));
                g2.fillRoundRect(130, y, 170, 22, 8, 8);

                int width = max > 0 ? values[i] * 170 / max : 0;
                g2.setColor(colors[i]);
                g2.fillRoundRect(130, y, width, 22, 8, 8);

                g2.setColor(TEXT);
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
                g2.drawString(names[i], 10, y + 15);

                g2.setFont(new Font("Segoe UI", Font.BOLD, 11));
                g2.drawString(values[i] + "", 310, y + 15);
            }
            g2.dispose();
        }
    }

    // =========================================================
    // AGE CHART (Động theo ngày sinh thực tế của nhân viên)
    // =========================================================

    private class AgeChart extends JPanel {
        @Override
        public Dimension getPreferredSize() {
            return new Dimension(380, 190);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Phân nhóm: [<25, 25-30, 31-35, 36-40, >40]
            int[] values = new int[5];
            LocalDate today = LocalDate.now();

            for (Employee e : employees) {
                try {
                    LocalDate birthDate = LocalDate.parse(e.ngaySinh);
                    int age = Period.between(birthDate, today).getYears();
                    if (age < 25) {
                        values[0]++;
                    } else if (age <= 30) {
                        values[1]++;
                    } else if (age <= 35) {
                        values[2]++;
                    } else if (age <= 40) {
                        values[3]++;
                    } else {
                        values[4]++;
                    }
                } catch (Exception ex) {
                    // Bỏ qua nếu lỗi định dạng ngày
                }
            }

            String[] labels = {"< 25", "25-30", "31-35", "36-40", "> 40"};
            int max = 1;
            for (int v : values) {
                if (v > max) max = v;
            }

            int startX = 35;
            int baseY = 160;
            int barWidth = 42;
            int gap = 20;

            for (int i = 0; i < values.length; i++) {
                int height = max > 0 ? (values[i] * 100 / max) : 0;
                int x = startX + i * (barWidth + gap);
                int y = baseY - height;

                g2.setColor(BLUE);
                g2.fillRoundRect(x, y, barWidth, Math.max(4, height), 6, 6);

                g2.setColor(TEXT);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 10));
                g2.drawString(String.valueOf(values[i]), x + 16, Math.max(15, y - 5));

                g2.setColor(MUTED);
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
                g2.drawString(labels[i], x + 6, baseY + 15);
            }

            g2.setColor(BORDER);
            g2.drawLine(25, baseY, 345, baseY);

            g2.dispose();
        }
    }

    // =========================================================
    // RECRUITMENT CHART
    // =========================================================

    private class RecruitmentChart extends JPanel {
        @Override
        public Dimension getPreferredSize() {
            return new Dimension(380, 190);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Thống kê 6 tháng gần nhất dựa trên ngày vào làm thực tế.
            LocalDate currentMonth = LocalDate.now().withDayOfMonth(1);
            String[] months = new String[6];
            int[] values = new int[6];

            for (int i = 0; i < 6; i++) {
                LocalDate month = currentMonth.minusMonths(5 - i);
                months[i] = "T" + month.getMonthValue();

                for (Employee e : employees) {
                    try {
                        if (e.ngayVaoLam == null || e.ngayVaoLam.trim().isEmpty()) {
                            continue;
                        }

                        LocalDate startDate = LocalDate.parse(e.ngayVaoLam);

                        if (startDate.getYear() == month.getYear()
                                && startDate.getMonthValue() == month.getMonthValue()) {
                            values[i]++;
                        }
                    } catch (Exception ignored) {
                        // Bỏ qua ngày vào làm không hợp lệ.
                    }
                }
            }

            int max = 1;
            for (int value : values) {
                max = Math.max(max, value);
            }

            int startX = 30;
            int baseY = 160;
            int barWidth = 42;
            int gap = 14;

            for (int i = 0; i < values.length; i++) {
                int height = values[i] * 100 / max;
                int x = startX + i * (barWidth + gap);
                int y = baseY - height;

                g2.setColor(GREEN);
                g2.fillRoundRect(x, y, barWidth, height, 6, 6);

                g2.setColor(TEXT);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 10));
                g2.drawString(String.valueOf(values[i]), x + 16, y - 5);

                g2.setColor(MUTED);
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
                g2.drawString(months[i], x + 12, baseY + 15);
            }

            g2.setColor(BORDER);
            g2.drawLine(20, baseY, 360, baseY);

            g2.dispose();
        }
    }
}