package vn.edu.eaut.lab3;

import javax.swing.*;
import java.awt.*;

public class Bai06LoginForm extends JFrame {
    private final JTextField txtUsername = new JTextField(15);
    private final JPasswordField txtPassword = new JPasswordField(15);
    private final JComboBox<String> cbRole = new JComboBox<>(new String[]{"Admin", "User"});
    private final JCheckBox chkShowPassword = new JCheckBox("Hiển thị mật khẩu");

    public Bai06LoginForm() {
        setTitle("Bài 6 - Form đăng nhập cơ bản");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(380, 240);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.WEST;

        // Dòng 1: Tài khoản
        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Tài khoản:"), gbc);
        gbc.gridx = 1; add(txtUsername, gbc);

        // Dòng 2: Mật khẩu
        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Mật khẩu:"), gbc);
        gbc.gridx = 1; add(txtPassword, gbc);

        // Dòng 3: Hiển thị mật khẩu
        gbc.gridx = 1; gbc.gridy = 2;
        add(chkShowPassword, gbc);

        // Dòng 4: Vai trò
        gbc.gridx = 0; gbc.gridy = 3;
        add(new JLabel("Vai trò:"), gbc);
        gbc.gridx = 1; add(cbRole, gbc);

        // Dòng 5: Nút Đăng nhập
        JButton btnLogin = new JButton("Đăng nhập");
        gbc.gridx = 1; gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.CENTER;
        add(btnLogin, gbc);

        // Xử lý sự kiện checkbox hiển thị mật khẩu
        chkShowPassword.addActionListener(e -> {
            if (chkShowPassword.isSelected()) {
                txtPassword.setEchoChar((char) 0);
            } else {
                txtPassword.setEchoChar('•');
            }
        });

        // Xử lý sự kiện nút Đăng nhập
        btnLogin.addActionListener(e -> xuLyDangNhap());
    }

    private void xuLyDangNhap() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());
        String role = (String) cbRole.getSelectedItem();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ tài khoản và mật khẩu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Kiểm thử theo quy ước: admin/123456 (Admin) hoặc user/123456 (User)
        if ("admin".equals(username) && "123456".equals(password) && "Admin".equals(role)) {
            JOptionPane.showMessageDialog(this, "Đăng nhập thành công! Chào mừng Quản trị viên (Admin).", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        } else if ("user".equals(username) && "123456".equals(password) && "User".equals(role)) {
            JOptionPane.showMessageDialog(this, "Đăng nhập thành công! Chào mừng Người dùng (User).", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Sai tài khoản, mật khẩu hoặc vai trò người dùng!", "Đăng nhập thất bại", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai06LoginForm().setVisible(true));
    }
}