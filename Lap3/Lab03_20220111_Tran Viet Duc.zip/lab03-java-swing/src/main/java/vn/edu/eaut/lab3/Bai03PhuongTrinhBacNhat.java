package vn.edu.eaut.lab3;

import javax.swing.*;
import java.awt.*;

public class Bai03PhuongTrinhBacNhat extends JFrame {
    private final JTextField txtA = new JTextField(15);
    private final JTextField txtB = new JTextField(15);
    private final JTextField txtKetQua = new JTextField(20);

    public Bai03PhuongTrinhBacNhat() {
        setTitle("Bài 3 - Giải phương trình bậc nhất (ax + b = 0)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(380, 230);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        // Dòng 1: Hệ số a
        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Hệ số a:"), gbc);
        gbc.gridx = 1;
        add(txtA, gbc);

        // Dòng 2: Hệ số b
        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Hệ số b:"), gbc);
        gbc.gridx = 1;
        add(txtB, gbc);

        // Dòng 3: Kết quả
        gbc.gridx = 0; gbc.gridy = 2;
        add(new JLabel("Kết quả:"), gbc);
        gbc.gridx = 1;
        txtKetQua.setEditable(false);
        add(txtKetQua, gbc);

        // Dòng 4: Nút giải phương trình
        JButton btnGiai = new JButton("Giải phương trình");
        gbc.gridx = 1; gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        add(btnGiai, gbc);

        // Xử lý sự kiện nút bấm
        btnGiai.addActionListener(e -> giaiPhuongTrinh());
    }

    private void giaiPhuongTrinh() {
        try {
            double a = Double.parseDouble(txtA.getText().trim());
            double b = Double.parseDouble(txtB.getText().trim());

            if (a == 0) {
                if (b == 0) {
                    txtKetQua.setText("Phương trình vô số nghiệm");
                } else {
                    txtKetQua.setText("Phương trình vô nghiệm");
                }
            } else {
                double x = -b / a;
                txtKetQua.setText(String.format("x = %.4f", x));
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập vào các số hợp lệ!", "Lỗi định dạng", JOptionPane.ERROR_MESSAGE);
            txtA.requestFocus();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai03PhuongTrinhBacNhat().setVisible(true));
    }
}