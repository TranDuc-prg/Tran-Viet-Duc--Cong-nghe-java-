package vn.edu.eaut.lab3;

import javax.swing.*;
import java.awt.*;

public class Bai07MayTinhMini extends JFrame {
    private final JTextField txtSo1 = new JTextField(12);
    private final JTextField txtSo2 = new JTextField(12);
    private final JTextField txtKetQua = new JTextField(15);
    private final JTextArea txtLichSu = new JTextArea(6, 25);

    public Bai07MayTinhMini() {
        setTitle("Bài 7 - Máy tính mini");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(420, 380);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Panel nhập liệu phía trên
        JPanel panelInput = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        panelInput.add(new JLabel("Số thứ nhất:"), gbc);
        gbc.gridx = 1; panelInput.add(txtSo1, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panelInput.add(new JLabel("Số thứ hai:"), gbc);
        gbc.gridx = 1; panelInput.add(txtSo2, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panelInput.add(new JLabel("Kết quả:"), gbc);
        gbc.gridx = 1;
        txtKetQua.setEditable(false);
        panelInput.add(txtKetQua, gbc);

        // Panel chứa các nút bấm phép tính
        JPanel panelButtons = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 5));
        JButton btnCong = new JButton("+");
        JButton btnTru = new JButton("-");
        JButton btnNhan = new JButton("*");
        JButton btnChia = new JButton("/");
        JButton btnClear = new JButton("Clear");

        panelButtons.add(btnCong);
        panelButtons.add(btnTru);
        panelButtons.add(btnNhan);
        panelButtons.add(btnChia);
        panelButtons.add(btnClear);

        JPanel panelTop = new JPanel(new BorderLayout());
        panelTop.add(panelInput, BorderLayout.CENTER);
        panelTop.add(panelButtons, BorderLayout.SOUTH);

        add(panelTop, BorderLayout.NORTH);

        // Panel lịch sử phép tính ở giữa
        txtLichSu.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(txtLichSu);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Lịch sử phép tính"));
        add(scrollPane, BorderLayout.CENTER);

        // Gắn sự kiện cho các nút
        btnCong.addActionListener(e -> tinhToan("+"));
        btnTru.addActionListener(e -> tinhToan("-"));
        btnNhan.addActionListener(e -> tinhToan("*"));
        btnChia.addActionListener(e -> tinhToan("/"));
        btnClear.addActionListener(e -> xoaForm());
    }

    private void tinhToan(String phepToan) {
        try {
            double so1 = Double.parseDouble(txtSo1.getText().trim());
            double so2 = Double.parseDouble(txtSo2.getText().trim());
            double kq = 0;
            String bieuThuc;

            switch (phepToan) {
                case "+":
                    kq = so1 + so2;
                    break;
                case "-":
                    kq = so1 - so2;
                    break;
                case "*":
                    kq = so1 * so2;
                    break;
                case "/":
                    if (so2 == 0) {
                        JOptionPane.showMessageDialog(this, "Lỗi: Không thể chia cho số 0!", "Lỗi toán học", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    kq = so1 / so2;
                    break;
            }

            txtKetQua.setText(String.valueOf(kq));
            bieuThuc = String.format("%.2f %s %.2f = %.2f\n", so1, phepToan, so2, kq);
            txtLichSu.append(bieuThuc);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập vào các số hợp lệ!", "Lỗi định dạng", JOptionPane.ERROR_MESSAGE);
            txtSo1.requestFocus();
        }
    }

    private void xoaForm() {
        txtSo1.setText("");
        txtSo2.setText("");
        txtKetQua.setText("");
        txtLichSu.setText("");
        txtSo1.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai07MayTinhMini().setVisible(true));
    }
}