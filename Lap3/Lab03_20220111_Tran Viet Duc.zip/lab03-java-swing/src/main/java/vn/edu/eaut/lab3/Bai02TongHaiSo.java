package vn.edu.eaut.lab3;

import javax.swing.*;
import java.awt.*;

public class Bai02TongHaiSo extends JFrame {
    private final JTextField txtSo1 = new JTextField(15);
    private final JTextField txtSo2 = new JTextField(15);
    private final JTextField txtKetQua = new JTextField(15);

    public Bai02TongHaiSo() {
        setTitle("Bài 2 - Tính tổng hai số");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(350, 220);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        // Dòng 1: Số thứ nhất
        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Số thứ nhất:"), gbc);
        gbc.gridx = 1;
        add(txtSo1, gbc);

        // Dòng 2: Số thứ hai
        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Số thứ hai:"), gbc);
        gbc.gridx = 1;
        add(txtSo2, gbc);

        // Dòng 3: Kết quả
        gbc.gridx = 0; gbc.gridy = 2;
        add(new JLabel("Kết quả:"), gbc);
        gbc.gridx = 1;
        txtKetQua.setEditable(false);
        add(txtKetQua, gbc);

        // Dòng 4: Nút tính tổng
        JButton btnTinh = new JButton("Tính tổng");
        gbc.gridx = 1; gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        add(btnTinh, gbc);

        // Xử lý sự kiện khi bấm nút
        btnTinh.addActionListener(e -> tinhTong());
    }

    private void tinhTong() {
        try {
            double so1 = Double.parseDouble(txtSo1.getText().trim());
            double so2 = Double.parseDouble(txtSo2.getText().trim());
            double tong = so1 + so2;
            txtKetQua.setText(String.valueOf(tong));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập vào các số hợp lệ!", "Lỗi định dạng", JOptionPane.ERROR_MESSAGE);
            txtSo1.requestFocus();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai02TongHaiSo().setVisible(true));
    }
}