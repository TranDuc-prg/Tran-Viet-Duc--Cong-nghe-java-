package vn.edu.eaut.lab3;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Bai08QuanLySinhVien extends JFrame {
    private final JTextField txtMaSV = new JTextField(15);
    private final JTextField txtHoTen = new JTextField(15);
    private final JTextField txtDiemTB = new JTextField(15);

    private final DefaultTableModel tableModel;
    private final JTable table;
    private final List<Student> listStudents = new ArrayList<>();

    public Bai08QuanLySinhVien() {
        setTitle("Bài 8 - Quản lý sinh viên bằng JTable");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Panel nhập liệu phía trên
        JPanel panelInput = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        panelInput.add(new JLabel("Mã sinh viên:"), gbc);
        gbc.gridx = 1; panelInput.add(txtMaSV, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panelInput.add(new JLabel("Họ tên:"), gbc);
        gbc.gridx = 1; panelInput.add(txtHoTen, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panelInput.add(new JLabel("Điểm trung bình:"), gbc);
        gbc.gridx = 1; panelInput.add(txtDiemTB, gbc);

        // Panel chứa các nút chức năng
        JPanel panelButtons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        JButton btnThem = new JButton("Thêm");
        JButton btnSua = new JButton("Sửa");
        JButton btnXoa = new JButton("Xóa");
        JButton btnLamMoi = new JButton("Làm mới");

        panelButtons.add(btnThem);
        panelButtons.add(btnSua);
        panelButtons.add(btnXoa);
        panelButtons.add(btnLamMoi);

        JPanel panelTop = new JPanel(new BorderLayout());
        panelTop.add(panelInput, BorderLayout.CENTER);
        panelTop.add(panelButtons, BorderLayout.SOUTH);
        add(panelTop, BorderLayout.NORTH);

        // Khởi tạo JTable
        String[] columnNames = {"Mã SV", "Họ tên", "Điểm TB", "Xếp loại"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // Xử lý sự kiện click trên bảng
        table.getSelectionModel().addListSelectionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                txtMaSV.setText(tableModel.getValueAt(selectedRow, 0).toString());
                txtHoTen.setText(tableModel.getValueAt(selectedRow, 1).toString());
                txtDiemTB.setText(tableModel.getValueAt(selectedRow, 2).toString());
                txtMaSV.setEditable(false);
            }
        });

        // Gắn sự kiện cho các nút
        btnThem.addActionListener(e -> themSinhVien());
        btnSua.addActionListener(e -> suaSinhVien());
        btnXoa.addActionListener(e -> xoaSinhVien());
        btnLamMoi.addActionListener(e -> lamMoiForm());
    }

    private void themSinhVien() {
        try {
            String maSV = txtMaSV.getText().trim();
            String hoTen = txtHoTen.getText().trim();
            if (maSV.isEmpty() || hoTen.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
                return;
            }
            for (Student s : listStudents) {
                if (s.getMaSV().equalsIgnoreCase(maSV)) {
                    JOptionPane.showMessageDialog(this, "Mã sinh viên đã tồn tại!");
                    return;
                }
            }
            double diemTB = Double.parseDouble(txtDiemTB.getText().trim());
            listStudents.add(new Student(maSV, hoTen, diemTB));
            capNhatBang();
            lamMoiForm();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Điểm phải là số hợp lệ!");
        }
    }

    private void suaSinhVien() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Chọn sinh viên để sửa!");
            return;
        }
        try {
            Student sv = listStudents.get(row);
            sv.setHoTen(txtHoTen.getText().trim());
            sv.setDiemTB(Double.parseDouble(txtDiemTB.getText().trim()));
            capNhatBang();
            lamMoiForm();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Điểm phải là số hợp lệ!");
        }
    }

    private void xoaSinhVien() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            listStudents.remove(row);
            capNhatBang();
            lamMoiForm();
        }
    }

    private void lamMoiForm() {
        txtMaSV.setText(""); txtHoTen.setText(""); txtDiemTB.setText("");
        txtMaSV.setEditable(true);
        table.clearSelection();
    }

    private void capNhatBang() {
        tableModel.setRowCount(0);
        for (Student s : listStudents) {
            tableModel.addRow(new Object[]{s.getMaSV(), s.getHoTen(), s.getDiemTB(), s.getXepLoai()});
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai08QuanLySinhVien().setVisible(true));
    }
}