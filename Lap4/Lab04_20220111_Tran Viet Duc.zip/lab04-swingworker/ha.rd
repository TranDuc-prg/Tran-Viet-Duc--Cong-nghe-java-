mvn clean compile
mvn "exec:java" "-Dexec.mainClass=vn.edu.eaut.lab4.App"