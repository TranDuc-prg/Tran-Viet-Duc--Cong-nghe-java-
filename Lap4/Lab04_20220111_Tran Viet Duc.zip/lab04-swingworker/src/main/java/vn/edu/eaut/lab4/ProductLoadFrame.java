package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ProductLoadFrame extends JFrame {

    private JButton btnLoad;
    private JProgressBar progressBar;
    private JLabel lblStatus;
    private JTable table;
    private DefaultTableModel tableModel;

    public ProductLoadFrame() {

        setTitle("Bài 9 - Tải danh sách sản phẩm");
        setSize(650, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Nút tải sản phẩm
        btnLoad = new JButton("Tải sản phẩm");

        // Thanh tiến trình
        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);

        // Trạng thái
        lblStatus = new JLabel(
                "Chưa tải dữ liệu",
                SwingConstants.CENTER
        );

        // Tạo bảng
        tableModel = new DefaultTableModel(
                new String[]{
                        "Mã SP",
                        "Tên sản phẩm",
                        "Giá"
                },
                0
        );

        table = new JTable(tableModel);

        JScrollPane scrollPane =
                new JScrollPane(table);

        // Panel phía trên
        JPanel topPanel = new JPanel(
                new GridLayout(3, 1, 10, 10)
        );

        topPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        15, 20, 15, 20
                )
        );

        topPanel.add(btnLoad);
        topPanel.add(progressBar);
        topPanel.add(lblStatus);

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Sự kiện nút tải
        btnLoad.addActionListener(
                e -> loadProducts()
        );
    }

    private void loadProducts() {

        btnLoad.setEnabled(false);

        tableModel.setRowCount(0);

        progressBar.setValue(0);

        lblStatus.setText(
                "Đang tải sản phẩm..."
        );

        SwingWorker<List<Product>, Integer> worker =
                new SwingWorker<>() {

                    @Override
                    protected List<Product> doInBackground()
                            throws Exception {

                        List<Product> products =
                                new ArrayList<>();

                        // Dữ liệu giả lập
                        products.add(
                                new Product(
                                        "SP01",
                                        "Laptop Dell",
                                        15000000
                                )
                        );

                        products.add(
                                new Product(
                                        "SP02",
                                        "Chuột Logitech",
                                        500000
                                )
                        );

                        products.add(
                                new Product(
                                        "SP03",
                                        "Bàn phím cơ",
                                        1200000
                                )
                        );

                        products.add(
                                new Product(
                                        "SP04",
                                        "Màn hình Samsung",
                                        4500000
                                )
                        );

                        products.add(
                                new Product(
                                        "SP05",
                                        "Tai nghe Bluetooth",
                                        800000
                                )
                        );

                        products.add(
                                new Product(
                                        "SP06",
                                        "Webcam Full HD",
                                        1100000
                                )
                        );

                        products.add(
                                new Product(
                                        "SP07",
                                        "Ổ cứng SSD 1TB",
                                        1800000
                                )
                        );

                        products.add(
                                new Product(
                                        "SP08",
                                        "USB 64GB",
                                        250000
                                )
                        );

                        products.add(
                                new Product(
                                        "SP09",
                                        "Loa Bluetooth",
                                        900000
                                )
                        );

                        products.add(
                                new Product(
                                        "SP10",
                                        "Giá đỡ laptop",
                                        350000
                                )
                        );

                        // Mô phỏng tải dữ liệu
                        for (int i = 0;
                             i < products.size();
                             i++) {

                            Thread.sleep(500);

                            int progress =
                                    (i + 1) * 100
                                            / products.size();

                            publish(progress);
                        }

                        return products;
                    }

                    @Override
                    protected void process(
                            List<Integer> chunks) {

                        int progress =
                                chunks.get(
                                        chunks.size() - 1
                                );

                        progressBar.setValue(progress);

                        lblStatus.setText(
                                "Đang tải: "
                                        + progress
                                        + "%"
                        );
                    }

                    @Override
                    protected void done() {

                        try {

                            List<Product> products =
                                    get();

                            // Đưa dữ liệu vào JTable
                            for (Product product : products) {

                                tableModel.addRow(
                                        new Object[]{
                                                product.id,
                                                product.name,
                                                String.format(
                                                        "%,.0f VNĐ",
                                                        product.price
                                                )
                                        }
                                );
                            }

                            progressBar.setValue(100);

                            lblStatus.setText(
                                    "Tải hoàn tất - "
                                            + products.size()
                                            + " sản phẩm"
                            );

                        } catch (Exception ex) {

                            lblStatus.setText(
                                    "Lỗi khi tải dữ liệu"
                            );
                        }

                        btnLoad.setEnabled(true);
                    }
                };

        worker.execute();
    }

    // Class Product
    private static class Product {

        String id;
        String name;
        double price;

        public Product(
                String id,
                String name,
                double price) {

            this.id = id;
            this.name = name;
            this.price = price;
        }
    }
}