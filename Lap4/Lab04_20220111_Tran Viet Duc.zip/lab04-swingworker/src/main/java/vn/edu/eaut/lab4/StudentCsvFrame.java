package vn.edu.eaut.lab4;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class StudentCsvFrame extends JFrame {

    private JButton btnChoose;
    private JButton btnLoad;

    private JLabel lblFile;
    private JLabel lblAverage;
    private JLabel lblHighest;

    private JTable table;
    private DefaultTableModel tableModel;

    private File selectedFile;

    public StudentCsvFrame() {

        setTitle("Bài 8 - Đọc CSV điểm sinh viên");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Nút chọn file
        btnChoose = new JButton("Chọn file CSV");

        // Nút đọc dữ liệu
        btnLoad = new JButton("Đọc dữ liệu");

        // Thông tin file
        lblFile = new JLabel("Chưa chọn file");

        // Điểm trung bình
        lblAverage = new JLabel("Điểm trung bình: ");

        // Sinh viên cao nhất
        lblHighest = new JLabel("Sinh viên cao nhất: ");

        // Tạo bảng
        tableModel = new DefaultTableModel(
                new String[]{"Mã SV", "Họ tên", "Điểm"},
                0
        );

        table = new JTable(tableModel);

        JScrollPane scrollPane =
                new JScrollPane(table);

        // Panel trên
        JPanel topPanel = new JPanel(
                new GridLayout(2, 2, 10, 10)
        );

        topPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        10, 10, 10, 10
                )
        );

        topPanel.add(btnChoose);
        topPanel.add(btnLoad);
        topPanel.add(lblFile);
        topPanel.add(new JLabel());

        // Panel thống kê
        JPanel statisticPanel = new JPanel(
                new GridLayout(2, 1)
        );

        statisticPanel.add(lblAverage);
        statisticPanel.add(lblHighest);

        // Panel chính
        JPanel mainPanel = new JPanel(
                new BorderLayout(10, 10)
        );

        mainPanel.add(
                topPanel,
                BorderLayout.NORTH
        );

        mainPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        mainPanel.add(
                statisticPanel,
                BorderLayout.SOUTH
        );

        add(mainPanel);

        // Chọn file
        btnChoose.addActionListener(
                e -> chooseFile()
        );

        // Đọc file
        btnLoad.addActionListener(
                e -> loadCsv()
        );
    }

    // Chọn file CSV
    private void chooseFile() {

        JFileChooser chooser =
                new JFileChooser();

        int result =
                chooser.showOpenDialog(this);

        if (result == JFileChooser.APPROVE_OPTION) {

            selectedFile =
                    chooser.getSelectedFile();

            lblFile.setText(
                    "File: "
                            + selectedFile.getAbsolutePath()
            );
        }
    }

    // Đọc CSV bằng SwingWorker
    private void loadCsv() {

        if (selectedFile == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng chọn file CSV trước!"
            );

            return;
        }

        btnChoose.setEnabled(false);
        btnLoad.setEnabled(false);

        // Xóa dữ liệu cũ
        tableModel.setRowCount(0);

        lblAverage.setText(
                "Điểm trung bình: Đang tính..."
        );

        lblHighest.setText(
                "Sinh viên cao nhất: Đang tìm..."
        );

        SwingWorker<List<Student>, Void> worker =
                new SwingWorker<>() {

                    @Override
                    protected List<Student> doInBackground()
                            throws Exception {

                        List<Student> students =
                                new ArrayList<>();

                        try (
                                BufferedReader reader =
                                        Files.newBufferedReader(
                                                selectedFile.toPath(),
                                                StandardCharsets.UTF_8
                                        )
                        ) {

                            String line;

                            // Bỏ dòng tiêu đề
                            reader.readLine();

                            while (
                                    (line = reader.readLine())
                                            != null
                            ) {

                                if (line.trim().isEmpty()) {
                                    continue;
                                }

                                String[] data =
                                        line.split(",");

                                if (data.length >= 3) {

                                    String maSV =
                                            data[0].trim();

                                    String hoTen =
                                            data[1].trim();

                                    double diem =
                                            Double.parseDouble(
                                                    data[2].trim()
                                            );

                                    students.add(
                                            new Student(
                                                    maSV,
                                                    hoTen,
                                                    diem
                                            )
                                    );
                                }
                            }
                        }

                        return students;
                    }

                    @Override
                    protected void done() {

                        try {

                            List<Student> students =
                                    get();

                            double total = 0;

                            Student highest = null;

                            for (Student student : students) {

                                // Thêm vào JTable
                                tableModel.addRow(
                                        new Object[]{
                                                student.maSV,
                                                student.hoTen,
                                                student.diem
                                        }
                                );

                                // Tính tổng
                                total += student.diem;

                                // Tìm điểm cao nhất
                                if (highest == null
                                        || student.diem
                                        > highest.diem) {

                                    highest = student;
                                }
                            }

                            // Tính trung bình
                            if (!students.isEmpty()) {

                                double average =
                                        total / students.size();

                                lblAverage.setText(
                                        String.format(
                                                "Điểm trung bình: %.2f",
                                                average
                                        )
                                );
                            } else {

                                lblAverage.setText(
                                        "Điểm trung bình: Không có dữ liệu"
                                );
                            }

                            // Hiển thị sinh viên cao nhất
                            if (highest != null) {

                                lblHighest.setText(
                                        String.format(
                                                "Sinh viên cao nhất: %s - %s - %.2f điểm",
                                                highest.maSV,
                                                highest.hoTen,
                                                highest.diem
                                        )
                                );
                            } else {

                                lblHighest.setText(
                                        "Sinh viên cao nhất: Không có dữ liệu"
                                );
                            }

                        } catch (Exception ex) {

                            JOptionPane.showMessageDialog(
                                    StudentCsvFrame.this,
                                    "Lỗi đọc file CSV: "
                                            + ex.getMessage()
                            );
                        }

                        btnChoose.setEnabled(true);
                        btnLoad.setEnabled(true);
                    }
                };

        worker.execute();
    }

    // Class Student
    private static class Student {

        String maSV;
        String hoTen;
        double diem;

        public Student(
                String maSV,
                String hoTen,
                double diem) {

            this.maSV = maSV;
            this.hoTen = hoTen;
            this.diem = diem;
        }
    }
}