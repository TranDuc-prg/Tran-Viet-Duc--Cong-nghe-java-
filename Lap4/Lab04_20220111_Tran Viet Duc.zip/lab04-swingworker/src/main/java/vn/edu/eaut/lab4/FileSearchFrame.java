package vn.edu.eaut.lab4;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class FileSearchFrame extends JFrame {

    private JButton btnChoose;
    private JButton btnSearch;
    private JTextField txtKeyword;
    private JLabel lblFile;
    private JLabel lblResult;
    private JTextArea txtResult;

    private File selectedFile;

    public FileSearchFrame() {

        setTitle("Bài 7 - Tìm kiếm từ khóa trong file");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Nút chọn file
        btnChoose = new JButton("Chọn file");

        // Ô nhập từ khóa
        txtKeyword = new JTextField();

        // Nút tìm kiếm
        btnSearch = new JButton("Tìm kiếm");

        // Hiển thị file
        lblFile = new JLabel("Chưa chọn file");

        // Hiển thị kết quả
        lblResult = new JLabel("Số dòng tìm thấy: 0");

        // Vùng hiển thị các dòng tìm thấy
        txtResult = new JTextArea();
        txtResult.setEditable(false);
        txtResult.setLineWrap(true);
        txtResult.setWrapStyleWord(true);

        JScrollPane scrollPane =
                new JScrollPane(txtResult);

        // Panel phía trên
        JPanel topPanel = new JPanel(
                new GridLayout(3, 2, 10, 10)
        );

        topPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        15, 15, 10, 15
                )
        );

        topPanel.add(new JLabel("File:"));
        topPanel.add(btnChoose);

        topPanel.add(new JLabel("Từ khóa:"));
        topPanel.add(txtKeyword);

        topPanel.add(btnSearch);
        topPanel.add(lblResult);

        // Panel chính
        JPanel mainPanel = new JPanel(
                new BorderLayout(10, 10)
        );

        mainPanel.add(
                topPanel,
                BorderLayout.NORTH
        );

        mainPanel.add(
                lblFile,
                BorderLayout.CENTER
        );

        mainPanel.add(
                scrollPane,
                BorderLayout.SOUTH
        );

        add(mainPanel);

        // Chọn file
        btnChoose.addActionListener(
                e -> chooseFile()
        );

        // Tìm kiếm
        btnSearch.addActionListener(
                e -> searchKeyword()
        );
    }

    // Chọn file TXT
    private void chooseFile() {

        JFileChooser chooser =
                new JFileChooser();

        int result =
                chooser.showOpenDialog(this);

        if (result == JFileChooser.APPROVE_OPTION) {

            selectedFile =
                    chooser.getSelectedFile();

            lblFile.setText(
                    "File: "
                            + selectedFile.getAbsolutePath()
            );

            txtResult.setText("");

            lblResult.setText(
                    "Số dòng tìm thấy: 0"
            );
        }
    }

    // Tìm kiếm từ khóa
    private void searchKeyword() {

        if (selectedFile == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng chọn file trước!"
            );

            return;
        }

        String keyword =
                txtKeyword.getText().trim();

        if (keyword.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng nhập từ khóa!"
            );

            return;
        }

        // Khóa nút khi đang tìm
        btnChoose.setEnabled(false);
        btnSearch.setEnabled(false);

        txtResult.setText("");

        lblResult.setText(
                "Đang tìm kiếm..."
        );

        SwingWorker<Integer, String> worker =
                new SwingWorker<>() {

                    @Override
                    protected Integer doInBackground()
                            throws Exception {

                        int count = 0;

                        try (
                                BufferedReader reader =
                                        Files.newBufferedReader(
                                                selectedFile.toPath(),
                                                StandardCharsets.UTF_8
                                        )
                        ) {

                            String line;

                            while (
                                    (line = reader.readLine())
                                            != null
                            ) {

                                // Không phân biệt hoa/thường
                                if (line.toLowerCase()
                                        .contains(
                                                keyword.toLowerCase()
                                        )) {

                                    count++;

                                    // Gửi dòng tìm được
                                    publish(line);
                                }
                            }
                        }

                        return count;
                    }

                    @Override
                    protected void process(
                            java.util.List<String> chunks) {

                        for (String line : chunks) {

                            txtResult.append(
                                    line + "\n"
                            );
                        }
                    }

                    @Override
                    protected void done() {

                        try {

                            int count = get();

                            lblResult.setText(
                                    "Số dòng tìm thấy: "
                                            + count
                            );

                        } catch (Exception ex) {

                            lblResult.setText(
                                    "Lỗi khi đọc file!"
                            );
                        }

                        btnChoose.setEnabled(true);
                        btnSearch.setEnabled(true);
                    }
                };

        worker.execute();
    }
}