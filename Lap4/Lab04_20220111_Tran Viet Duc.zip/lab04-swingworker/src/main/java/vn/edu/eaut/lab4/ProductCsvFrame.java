package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class ProductCsvFrame extends JFrame {

    private JButton btnOpen;
    private JButton btnAdd;
    private JButton btnDelete;
    private JButton btnSave;

    private JTable table;
    private DefaultTableModel tableModel;

    private File csvFile;

    public ProductCsvFrame() {

        setTitle("Bài 10 - Quản lý sản phẩm CSV");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Các nút
        btnOpen = new JButton("Mở CSV");
        btnAdd = new JButton("Thêm");
        btnDelete = new JButton("Xóa");
        btnSave = new JButton("Lưu CSV");

        // Bảng
        tableModel = new DefaultTableModel(
                new String[]{
                        "Mã SP",
                        "Tên sản phẩm",
                        "Giá"
                },
                0
        );

        table = new JTable(tableModel);

        JScrollPane scrollPane =
                new JScrollPane(table);

        // Panel nút
        JPanel buttonPanel = new JPanel(
                new FlowLayout()
        );

        buttonPanel.add(btnOpen);
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnSave);

        add(buttonPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Sự kiện
        btnOpen.addActionListener(
                e -> openCsv()
        );

        btnAdd.addActionListener(
                e -> addProduct()
        );

        btnDelete.addActionListener(
                e -> deleteProduct()
        );

        btnSave.addActionListener(
                e -> saveCsv()
        );
    }

    // =========================
    // MỞ FILE CSV
    // =========================

    private void openCsv() {

        JFileChooser chooser =
                new JFileChooser();

        int result =
                chooser.showOpenDialog(this);

        if (result != JFileChooser.APPROVE_OPTION) {
            return;
        }

        csvFile = chooser.getSelectedFile();

        tableModel.setRowCount(0);

        btnOpen.setEnabled(false);

        SwingWorker<Void, Object[]> worker =
                new SwingWorker<>() {

                    @Override
                    protected Void doInBackground()
                            throws Exception {

                        try (
                                BufferedReader reader =
                                        new BufferedReader(
                                                new InputStreamReader(
                                                        new FileInputStream(csvFile),
                                                        StandardCharsets.UTF_8
                                                )
                                        )
                        ) {

                            String line;

                            // Bỏ dòng tiêu đề
                            reader.readLine();

                            while (
                                    (line = reader.readLine())
                                            != null
                            ) {

                                if (line.trim().isEmpty()) {
                                    continue;
                                }

                                String[] data =
                                        line.split(",");

                                if (data.length >= 3) {

                                    String id =
                                            data[0].trim();

                                    String name =
                                            data[1].trim();

                                    double price =
                                            Double.parseDouble(
                                                    data[2].trim()
                                            );

                                    publish(
                                            new Object[]{
                                                    id,
                                                    name,
                                                    price
                                            }
                                    );
                                }
                            }
                        }

                        return null;
                    }

                    @Override
                    protected void process(
                            java.util.List<Object[]> chunks) {

                        for (Object[] row : chunks) {

                            tableModel.addRow(row);
                        }
                    }

                    @Override
                    protected void done() {

                        btnOpen.setEnabled(true);

                        JOptionPane.showMessageDialog(
                                ProductCsvFrame.this,
                                "Đã đọc file CSV!"
                        );
                    }
                };

        worker.execute();
    }

    // =========================
    // THÊM SẢN PHẨM
    // =========================

    private void addProduct() {

        JTextField txtId =
                new JTextField();

        JTextField txtName =
                new JTextField();

        JTextField txtPrice =
                new JTextField();

        JPanel panel = new JPanel(
                new GridLayout(3, 2, 10, 10)
        );

        panel.add(new JLabel("Mã sản phẩm:"));
        panel.add(txtId);

        panel.add(new JLabel("Tên sản phẩm:"));
        panel.add(txtName);

        panel.add(new JLabel("Giá:"));
        panel.add(txtPrice);

        int result =
                JOptionPane.showConfirmDialog(
                        this,
                        panel,
                        "Thêm sản phẩm",
                        JOptionPane.OK_CANCEL_OPTION
                );

        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        String id =
                txtId.getText().trim();

        String name =
                txtName.getText().trim();

        String priceText =
                txtPrice.getText().trim();

        if (id.isEmpty()
                || name.isEmpty()
                || priceText.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng nhập đầy đủ thông tin!"
            );

            return;
        }

        try {

            double price =
                    Double.parseDouble(
                            priceText
                    );

            if (price < 0) {
                throw new NumberFormatException();
            }

            tableModel.addRow(
                    new Object[]{
                            id,
                            name,
                            price
                    }
            );

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Giá phải là số >= 0!"
            );
        }
    }

    // =========================
    // XÓA SẢN PHẨM
    // =========================

    private void deleteProduct() {

        int selectedRow =
                table.getSelectedRow();

        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng chọn sản phẩm cần xóa!"
            );

            return;
        }

        int confirm =
                JOptionPane.showConfirmDialog(
                        this,
                        "Bạn có chắc muốn xóa sản phẩm này?",
                        "Xác nhận",
                        JOptionPane.YES_NO_OPTION
                );

        if (confirm ==
                JOptionPane.YES_OPTION) {

            tableModel.removeRow(
                    selectedRow
            );
        }
    }

    // =========================
    // LƯU FILE CSV
    // =========================

    private void saveCsv() {

        if (csvFile == null) {

            JFileChooser chooser =
                    new JFileChooser();

            int result =
                    chooser.showSaveDialog(this);

            if (result != JFileChooser.APPROVE_OPTION) {
                return;
            }

            csvFile =
                    chooser.getSelectedFile();
        }

        btnSave.setEnabled(false);

        SwingWorker<Void, Void> worker =
                new SwingWorker<>() {

                    @Override
                    protected Void doInBackground()
                            throws Exception {

                        try (
                                BufferedWriter writer =
                                        new BufferedWriter(
                                                new OutputStreamWriter(
                                                        new FileOutputStream(csvFile),
                                                        StandardCharsets.UTF_8
                                                )
                                        )
                        ) {

                            // Ghi tiêu đề
                            writer.write(
                                    "MaSP,TenSanPham,Gia"
                            );

                            writer.newLine();

                            // Ghi dữ liệu
                            for (int i = 0;
                                 i < tableModel.getRowCount();
                                 i++) {

                                String id =
                                        tableModel
                                                .getValueAt(i, 0)
                                                .toString();

                                String name =
                                        tableModel
                                                .getValueAt(i, 1)
                                                .toString();

                                String price =
                                        tableModel
                                                .getValueAt(i, 2)
                                                .toString();

                                writer.write(
                                        id + ","
                                                + name + ","
                                                + price
                                );

                                writer.newLine();
                            }
                        }

                        return null;
                    }

                    @Override
                    protected void done() {

                        btnSave.setEnabled(true);

                        try {

                            get();

                            JOptionPane.showMessageDialog(
                                    ProductCsvFrame.this,
                                    "Đã lưu file CSV thành công!"
                            );

                        } catch (Exception ex) {

                            JOptionPane.showMessageDialog(
                                    ProductCsvFrame.this,
                                    "Lỗi khi lưu file: "
                                            + ex.getMessage()
                            );
                        }
                    }
                };

        worker.execute();
    }

    // =========================
    // MAIN
    // =========================

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new ProductCsvFrame().setVisible(true);
        });
    }
}