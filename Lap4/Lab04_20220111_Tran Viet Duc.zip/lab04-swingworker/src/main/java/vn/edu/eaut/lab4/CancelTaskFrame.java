package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;

public class CancelTaskFrame extends JFrame {

    private JButton btnStart;
    private JButton btnCancel;
    private JProgressBar progressBar;
    private JLabel lblStatus;

    private SwingWorker<Void, Void> worker;

    public CancelTaskFrame() {

        setTitle("Bài 6 - Hủy tác vụ");
        setSize(500, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Nút bắt đầu
        btnStart = new JButton("Bắt đầu");

        // Nút hủy
        btnCancel = new JButton("Hủy");
        btnCancel.setEnabled(false);

        // Thanh tiến trình
        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);

        // Trạng thái
        lblStatus = new JLabel(
                "Chưa bắt đầu",
                SwingConstants.CENTER
        );

        // Panel chứa nút
        JPanel buttonPanel = new JPanel(
                new GridLayout(1, 2, 10, 10)
        );

        buttonPanel.add(btnStart);
        buttonPanel.add(btnCancel);

        // Panel chính
        JPanel panel = new JPanel(
                new GridLayout(3, 1, 10, 10)
        );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 30, 20, 30
                )
        );

        panel.add(buttonPanel);
        panel.add(progressBar);
        panel.add(lblStatus);

        add(panel);

        // Sự kiện bắt đầu
        btnStart.addActionListener(
                e -> startTask()
        );

        // Sự kiện hủy
        btnCancel.addActionListener(
                e -> cancelTask()
        );
    }

    // Bắt đầu tác vụ
    private void startTask() {

        btnStart.setEnabled(false);
        btnCancel.setEnabled(true);

        progressBar.setValue(0);

        lblStatus.setText(
                "Đang xử lý..."
        );

        worker = new SwingWorker<>() {

            @Override
            protected Void doInBackground()
                    throws Exception {

                // Mô phỏng công việc 10 giây
                for (int i = 0; i <= 100; i++) {

                    // Kiểm tra đã bị hủy chưa
                    if (isCancelled()) {
                        return null;
                    }

                    setProgress(i);

                    Thread.sleep(100);
                }

                return null;
            }

            @Override
            protected void done() {

                // Nếu tác vụ bị hủy
                if (isCancelled()) {

                    lblStatus.setText(
                            "Đã hủy tác vụ"
                    );

                    btnStart.setEnabled(true);
                    btnCancel.setEnabled(false);

                    return;
                }

                // Nếu hoàn thành
                progressBar.setValue(100);

                lblStatus.setText(
                        "Tác vụ hoàn thành"
                );

                btnStart.setEnabled(true);
                btnCancel.setEnabled(false);
            }
        };

        // Theo dõi tiến trình
        worker.addPropertyChangeListener(
                evt -> {

                    if ("progress".equals(
                            evt.getPropertyName()
                    )) {

                        int progress =
                                (int) evt.getNewValue();

                        progressBar.setValue(
                                progress
                        );

                        lblStatus.setText(
                                "Đang xử lý: "
                                        + progress
                                        + "%"
                        );
                    }
                }
        );

        // Chạy tác vụ
        worker.execute();
    }

    // Hủy tác vụ
    private void cancelTask() {

        if (worker != null
                && !worker.isDone()) {

            worker.cancel(true);
        }
    }
}