package vn.edu.eaut.lab11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab11SpringbootThymeleafApplicationTests {

    @Test
    void contextLoads() {
    }

}
