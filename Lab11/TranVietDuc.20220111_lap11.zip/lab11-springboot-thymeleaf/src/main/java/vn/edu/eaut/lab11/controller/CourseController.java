package vn.edu.eaut.lab11.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import vn.edu.eaut.lab11.model.Course;

import java.util.List;

@Controller
public class CourseController {

    @GetMapping("/courses")
    public String listCourses(Model model) {
        List<Course> courses = List.of(
                new Course("IT3242", "Công nghệ Java", 3),
                new Course("IT3100", "Cơ sở dữ liệu", 3),
                new Course("IT3200", "Lập trình Web", 3),
                new Course("IT3300", "Cấu trúc dữ liệu và giải thuật", 4),
                new Course("IT3400", "Mạng máy tính", 3)
        );
        model.addAttribute("courses", courses);
        return "courses";
    }
}